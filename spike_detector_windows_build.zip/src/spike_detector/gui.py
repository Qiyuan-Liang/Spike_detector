"""
GUI for preprocessing and inspecting voltage imaging sessions.
Cross-platform (Mac/Windows) PyQt GUI that loads session folders containing
either analyzed NPZ files (created by your notebook) or raw Excel traces.

Features:
- Select master folder containing session files
- List and load sessions (npz or xlsx)
- Visualize raw traces, baseline, CS/SS streams, and detected spikes
- Adjustable detection parameters (thresholds, filter bands, smoothing)
- Compute and show simple spike statistics (rates, SNR, FWHM summary)
- Export current figure as vector image (SVG or PDF)

Dependencies:
- PyQt5 (or PySide6 as fallback)
- numpy, scipy, pandas, matplotlib

Install with pip if needed:
pip install pyqt5 numpy scipy pandas matplotlib

Run:
python gui_preprocess.py

"""

import os
import sys
import glob
from pathlib import Path
import json
import copy
from datetime import datetime
import numpy as np
import pandas as pd
from scipy.signal import butter, sosfiltfilt, find_peaks, fftconvolve, peak_widths
from scipy.ndimage import percentile_filter
from scipy.stats import median_abs_deviation
import matplotlib
matplotlib.use('QtAgg')
matplotlib.rcParams['font.family'] = 'Arial'
matplotlib.rcParams['svg.fonttype'] = 'none'
matplotlib.rcParams['pdf.fonttype'] = 42
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

# PyQt6-only target for packaging/release
from PyQt6 import QtWidgets, QtCore, QtGui
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QFileDialog, QMessageBox, QColorDialog
from PyQt6.QtGui import QColor

from .utils.processing import (
    TEMPLATE_TARGET_FS,
    _build_parallel_template_banks,
    _resample_template_to_fs,
    apply_frame_processing,
    apply_filter,
    compute_event_snrs,
    get_interpolated_wave,
    get_wave_stats,
    process_cell_simple,
    process_cell_template_matching,
    _select_event_bank,
)
from .utils.denoise import default_denoise_config, adaptive_wavelet_denoise
from .utils.session import (load_session_path, is_excel_lock_file,
                            _list_table_files_in_dir as list_table_files)
from .utils.export import save_figure_with_dialog
from .utils.event_metrics import event_dff_percent, peth_edges, session_time_courses
from .utils.stats import (autocorrelogram_counts, autocorrelogram_components,
                          recording_intervals_ms, mean_std_count, triggered_rate_components, local_cv2_values)
from .utils.validation import validate_session, effective_settings, mask_windows
from .utils.widths import measure_width, measure_widths
from .utils.combo import process_cell_combo
from .utils.qc import QC_DEFAULTS, LEGACY_QC_KEYS, migrate_qc_settings, run_with_qc
from .utils.annotations import manual_result
from .utils.boundaries import observation_bounds, observation_mask, protected_preprocess, protected_filter, embed_observed_result, smooth_blanked_display, visualization_window
from .utils.saved_session import load_saved_detection_folder, load_saved_detection, json_safe
from .utils.results import TemporaryDetectionStore, cleanup_legacy_temporaries, output_paths, publish_detection

APP_VERSION = '3.6.50'


# Keep input help in one place so the same setting reads consistently in the
# main window and its dialogs. These are Qt hover tooltips, not status messages.
SETTING_TOOLTIPS = {
    'list_sessions': 'Choose the recording session displayed in the main window.',
    'combo_path': 'Limit statistics to one loaded folder, or include all folders.',
    'combo_session': 'Choose a recording session to view or summarize.',
    'combo_cell': 'Choose a cell; All pools the selected cells where available.',
    'combo_baseline_method': 'Choose how slow baseline drift is estimated before detection.',
    'spin_baseline_window': 'Requested window for median/percentile drift estimation. Its effective sample count is constrained by recording length and saved in result metadata.',
    'spin_baseline_percentile': 'Percentile used only for the Percentile baseline method.',
    'combo_frame_processing': 'Rolling average uses overlapping frame windows. Mean averages non-overlapping frame groups and interpolates them onto the original time grid; this is the former Downsampling frames mode. Both reduce temporal resolution.',
    'spin_avg_frames': 'Frames used for rolling or block averaging before detection. 0 disables processing; 1 leaves the trace unchanged. Larger groups smooth noise and fast spikes.',
    'spin_window': 'Time span displayed in the plot; this does not change detection.',
    'spin_zoom': 'Vertical plot range; 0 chooses the range automatically.',
    'slider_time': 'Move the visible time window through the full recording, including blanked periods. New views start at the initial blank boundary.',
    'spin_cs_low': 'CS high-pass cutoff in Hz; 0 disables this cutoff.',
    'spin_cs_high': 'CS low-pass cutoff in Hz; 0 disables this cutoff.',
    'spin_cs_thresh': 'CS peak cutoff in MAD noise units; 0 disables CS in Threshold mode. With Combo, this selects template-learning seeds; use a conservative value.',
    'spin_cs_order': 'Butterworth filter order for the CS detection trace.',
    'spin_ss_low': 'SS high-pass cutoff in Hz; 0 disables this cutoff.',
    'spin_ss_high': 'SS low-pass cutoff in Hz; 0 disables this cutoff.',
    'spin_ss_thresh': 'SS peak cutoff in MAD noise units; 0 disables SS in Threshold mode. With Combo, this selects template-learning seeds; use a conservative value.',
    'spin_ss_order': 'Butterworth filter order for the SS detection trace.',
    'spin_ss_blank': 'Legacy symmetric SS exclusion around CS when separate mask sides are unset.',
    'chk_show_baseline': 'Show the baseline-corrected trace in the main plot.',
    'chk_show_cs': 'Show the filtered CS trace in the main plot.',
    'chk_show_ss': 'Show the filtered SS trace in the main plot.',
    'chk_denoise': 'Apply adaptive wavelet denoising before SS detection.',
    'chk_local_baseline': 'Use a centered, rolling Gaussian-scaled MAD noise estimate for Threshold cutoffs and Combo seeds. Does not subtract another baseline or change template scoring, amplitude-SNR windows or whitening.',
    'spin_local_ss_ms': 'Centered window for local SS threshold-noise estimation. Used only with Local noise, including Combo seeds; separate from amplitude-SNR and whitening windows.',
    'spin_local_cs_ms': 'Centered window for local CS threshold-noise estimation. Used only with Local noise, including Combo seeds; separate from amplitude-SNR and whitening windows.',
    'chk_template_parallel': 'Match separate groups of template shapes and combine candidates.',
    'chk_template_whitening': 'Estimate background noise spectrum and whiten both trace and matching kernels. Applies to template, Combo and batch detection; cutoffs may need retuning.',
    'chk_combo': 'Learn temporary templates per cell from Threshold-tab seeds, then use Template-tab matching settings. Use conservative seed thresholds.',
    'spin_template_groups': 'Number of template shape groups; View can enable each group.',
    'combo_template_method': 'Choose amplitude-fit LLR, experimental positive-core SS, or similarity scoring.',
    'spin_template_cs_sigma': 'CS positive matched response / Gaussian-scaled background MAD of the filtered or whitened trace. The LLR gain cutoff is this value squared / 2. Separate from amplitude SNR; not a calibrated probability.',
    'spin_template_ss_sigma': 'SS short-core matched response / Gaussian-scaled background MAD of the filtered or whitened trace. The LLR gain cutoff is this value squared / 2. Separate from amplitude SNR; not a calibrated probability.',
    'spin_template_cs_sim': 'Minimum CS waveform correlation for Normalized Similarity.',
    'spin_template_ss_sim': 'Minimum SS core correlation for Normalized Similarity.',
    'spin_template_lowpass': 'Additional SS low-pass cutoff for template detection; 0 disables.',
    'chk_detection_save': 'Save permanent results beside recordings. Unchecked: temporary viewing exports, removed on close. Existing saved results require confirmation before replacement.',
    'paths': 'Enter one recording-folder path per line for batch detection.',
    'combo_scope': 'Choose whether templates come from this cell or all cells.',
    'combo_type': 'Select CS templates, SS templates, or manual spike labels. Selections belong to their original cell and session.',
    'spin_cs_w': 'Duration of the extracted CS template waveform.',
    'spin_ss_w': 'Duration of the extracted SS template waveform.',
    'spin_cs_bg_alpha': 'Opacity of individual CS waveforms behind their mean.',
    'spin_distribution_bins': 'Number of bins in FWHM, SNR, instantaneous-rate, dF/F and local CV2 distributions. Does not change ACG or CS-triggered rate bins.',
    'spin_peth_pre_ms': 'Time before CS in the SS peri-event rate plot. This changes only statistics, not detection.',
    'spin_peth_post_ms': 'Time after CS in the SS peri-event rate plot. At least one side of the range must be positive.',
    'spin_peth_bin_ms': 'SS peri-CS rate bin width. Counts are divided by actual observed SS exposure; masked time is unavailable.',
    'spin_ss_trend_s': 'Non-overlapping window in seconds for mean SS event dF/F and exposure-corrected SS rate. Sessions are never binned together.',
    'spin_cs_trend_s': 'Non-overlapping window in seconds for mean CS event dF/F and exposure-corrected CS rate. Sessions are never binned together.',
    'spin_ss_bg_alpha': 'Opacity of individual SS waveforms behind their mean.',
    'spin_cs_acg_window': 'Maximum positive and negative CS lag shown in the autocorrelogram.',
    'spin_cs_acg_bin': 'Width of each CS autocorrelogram lag bin.',
    'spin_ss_acg_window': 'Maximum positive and negative SS lag shown in the autocorrelogram.',
    'spin_ss_acg_bin': 'Width of each SS autocorrelogram lag bin.',
    'chk_denoise_cs': 'Use the denoised trace for CS detection as well as SS detection.',
    'spin_cs_mind': 'Minimum CS candidate spacing before QC. 0 disables extra spacing beyond the native sample grid; applies to every detector.',
    'spin_ss_mind': 'Minimum SS candidate spacing before QC. Applied once across template groups; 0 disables extra spacing beyond the native sample grid.',
    'spin_ss_mask_pre': 'Exclude SS this long before accepted CS; 0 removes this side. Template/FIR support can extend the actual masked region.',
    'spin_ss_mask_post': 'Exclude SS this long after accepted CS; 0 removes this side. Template/FIR support can extend the actual masked region.',
    'spin_final_blank': 'Exclude the end of the recording from preprocessing, detection and analysis. 0 disables. Exports retain the raw samples for viewing and an explicit valid interval for analysis.',
    'spin_initial_blank': 'Exclude the recording start from preprocessing, detection and analysis; 0 disables. Template support also excludes incomplete boundary windows.',
    'spin_tpl_cs_window': 'Duration of CS waveforms saved as templates.',
    'spin_tpl_ss_window': 'Duration of SS waveforms saved as templates.',
    'spin_template_components': 'PCA components used to group templates, not detection kernels.',
    'spin_line_scale': 'Scale the line thickness used in plots and exported figures.',
    'combo_raw_scale_unit': 'Raw-trace scale bar in Gaussian-scaled MAD noise units (SD fallback) or ΔF/F percent. This scale is separate from local event SNR.',
    'spin_preview_window': 'Time span shown in the denoising preview.',
    'spin_f_min': 'Lowest frequency included in the wavelet transform.',
    'spin_f_max': 'Highest frequency included in the wavelet transform.',
    'spin_n_freqs': 'Number of sampled wavelet frequencies; more gives finer resolution.',
    'spin_min_clusters': 'Smallest frequency-cluster count considered by denoising.',
    'spin_max_clusters': 'Largest frequency-cluster count considered by denoising.',
    'spin_pca': 'Maximum PCA components used to cluster frequency profiles.',
    'spin_thr_sigma': 'Cluster-envelope cutoff: local mean + this multiplier × local SD. A larger value attenuates more frames; this is not event SNR or a MAD cutoff.',
    'spin_att_min': 'Minimum retained coefficient fraction after attenuation.',
    'chk_soft': 'Gradually attenuate coefficients below threshold instead of hard suppression.',
    'spin_cycles': 'Local envelope-threshold window = cycles / highest frequency in each cluster, with at least five samples.',
    'spin_max_tp': 'Maximum time samples used to fit frequency clusters.',
    'chk_event_refine': 'Apply optional event-level PC1-based attenuation after denoising.',
    'spin_evt_win': 'Time window around candidate events for PC1 refinement.',
    'spin_evt_sigma': 'Absolute reconstructed cluster-trace amplitude cutoff in Gaussian-scaled MAD units for proposing refinement events.',
    'spin_evt_z': 'Attenuate event windows whose PC1 score, centered on its median and scaled by MAD, falls below this cutoff.',
    'spin_evt_att': 'Fraction retained for events selected by PC1 refinement.',
    'chk_show_advanced': 'Show the advanced denoising controls.',
    'combo': 'Choose a color preset to preview and customize.',
}


def _set_input_tooltip(widget, description):
    widget.setToolTip(description)
    if isinstance(widget, QtWidgets.QAbstractSpinBox):
        widget.lineEdit().setToolTip(description)


def _apply_numeric_precision(owner):
    hz = {'spin_cs_low', 'spin_cs_high', 'spin_ss_low', 'spin_ss_high',
          'spin_template_lowpass', 'spin_f_min', 'spin_f_max'}
    sigma = {'spin_cs_thresh', 'spin_ss_thresh', 'spin_template_cs_sigma',
             'spin_template_ss_sigma', 'spin_thr_sigma', 'spin_evt_sigma', 'spin_evt_z'}
    ms = {'spin_baseline_window', 'spin_window', 'spin_preview_window', 'spin_cs_mind',
          'spin_ss_mind', 'spin_ss_blank', 'spin_initial_blank', 'spin_final_blank', 'spin_tpl_cs_window',
          'spin_tpl_ss_window', 'spin_cs_w', 'spin_ss_w', 'spin_evt_win',
          'spin_ss_mask_pre', 'spin_ss_mask_post'}
    for name, widget in vars(owner).items():
        if not isinstance(widget, QtWidgets.QDoubleSpinBox):
            continue
        if name in hz:
            widget.setDecimals(0)
            widget.setSingleStep(1)
        elif name in sigma or name in ms or name.endswith('_ms') or '_acg_' in name:
            widget.setDecimals(1)
            if name in sigma:
                widget.setSingleStep(0.1)


def _apply_setting_tooltips(owner):
    """Give each named input its hover help, including a spin box's edit field."""
    _apply_numeric_precision(owner)
    for name, description in SETTING_TOOLTIPS.items():
        widget = getattr(owner, name, None)
        if isinstance(widget, QtWidgets.QWidget):
            _set_input_tooltip(widget, description)


def _detect_cell(raw, fs, params, baseline_params, frames, frame_mode, templates, denoise_cfg,
                 fixed_exclusion_masks=None, fixed_whitening=None):
    start, stop = observation_bounds(len(raw), fs, params.get('INITIAL_BLANK_MS', 150.0),
                                      params.get('FINAL_BLANK_MS', 50.0))
    minimum = 6*max(int(params.get('CS_FILTER_ORDER', 4)), int(params.get('SS_FILTER_ORDER', 4)))+4
    if stop-start < minimum or frames > stop-start:
        raise ValueError(f'Boundary blanks leave {stop-start} samples; at least {minimum} observed samples (and at least the frame count) are required for these filters. Reduce the blanks/frame count or use a longer recording.')
    local = dict(params, INITIAL_BLANK_MS=0.0, FINAL_BLANK_MS=0.0)
    masks = ({key: np.asarray(value)[start:stop] for key, value in fixed_exclusion_masks.items()}
             if fixed_exclusion_masks is not None else None)
    result = _detect_observed_cell(np.asarray(raw)[start:stop], fs, local, baseline_params,
        frames, frame_mode, templates, denoise_cfg, fixed_exclusion_masks=masks,
        fixed_whitening=fixed_whitening)
    return embed_observed_result(result, len(raw), start, stop)


def _detect_observed_cell(raw, fs, params, baseline_params, frames, frame_mode, templates, denoise_cfg,
                 fixed_exclusion_masks=None, fixed_whitening=None):
    """CPU-only detection job. No QWidget or mutable GUI state is used here."""
    raw_proc, baseline, _ = protected_preprocess(raw, fs, params, baseline_params, frames, frame_mode)
    corrected = raw_proc - baseline
    denoise_meta = {'ok': False, 'error': 'disabled'}
    ss_input = cs_input = corrected
    if params.get('DENOISE_ENABLED', False):
        denoised, denoise_meta = adaptive_wavelet_denoise(corrected, fs, cfg=denoise_cfg)
        if not denoise_meta.get('ok', False):
            raise ValueError(f"Denoising failed: {denoise_meta.get('error', 'unknown error')}")
        ss_input = denoised
        if params.get('DENOISE_APPLY_TO_CS', False):
            cs_input = denoised
    sign = -1.0 if params.get('NEGATIVE_GOING', True) else 1.0
    common = dict(
        negative_going=params.get('NEGATIVE_GOING', True),
        cs_low_cut=params.get('CS_LOW_CUT_HZ', 0.0),
        cs_high_cut=params.get('CS_HIGH_CUT_HZ', 150.0),
        cs_min_dist_ms=params.get('CS_MIN_DIST_MS', 25.0),
        cs_min_fwhm_ms=0.0,
        ss_low_cut=params.get('SS_LOW_CUT_HZ', 0.0),
        ss_high_cut=params.get('SS_HIGH_CUT_HZ', 0.0),
        ss_min_dist_ms=params.get('SS_MIN_DIST_MS', 4.0),
        ss_blank_ms=params.get('SS_BLANK_MS', 18.0),
        ss_mask_pre_ms=mask_windows(params)[0],
        ss_mask_post_ms=mask_windows(params)[1],
        initial_blank_ms=params.get('INITIAL_BLANK_MS', 150.0),
        use_preprocessed=True, pre_detrended=corrected * sign,
        pre_baseline=baseline, pre_detrended_cs=cs_input * sign,
        pre_detrended_ss=ss_input * sign,
        cs_order=int(params.get('CS_FILTER_ORDER', 4)),
        ss_order=int(params.get('SS_FILTER_ORDER', 4)),
    )
    if params.get('COMBO_DETECTION') or params.get('DETECTION_METHOD') == 'Template Matching':
        template_options = dict(
            cs_thresh_sigma=params.get('TEMPLATE_CS_SIGMA', 30.0),
            cs_min_filtered_peak_sigma=0.0,
            ss_thresh_sigma=params.get('TEMPLATE_SS_SIGMA', 5.0),
            template_match_method=params.get('TEMPLATE_MATCH_METHOD', 'LLR Probability Vector'),
            cs_similarity_threshold=params.get('TEMPLATE_CS_SIMILARITY', .90),
            ss_similarity_threshold=params.get('TEMPLATE_SS_SIMILARITY', .80),
            similarity_min_response_sigma=0.0,
            template_ss_lowpass_hz=params.get('TEMPLATE_SS_LOWPASS_HZ', 700.0),
            template_whitening=bool(params.get('TEMPLATE_WHITENING', False)),
            fixed_whitening=fixed_whitening,
            fixed_exclusion_masks=fixed_exclusion_masks,
            parallel_match=bool(params.get('TEMPLATE_PARALLEL', False)),
            parallel_groups=int(params.get('TEMPLATE_PARALLEL_GROUPS', 3)),
            parallel_components=int(params.get('TEMPLATE_PARALLEL_COMPONENTS', 2)),
            cs_selected_groups=params.get('TEMPLATE_CS_SELECTED_GROUPS'),
            ss_selected_groups=params.get('TEMPLATE_SS_SELECTED_GROUPS'))
        if params.get('COMBO_DETECTION'):
            result = process_cell_combo(raw_proc, fs, common=common,
                seed_options=dict(cs_thresh_sigma=params.get('CS_THRESHOLD_SIGMA', 6.0),
                    ss_thresh_sigma=params.get('SS_THRESHOLD_SIGMA', 3.0),
                    local_baseline=bool(params.get('LOCAL_BASELINE', False)),
                    local_baseline_cs_ms=float(params.get('LOCAL_BASELINE_CS_MS', 200.0)),
                    local_baseline_ss_ms=float(params.get('LOCAL_BASELINE_SS_MS', 50.0))),
                template_options=template_options, fallback_templates=templates,
                cs_window_ms=params.get('TEMPLATE_CS_WINDOW_MS', 30.0),
                ss_window_ms=params.get('TEMPLATE_SS_WINDOW_MS', 8.0),
                ss_max_width=params.get('SS_MAX_FWHM_MS', 4.5) or None,
                qc_params=params, qc_source=corrected * sign)
        else:
            result = run_with_qc(lambda **qc: process_cell_template_matching(raw_proc, fs, **common, **template_options, **qc,
                template_cs_bank=templates.get('cs_templates', []),
                template_ss_bank=templates.get('ss_templates', []),
                template_cs_fs_bank=templates.get('fs_cs', []),
                template_ss_fs_bank=templates.get('fs_ss', [])), corrected * sign, fs, params)
    else:
        result = run_with_qc(lambda **qc: process_cell_simple(raw_proc, fs,
            cs_thresh_sigma=params.get('CS_THRESHOLD_SIGMA', 6.0),
            ss_thresh_sigma=params.get('SS_THRESHOLD_SIGMA', 3.0),
            local_baseline=bool(params.get('LOCAL_BASELINE', False)),
            local_baseline_cs_ms=float(params.get('LOCAL_BASELINE_CS_MS', 200.0)),
            local_baseline_ss_ms=float(params.get('LOCAL_BASELINE_SS_MS', 50.0)), **common, **qc), corrected * sign, fs, params)
    result['denoise_enabled'] = bool(params.get('DENOISE_ENABLED', False))
    result['negative_going'] = bool(params.get('NEGATIVE_GOING', True))
    result['denoise_apply_to_cs'] = bool(params.get('DENOISE_APPLY_TO_CS', False))
    result['denoise_meta'] = denoise_meta
    return result


def _polarity_reversed_control(raw, fs, context, original_result):
    """Rerun one cell with inverted signal and the original exclusion intervals."""
    params = dict(context['params'])
    if params.get('DETECTION_METHOD') != 'Template Matching' and not params.get('COMBO_DETECTION'):
        raise ValueError('Polarity-reversed control requires template matching results.')
    templates = context['templates']
    if params.get('COMBO_DETECTION'):
        # Reuse original learned shapes: learning again from reversed noise
        # would change the detector being controlled.
        templates = original_result['_combo_templates']
        params['COMBO_DETECTION'] = False
        params['DETECTION_METHOD'] = 'Template Matching'
        for kind in ('cs', 'ss'):
            if original_result['combo'][kind]['source'] == 'auto':
                params[f'TEMPLATE_{kind.upper()}_SELECTED_GROUPS'] = None
    params['NEGATIVE_GOING'] = not bool(params.get('NEGATIVE_GOING', True))
    masks = {kind: np.asarray(original_result[f'{kind}_exclusion_mask'], dtype=bool).copy()
             for kind in ('cs', 'ss')}
    result = _detect_cell(np.asarray(raw, dtype=float), fs, params,
        dict(context['baseline_params']), int(context['frames']), context['frame_mode'],
        templates, context['denoise_cfg'], fixed_exclusion_masks=masks,
        fixed_whitening=original_result.get('_template_whitening'))
    return dict(cs_score_peaks=result['cs_candidate_diagnostics']['score_peaks'],
                ss_score_peaks=result['ss_candidate_diagnostics']['score_peaks'],
                cs_kept=len(result['cs_peaks']), ss_kept=len(result['ss_peaks']),
                cs_masked=result['cs_candidate_diagnostics']['masked'],
                ss_masked=result['ss_candidate_diagnostics']['masked'])


class _DetectionCellThread(QtCore.QThread):
    result_ready = QtCore.pyqtSignal(object, object)

    def __init__(self, job, parent=None):
        super().__init__(parent)
        self.job = job

    def run(self):
        try:
            self.result_ready.emit(self.job(), None)
        except Exception as exc:
            self.result_ready.emit(None, exc)

# Orientation compatibility helper (works across PyQt6 / PySide6)
try:
    # PyQt6/PySide6: prefer Qt.Orientation.Horizontal
    ORIENT_HORIZONTAL = Qt.Orientation.Horizontal
except Exception:
    try:
        ORIENT_HORIZONTAL = QtCore.Qt.Orientation.Horizontal
    except Exception:
        try:
            ORIENT_HORIZONTAL = QtCore.Qt.Horizontal
        except Exception:
            # fallback integer (least preferred)
            ORIENT_HORIZONTAL = 1

# Alignment compatibility (AlignTop)
try:
    ALIGN_TOP = Qt.AlignTop
except Exception:
    try:
        ALIGN_TOP = QtCore.Qt.AlignTop
    except Exception:
        try:
            ALIGN_TOP = QtCore.Qt.AlignmentFlag.AlignTop
        except Exception:
            # fallback integer
            ALIGN_TOP = 1


def _get_screen_scale():
    """Return a scale factor based on the primary screen devicePixelRatio or logical DPI.
    Falls back to 1.0 when information is unavailable. This helps adapt sizes across
    different display resolutions and Windows scaling settings.
    """
    try:
        app = QtWidgets.QApplication.instance()
        if app is None:
            return 1.0
        screen = app.primaryScreen()
        if screen is None:
            return 1.0

        try:
            logical_dpi = float(screen.logicalDotsPerInch())
        except Exception:
            logical_dpi = 96.0
        try:
            dpr = float(screen.devicePixelRatio())
        except Exception:
            dpr = 1.0

        if sys.platform == 'darwin':
            # Keep macOS behavior unchanged (already tuned visually).
            return 1.0

        # Windows/Linux: account for OS display scaling from logical DPI.
        dpi_scale = logical_dpi / 96.0 if logical_dpi > 0 else 1.0
        scale = max(dpi_scale, dpr, 1.0)
        return float(max(0.9, min(2.0, scale)))
    except Exception:
        return 1.0

# QSizePolicy compatibility: resolve Expanding/Fixed across bindings
try:
    SIZEPOLICY_EXPANDING = QtWidgets.QSizePolicy.Expanding
    SIZEPOLICY_FIXED = QtWidgets.QSizePolicy.Fixed
except Exception:
    try:
        SIZEPOLICY_EXPANDING = QtWidgets.QSizePolicy.Policy.Expanding
        SIZEPOLICY_FIXED = QtWidgets.QSizePolicy.Policy.Fixed
    except Exception:
        try:
            SIZEPOLICY_EXPANDING = QtWidgets.QSizePolicy.Policy.Expanding.value
            SIZEPOLICY_FIXED = QtWidgets.QSizePolicy.Policy.Fixed.value
        except Exception:
            SIZEPOLICY_EXPANDING = 1
            SIZEPOLICY_FIXED = 0


def _scaled_size(px_w, px_h):
    """Scale a (width,height) pair by the detected screen scale factor and return ints."""
    try:
        # Keep top-level window sizes in logical pixels and let Qt handle DPI scaling.
        # This avoids oversized windows on Windows high-DPI displays.
        return max(1, int(round(float(px_w)))), max(1, int(round(float(px_h))))
    except Exception:
        return px_w, px_h


def _make_figure(width, height, dpi=100):
    """Create a matplotlib Figure with reduced font sizes (approx. 4x smaller)
    to avoid overly large text on high-DPI displays. Uses a temporary rc_context
    so global rcParams are not permanently changed.
    """
    # Create a standard Figure and rely on native Qt6 font/DPI handling.
    return Figure(figsize=(width, height), dpi=dpi)


def _get_linewidth(base=1.0):
    """Return an adaptive line width scaled with screen DPI.
    Ensures lines are thicker on high-DPI displays and not too thin on low-DPI.
    """
    try:
        s = _get_screen_scale()
        user_scale = float(globals().get('_USER_LINEWIDTH_SCALE', 1.0))
        lw = float(base) * user_scale * (1.0 + 0.20 * max(0.0, s - 1.0))
        return float(max(0.5, lw))
    except Exception:
        return float(1.0)


_USER_LINEWIDTH_SCALE = 1.0


def _set_user_linewidth_scale(scale):
    try:
        globals()['_USER_LINEWIDTH_SCALE'] = float(max(0.2, min(5.0, float(scale))))
    except Exception:
        globals()['_USER_LINEWIDTH_SCALE'] = 1.0


def _scale_font(base=10):
    """Scale font size mildly on high-DPI displays while keeping macOS unchanged."""
    try:
        s = _get_screen_scale()
        return int(round(float(base) * (1.0 + 0.15 * max(0.0, s - 1.0))))
    except Exception:
        return base


def _stats_window_ms(spike_type):
    """Per-type waveform window used for SNR/FWHM statistics.

    Keep this centralized so summary text and Spike Statistics viewer stay aligned.
    """
    return 100.0 if str(spike_type).upper() == 'CS' else 50.0


def _set_frame_hline(frame):
    """Set a QFrame to horizontal line shape in a binding-compatible way."""
    try:
        frame.setFrameShape(QtWidgets.QFrame.HLine)
        return
    except Exception:
        pass
    try:
        frame.setFrameShape(QtWidgets.QFrame.Shape.HLine)
        return
    except Exception:
        pass
    try:
        # PySide/PyQt variants where enum has .value
        frame.setFrameShape(QtWidgets.QFrame.HLine.value)
        return
    except Exception:
        pass
    try:
        # fallback: set a thin line by adjusting frame style
        frame.setLineWidth(1)
    except Exception:
        pass


# -------------------- Core processing helpers (adapted from notebook) --------------------

def estimate_noise_mad(trace):
    # Robust MAD-based noise estimator with fallbacks.
    try:
        mad = median_abs_deviation(trace, scale='normal')
        if np.isfinite(mad) and mad > 0:
            return mad
    except Exception:
        mad = None
    # The normal-scaled MAD above estimates standard deviation for Gaussian noise.
    # If MAD is zero, use standard deviation in the same signal units.
    try:
        std = float(np.nanstd(trace))
        if np.isfinite(std) and std > 0:
            return std
    except Exception:
        pass
    # final tiny fallback to avoid zero thresholds
    return 1e-6


def detrend_trace(trace, fs, window_sec=0.05, percentile=20):
    window_samples = int(window_sec * fs)
    if window_samples < 5:
        window_samples = 5
    baseline = percentile_filter(trace, percentile, size=window_samples)
    return trace - baseline, baseline


def butter_bandpass(lowcut, highcut, fs, order=3):
    nyq = 0.5 * fs
    # no filtering requested
    if lowcut is None and highcut is None:
        return None
    # A cutoff set to 0 or below disables that side of the filter.
    def _norm(val):
        if val is None:
            return None
        try:
            v = float(val)
        except Exception:
            return None
        if not np.isfinite(v) or v <= 0.0:
            return None
        return v / float(nyq)

    low_n = _norm(lowcut)
    high_n = _norm(highcut)
    if low_n is None and high_n is None:
        return None
    # clamp to valid open interval (0,1)
    if high_n is not None and high_n >= 1.0:
        high_n = 1.0 - 1e-3
    # If both normalized present but inverted or too narrow, skip filtering
    if low_n is not None and high_n is not None and low_n >= high_n:
        return None
    try:
        if low_n is None:
            return butter(order, high_n, btype='low', output='sos')
        if high_n is None:
            return butter(order, low_n, btype='high', output='sos')
        return butter(order, [low_n, high_n], btype='band', output='sos')
    except ValueError:
        # fallback: do not filter if parameters invalid
        return None


def apply_filter(trace, fs, low=None, high=None, order=3):
    sos = butter_bandpass(low, high, fs, order=order)
    if sos is None:
        return trace
    return sosfiltfilt(sos, trace)


def apply_frame_processing(trace, frames=0, mode='Rolling average'):
    """Apply frame-based processing while preserving original signal length."""
    arr = np.asarray(trace, dtype=float).ravel()
    try:
        n_frames = int(frames)
    except Exception:
        n_frames = 0
    if n_frames <= 0 or arr.size <= 1:
        return arr.copy()

    mode_txt = str(mode)
    if 'Downsampling' in mode_txt:
        step = max(1, n_frames)
        n_blocks = int(np.ceil(arr.size / float(step)))
        if n_blocks <= 1:
            return arr.copy()
        ds = np.empty(n_blocks, dtype=float)
        x_ds = np.empty(n_blocks, dtype=float)
        for i in range(n_blocks):
            s = i * step
            e = min(arr.size, s + step)
            blk = arr[s:e]
            ds[i] = float(np.mean(blk)) if blk.size > 0 else float(arr[min(s, arr.size - 1)])
            x_ds[i] = s + 0.5 * max(1, (e - s) - 1)
        x_full = np.arange(arr.size, dtype=float)
        return np.interp(x_full, x_ds, ds, left=float(ds[0]), right=float(ds[-1]))

    win = int(max(1, n_frames))
    kern = np.ones(win, dtype=float) / float(win)
    return np.convolve(arr, kern, mode='same')


TEMPLATE_TARGET_FS = 5000.0


def _resample_template_to_fs(template, template_fs, target_fs):
    tpl = np.asarray(template, dtype=float).ravel()
    if tpl.size <= 3:
        return tpl
    try:
        src_fs = float(template_fs) if template_fs is not None else float(target_fs)
        dst_fs = float(target_fs)
    except Exception:
        return tpl
    if not np.isfinite(src_fs) or src_fs <= 0 or not np.isfinite(dst_fs) or dst_fs <= 0:
        return tpl
    if abs(src_fs - dst_fs) < 1e-9:
        return tpl
    duration_s = (tpl.size - 1) / src_fs
    n_new = int(round(duration_s * dst_fs)) + 1
    n_new = max(4, n_new)
    x_old = np.linspace(0.0, duration_s, tpl.size)
    x_new = np.linspace(0.0, duration_s, n_new)
    return np.interp(x_new, x_old, tpl)


def _resample_to_length(arr, n_out):
    x = np.asarray(arr, dtype=float).ravel()
    n_out = int(max(1, n_out))
    if x.size == 0:
        return np.zeros(n_out, dtype=float)
    if x.size == n_out:
        return x.copy()
    if x.size == 1:
        return np.full(n_out, float(x[0]), dtype=float)
    x_old = np.linspace(0.0, 1.0, x.size)
    x_new = np.linspace(0.0, 1.0, n_out)
    return np.interp(x_new, x_old, x)


def _resample_trace_to_fs(trace, src_fs, target_fs):
    x = np.asarray(trace, dtype=float).ravel()
    if x.size <= 1:
        return x.copy()
    try:
        src = float(src_fs)
        dst = float(target_fs)
    except Exception:
        return x.copy()
    if not np.isfinite(src) or not np.isfinite(dst) or src <= 0 or dst <= 0:
        return x.copy()
    if abs(src - dst) < 1e-9:
        return x.copy()
    n_out = int(round(x.size * dst / src))
    return _resample_to_length(x, max(2, n_out))


def _orient_template_peak_positive(template):
    tpl = np.asarray(template, dtype=float).ravel()
    if tpl.size <= 3:
        return tpl
    x = tpl - np.nanmean(tpl)
    n = x.size
    center = n // 2
    half_w = max(1, int(round(0.1 * n)))
    s = max(0, center - half_w)
    e = min(n, center + half_w + 1)
    try:
        center_mean = float(np.nanmean(x[s:e]))
    except Exception:
        center_mean = np.nan
    if np.isfinite(center_mean):
        if center_mean < 0:
            return -x
        return x
    try:
        if abs(float(np.nanmin(x))) > abs(float(np.nanmax(x))):
            return -x
    except Exception:
        pass
    return x


def _build_template_distribution(template_bank, fs_bank, target_fs, force_peak_positive=False):
    rows = []
    if template_bank is None:
        return None, None
    for k, tpl in enumerate(template_bank):
        try:
            tpl_fs = fs_bank[k] if fs_bank is not None and k < len(fs_bank) else target_fs
        except Exception:
            tpl_fs = target_fs
        try:
            arr = np.asarray(tpl, dtype=float).ravel()
            if arr.size <= 3:
                continue
            if force_peak_positive:
                arr = _orient_template_peak_positive(arr)
            arr_rs = _resample_template_to_fs(arr, tpl_fs, target_fs)
            if arr_rs.size > 3 and np.all(np.isfinite(arr_rs)):
                rows.append(arr_rs)
        except Exception:
            continue
    if len(rows) == 0:
        return None, None
    lengths = [int(np.asarray(r).size) for r in rows]
    m = int(np.median(lengths))
    m = max(4, m)
    stack = np.vstack([_resample_to_length(np.asarray(r, dtype=float).ravel(), m) for r in rows])
    mu_signal = np.nanmean(stack, axis=0)
    return mu_signal, stack


def _llr_probability_vector(trace, mu_signal, sigma_signal, mu_noise, sigma_noise):
    x = np.asarray(trace, dtype=float).ravel()
    mu_s = np.asarray(mu_signal, dtype=float).ravel()
    sig_s = np.asarray(sigma_signal, dtype=float).ravel()
    if x.size == 0 or mu_s.size <= 3 or sig_s.size != mu_s.size:
        return np.zeros_like(x)

    eps = 1e-9
    sig_b = float(max(abs(float(sigma_noise)), eps))
    mu_b = float(mu_noise)
    sig_s = np.maximum(np.abs(sig_s), eps)
    m = int(mu_s.size)

    x2 = x * x
    ones = np.ones(m, dtype=float)

    sum_x = fftconvolve(x, ones, mode='same')
    sum_x2 = fftconvolve(x2, ones, mode='same')

    inv_var_s = 1.0 / (sig_s * sig_s)
    w1 = inv_var_s
    w2 = mu_s * inv_var_s
    w3 = (mu_s * mu_s) * inv_var_s

    term_signal = (
        -0.5 * float(np.sum(np.log(2.0 * np.pi * sig_s * sig_s)))
        -0.5 * fftconvolve(x2, w1[::-1], mode='same')
        + fftconvolve(x, w2[::-1], mode='same')
        -0.5 * float(np.sum(w3))
    )

    term_noise = (
        -0.5 * m * float(np.log(2.0 * np.pi * sig_b * sig_b))
        -0.5 * (sum_x2 - 2.0 * mu_b * sum_x + m * (mu_b * mu_b)) / (sig_b * sig_b)
    )

    return np.asarray(term_signal - term_noise, dtype=float)


def _compute_llr_from_template_bank(trace, template_bank, fs_bank, fs, force_peak_positive=False):
    x = np.asarray(trace, dtype=float).ravel()
    if x.size == 0:
        return x
    mu_signal, stack = _build_template_distribution(template_bank, fs_bank, fs, force_peak_positive=force_peak_positive)
    if mu_signal is None or stack is None:
        return np.zeros_like(x)

    mu_noise = float(np.nanmedian(x))
    sigma_noise = float(estimate_noise_mad(x))
    sigma_noise = max(abs(sigma_noise), 1e-9)

    n_templates = int(stack.shape[0])
    if n_templates > 9:
        sigma_signal = np.nanstd(stack, axis=0, ddof=1)
    else:
        sigma_signal = np.full(mu_signal.shape, sigma_noise, dtype=float)
    sigma_signal = np.maximum(np.asarray(sigma_signal, dtype=float), max(1e-9, sigma_noise * 1e-3))

    return _llr_probability_vector(x, mu_signal, sigma_signal, mu_noise, sigma_noise)


def _kmeans_points(points, k, max_iter=40):
    x = np.asarray(points, dtype=float)
    if x.ndim != 2 or x.shape[0] == 0:
        return np.zeros(0, dtype=int)
    n = x.shape[0]
    k = int(max(1, min(int(k), n)))
    init_idx = np.linspace(0, n - 1, k).round().astype(int)
    centers = x[init_idx].copy()
    labels = np.zeros(n, dtype=int)
    for _ in range(int(max_iter)):
        d2 = np.sum((x[:, None, :] - centers[None, :, :]) ** 2, axis=2)
        new_labels = np.argmin(d2, axis=1)
        if np.array_equal(new_labels, labels):
            break
        labels = new_labels
        for ci in range(k):
            mask = (labels == ci)
            if np.any(mask):
                centers[ci] = np.mean(x[mask], axis=0)
    return labels


def _build_parallel_template_banks(template_bank, fs_bank, target_fs, force_peak_positive=False, max_use_types=3):
    if template_bank is None or len(template_bank) == 0:
        return []
    rows = []
    for k, tpl in enumerate(template_bank):
        try:
            tpl_fs = fs_bank[k] if fs_bank is not None and k < len(fs_bank) else target_fs
        except Exception:
            tpl_fs = target_fs
        try:
            arr = np.asarray(tpl, dtype=float).ravel()
            if arr.size <= 3:
                continue
            if force_peak_positive:
                arr = _orient_template_peak_positive(arr)
            arr_rs = _resample_template_to_fs(arr, tpl_fs, target_fs)
            if arr_rs.size > 3 and np.all(np.isfinite(arr_rs)):
                rows.append(np.asarray(arr_rs, dtype=float).ravel())
        except Exception:
            continue
    if len(rows) == 0:
        return []

    lengths = [r.size for r in rows]
    m = max(4, int(np.median(lengths)))
    stack = np.vstack([_resample_to_length(r, m) for r in rows])

    centered = stack - np.mean(stack, axis=0, keepdims=True)
    if centered.shape[0] > 1 and centered.shape[1] > 1:
        try:
            _, _, vt = np.linalg.svd(centered, full_matrices=False)
            n_pc = max(1, min(2, vt.shape[0]))
            feats = centered @ vt[:n_pc].T
        except Exception:
            feats = centered[:, :1]
    else:
        feats = centered[:, :1]

    n_templates = stack.shape[0]
    k_clusters = max(1, min(max(4, max_use_types), n_templates))
    labels = _kmeans_points(feats, k_clusters)

    unique, counts = np.unique(labels, return_counts=True)
    order = np.argsort(-counts)
    chosen = [int(unique[idx]) for idx in order[:max(1, min(int(max_use_types), unique.size))]]

    out = []
    for cid in chosen:
        mask = (labels == cid)
        if not np.any(mask):
            continue
        bank = [stack[i].copy() for i in np.where(mask)[0]]
        fs_list = [float(target_fs)] * len(bank)
        out.append((bank, fs_list))
    return out


def _filter_peaks_min_fwhm(signal, peaks, fs_hz, min_fwhm_ms):
    p = np.asarray(peaks, dtype=int).ravel()
    if p.size == 0:
        return np.array([], dtype=int)
    try:
        min_ms = float(min_fwhm_ms)
    except Exception:
        return np.sort(np.unique(p))
    try:
        fs_val = float(fs_hz)
    except Exception:
        fs_val = np.nan
    if (not np.isfinite(min_ms)) or min_ms <= 0 or (not np.isfinite(fs_val)) or fs_val <= 0:
        return np.sort(np.unique(p))
    try:
        widths_samples, _, _, _ = peak_widths(np.asarray(signal, dtype=float), p, rel_height=0.5)
        fwhm_ms = (widths_samples / fs_val) * 1000.0
        keep = p[fwhm_ms > min_ms]
        if keep.size == 0:
            return np.array([], dtype=int)
        return np.asarray(sorted(set(keep.tolist())), dtype=int)
    except Exception:
        return np.sort(np.unique(p))


def process_cell_template_matching(raw_trace, fs,
                                   template_cs_bank=None, template_ss_bank=None,
                                   template_cs_fs_bank=None, template_ss_fs_bank=None,
                                   negative_going=True,
                                   cs_low_cut=0.0, cs_high_cut=150.0, cs_thresh_sigma=6.0, cs_min_dist_ms=25,
                                   cs_min_fwhm_ms=4.0,
                                   ss_low_cut=0.0, ss_high_cut=0.0, ss_thresh_sigma=2.5,
                                   ss_min_dist_ms=2, ss_blank_ms=15,
                                   template_match_method='LLR Probability Vector',
                                   parallel_match=False,
                                   use_preprocessed=False, pre_detrended=None, pre_baseline=None,
                                   pre_detrended_cs=None, pre_detrended_ss=None,
                                   initial_blank_ms=0.0, cs_order=3, ss_order=3):
    working = raw_trace * -1 if negative_going else raw_trace
    if use_preprocessed and pre_detrended is not None and pre_baseline is not None:
        detrended = pre_detrended
        baseline = pre_baseline
    else:
        detrended, baseline = detrend_trace(working, fs, window_sec=0.05, percentile=20)

    detr_for_detection = detrended
    detr_for_detection_cs = np.asarray(pre_detrended_cs, dtype=float) if pre_detrended_cs is not None else detr_for_detection
    detr_for_detection_ss = np.asarray(pre_detrended_ss, dtype=float) if pre_detrended_ss is not None else detr_for_detection

    global_sigma = estimate_noise_mad(detrended)

    sim_fs = float(max(float(fs), TEMPLATE_TARGET_FS))
    cs_base = apply_filter(detr_for_detection_cs, fs, low=cs_low_cut, high=cs_high_cut, order=cs_order)
    cs_base_sim = _resample_trace_to_fs(cs_base, fs, sim_fs)
    if bool(parallel_match):
        cs_banks = _build_parallel_template_banks(template_cs_bank, template_cs_fs_bank, sim_fs,
                                                  force_peak_positive=bool(negative_going),
                                                  max_use_types=3)
        cs_scores = []
        cs_union_candidates = []
        cs_thr_each = []
        for bk, bk_fs in cs_banks:
            s = _compute_llr_from_template_bank(cs_base_sim, bk, bk_fs, sim_fs, force_peak_positive=False)
            cs_scores.append(s)
            try:
                sig_i = estimate_noise_mad(s)
                thr_i = float(cs_thresh_sigma * sig_i)
                cs_thr_each.append(thr_i)
                p_i, _ = find_peaks(s, height=thr_i, distance=max(1, int((cs_min_dist_ms / 1000.0) * sim_fs)))
                if p_i.size > 0:
                    cs_union_candidates.append(np.asarray(p_i, dtype=int))
            except Exception:
                pass
        if len(cs_scores) > 0:
            cs_trace_sim = np.maximum.reduce(cs_scores)
        else:
            cs_trace_sim = _compute_llr_from_template_bank(cs_base_sim, template_cs_bank, template_cs_fs_bank, sim_fs, force_peak_positive=bool(negative_going))
    else:
        cs_trace_sim = _compute_llr_from_template_bank(cs_base_sim, template_cs_bank, template_cs_fs_bank, sim_fs, force_peak_positive=bool(negative_going))
    sigma_cs = estimate_noise_mad(cs_trace_sim)
    cs_dist = max(1, int((cs_min_dist_ms / 1000.0) * sim_fs))
    cs_has_templates = template_cs_bank is not None and len(template_cs_bank) > 0
    if cs_has_templates:
        cs_threshold_used = float(cs_thresh_sigma * sigma_cs)
        cs_candidates_sim, _ = find_peaks(cs_trace_sim, height=cs_threshold_used, distance=cs_dist)
        if bool(parallel_match):
            extra = []
            try:
                if len(cs_union_candidates) > 0:
                    extra.append(np.concatenate(cs_union_candidates))
            except Exception:
                pass
            if len(extra) > 0:
                cs_candidates_sim = np.unique(np.concatenate([cs_candidates_sim] + extra).astype(int))
            try:
                if len(cs_thr_each) > 0:
                    cs_threshold_used = float(min([cs_threshold_used] + cs_thr_each))
            except Exception:
                pass
    else:
        cs_threshold_used = np.nan
        cs_candidates_sim = np.array([], dtype=int)
    cs_candidates_sim = _filter_peaks_min_fwhm(cs_trace_sim, cs_candidates_sim, sim_fs, cs_min_fwhm_ms)
    if initial_blank_ms is not None and initial_blank_ms > 0:
        init_blank_samples = int((initial_blank_ms / 1000.0) * sim_fs)
        cs_candidates_sim = cs_candidates_sim[cs_candidates_sim >= init_blank_samples]
    if cs_candidates_sim.size > 0:
        cs_peaks = np.unique(np.clip(np.round(cs_candidates_sim * (fs / sim_fs)).astype(int), 0, len(raw_trace) - 1))
    else:
        cs_peaks = np.array([], dtype=int)

    ss_base = apply_filter(detr_for_detection_ss, fs, low=ss_low_cut, high=ss_high_cut, order=ss_order)
    ss_base_sim = _resample_trace_to_fs(ss_base, fs, sim_fs)
    ss_base_clean_sim = ss_base_sim.copy()
    blank_samples = max(0, int((ss_blank_ms / 1000.0) * sim_fs))
    for cs_idx in cs_candidates_sim:
        start = max(0, cs_idx - blank_samples // 2)
        end = min(len(ss_base_clean_sim), start + blank_samples)
        ss_base_clean_sim[start:end] = 0

    if bool(parallel_match):
        ss_banks = _build_parallel_template_banks(template_ss_bank, template_ss_fs_bank, sim_fs,
                                                  force_peak_positive=bool(negative_going),
                                                  max_use_types=3)
        ss_scores = []
        ss_union_candidates = []
        ss_thr_each = []
        for bk, bk_fs in ss_banks:
            s = _compute_llr_from_template_bank(ss_base_clean_sim, bk, bk_fs, sim_fs, force_peak_positive=False)
            ss_scores.append(s)
            try:
                sig_i = estimate_noise_mad(s)
                thr_i = float(ss_thresh_sigma * sig_i)
                ss_thr_each.append(thr_i)
                p_i, _ = find_peaks(s, height=thr_i, distance=max(1, int((ss_min_dist_ms / 1000.0) * sim_fs)))
                if p_i.size > 0:
                    ss_union_candidates.append(np.asarray(p_i, dtype=int))
            except Exception:
                pass
        if len(ss_scores) > 0:
            ss_trace_sim = np.maximum.reduce(ss_scores)
        else:
            ss_trace_sim = _compute_llr_from_template_bank(ss_base_clean_sim, template_ss_bank, template_ss_fs_bank, sim_fs, force_peak_positive=bool(negative_going))
    else:
        ss_trace_sim = _compute_llr_from_template_bank(ss_base_clean_sim, template_ss_bank, template_ss_fs_bank, sim_fs, force_peak_positive=bool(negative_going))

    sigma_ss = estimate_noise_mad(ss_trace_sim)
    ss_dist = max(1, int((ss_min_dist_ms / 1000.0) * sim_fs))
    ss_has_templates = template_ss_bank is not None and len(template_ss_bank) > 0
    if ss_has_templates:
        ss_threshold_used = float(ss_thresh_sigma * sigma_ss)
        ss_candidates_sim, _ = find_peaks(ss_trace_sim, height=ss_threshold_used, distance=ss_dist)
        if bool(parallel_match):
            extra = []
            try:
                if len(ss_union_candidates) > 0:
                    extra.append(np.concatenate(ss_union_candidates))
            except Exception:
                pass
            if len(extra) > 0:
                ss_candidates_sim = np.unique(np.concatenate([ss_candidates_sim] + extra).astype(int))
            try:
                if len(ss_thr_each) > 0:
                    ss_threshold_used = float(min([ss_threshold_used] + ss_thr_each))
            except Exception:
                pass
    else:
        ss_threshold_used = np.nan
        ss_candidates_sim = np.array([], dtype=int)
    if initial_blank_ms is not None and initial_blank_ms > 0:
        init_blank_samples = int((initial_blank_ms / 1000.0) * sim_fs)
        ss_candidates_sim = ss_candidates_sim[ss_candidates_sim >= init_blank_samples]
    if ss_candidates_sim.size > 0:
        ss_peaks = np.unique(np.clip(np.round(ss_candidates_sim * (fs / sim_fs)).astype(int), 0, len(raw_trace) - 1))
    else:
        ss_peaks = np.array([], dtype=int)

    cs_similarity_trace = _resample_to_length(cs_trace_sim, len(raw_trace))
    ss_similarity_trace = _resample_to_length(ss_trace_sim, len(raw_trace))
    ss_base_clean = _resample_to_length(ss_base_clean_sim, len(raw_trace))

    return {
        'detrended': detrended,
        'baseline': baseline,
        'cs_trace': cs_base,
        'cs_peaks': cs_peaks,
        'ss_trace': ss_base_clean,
        'ss_peaks': ss_peaks,
        'sigma_cs': sigma_cs,
        'sigma_ss': sigma_ss,
        'raw_sigma': global_sigma,
        'det_method': f'Template Matching ({template_match_method})',
        'threshold_mode': 'Sigma x MAD',
        'parallel_match': bool(parallel_match),
        'cs_min_fwhm_ms_used': float(cs_min_fwhm_ms),
        'cs_threshold_used': cs_threshold_used,
        'ss_threshold_used': ss_threshold_used,
        'cs_similarity_trace': cs_similarity_trace,
        'ss_similarity_trace': ss_similarity_trace,
    }





def process_cell_simple(raw_trace, fs, negative_going=True,
                        cs_low_cut=0.0, cs_high_cut=150.0, cs_thresh_sigma=6.0, cs_min_dist_ms=25,
                        cs_min_fwhm_ms=4.0,
                        ss_low_cut=0.0, ss_high_cut=0.0, ss_thresh_sigma=2.5,
                        ss_min_dist_ms=2, ss_blank_ms=15, ss_min_width_ms=1, ss_max_width_ms=6,
                        use_preprocessed=False, pre_detrended=None, pre_baseline=None,
                        pre_detrended_cs=None, pre_detrended_ss=None,
                        initial_blank_ms=0.0, cs_order=3, ss_order=3,
                        local_baseline=False, local_baseline_cs_ms=200.0,
                        local_baseline_ss_ms=50.0):
    # allow upstream code to provide averaged + baseline-corrected (detrended) signal
    working = raw_trace * -1 if negative_going else raw_trace
    if use_preprocessed and pre_detrended is not None and pre_baseline is not None:
        detrended = pre_detrended
        baseline = pre_baseline
    else:
        detrended, baseline = detrend_trace(working, fs, window_sec=0.05, percentile=20)
    # If baseline is effectively disabled (all zeros), remove very-low-frequency
    # components for detection only so DC/drift doesn't dominate filtered traces.
    detr_for_detection = detrended
    try:
        if isinstance(baseline, np.ndarray) and np.allclose(baseline, 0):
            # apply a mild high-pass at 1 Hz to remove DC/drift for detection
            try:
                detr_for_detection = apply_filter(detrended, fs, low=1.0, high=None, order=3)
            except Exception:
                detr_for_detection = detrended
    except Exception:
        detr_for_detection = detrended
    detr_for_detection_cs = np.asarray(pre_detrended_cs, dtype=float) if pre_detrended_cs is not None else detr_for_detection
    detr_for_detection_ss = np.asarray(pre_detrended_ss, dtype=float) if pre_detrended_ss is not None else detr_for_detection
    global_sigma = estimate_noise_mad(detrended)

    # CS stream. A cutoff set to 0 disables that side of the filter.
    # Use detr_for_detection (possibly high-passed) for computing detection traces
    cs_trace = apply_filter(detr_for_detection_cs, fs, low=cs_low_cut, high=cs_high_cut, order=cs_order)
    sigma_cs = estimate_noise_mad(cs_trace)
    cs_dist = int((cs_min_dist_ms / 1000.0) * fs)
    if cs_dist < 1:
        cs_dist = 1

    # CS threshold: local or global
    if local_baseline:
        from .utils.processing import estimate_noise_mad_local
        cs_win_samples = max(5, int((local_baseline_cs_ms / 1000.0) * fs))
        cs_local_sigma = estimate_noise_mad_local(cs_trace, cs_win_samples)
        cs_threshold_trace = cs_thresh_sigma * cs_local_sigma
        cs_candidates, _ = find_peaks(cs_trace, distance=cs_dist)
        cs_candidates = cs_candidates[cs_trace[cs_candidates] >= cs_threshold_trace[cs_candidates]]
    else:
        cs_threshold_trace = None
        cs_candidates, _ = find_peaks(cs_trace, height=cs_thresh_sigma * sigma_cs, distance=cs_dist)

    cs_candidates = _filter_peaks_min_fwhm(cs_trace, cs_candidates, fs, cs_min_fwhm_ms)

    # remove peaks that fall within the initial blank period (if any)
    if initial_blank_ms is not None and initial_blank_ms > 0:
        init_blank_samples = int((initial_blank_ms / 1000.0) * fs)
        cs_peaks = cs_candidates[cs_candidates >= init_blank_samples]
    else:
        cs_peaks = cs_candidates

    # SS stream (bandpass)
    ss_trace = apply_filter(detr_for_detection_ss, fs, low=ss_low_cut, high=ss_high_cut, order=ss_order)
    ss_trace_clean = ss_trace.copy()
    blank_samples = int((ss_blank_ms / 1000.0) * fs)
    for cs_idx in cs_peaks:
        # blank centered on CS
        start = max(0, cs_idx - blank_samples // 2)
        end = min(len(raw_trace), start + blank_samples)
        ss_trace_clean[start:end] = 0
    # Robust sigma for SS: prefer non-zero samples after blanking, else use estimator on full signal
    try:
        nonzero = ss_trace_clean[ss_trace_clean != 0]
        if nonzero.size > 0:
            sigma_ss_filtered = estimate_noise_mad(nonzero)
        else:
            sigma_ss_filtered = estimate_noise_mad(ss_trace_clean)
    except Exception:
        sigma_ss_filtered = estimate_noise_mad(ss_trace_clean)
    ss_dist = int((ss_min_dist_ms / 1000.0) * fs)
    ss_dist = max(1, ss_dist)

    # SS threshold: local or global
    if local_baseline:
        from .utils.processing import estimate_noise_mad_local
        ss_win_samples = max(5, int((local_baseline_ss_ms / 1000.0) * fs))
        ss_local_sigma = estimate_noise_mad_local(ss_trace_clean, ss_win_samples)
        ss_threshold_trace = ss_thresh_sigma * ss_local_sigma
        try:
            ss_candidates, _ = find_peaks(ss_trace_clean, distance=ss_dist)
            ss_candidates = ss_candidates[ss_trace_clean[ss_candidates] >= ss_threshold_trace[ss_candidates]]
        except Exception:
            ss_candidates = np.array([], dtype=int)
    else:
        ss_threshold_trace = None
        try:
            ss_candidates, _ = find_peaks(
                ss_trace_clean,
                height=ss_thresh_sigma * sigma_ss_filtered,
                distance=ss_dist,
            )
        except Exception:
            ss_candidates = np.array([], dtype=int)

    # No local SNR filtering: accept SS candidates directly, but exclude initial blank
    if initial_blank_ms is not None and initial_blank_ms > 0:
        init_blank_samples = int((initial_blank_ms / 1000.0) * fs)
        ss_peaks = ss_candidates[ss_candidates >= init_blank_samples]
    else:
        ss_peaks = ss_candidates

    result = {
        'detrended': detrended,
        'baseline': baseline,
        'cs_trace': cs_trace,
        'cs_peaks': cs_peaks,
        'ss_trace': ss_trace_clean,
        'ss_peaks': ss_peaks,
        'sigma_cs': sigma_cs,
        'sigma_ss': sigma_ss_filtered,
        'raw_sigma': global_sigma,
        'det_method': 'Threshold',
        'threshold_mode': 'Sigma x MAD (local)' if local_baseline else 'Sigma x MAD',
        'cs_min_fwhm_ms_used': float(cs_min_fwhm_ms),
        'cs_threshold_used': float(cs_thresh_sigma * sigma_cs),
        'ss_threshold_used': float(ss_thresh_sigma * sigma_ss_filtered),
        'local_baseline': bool(local_baseline),
        'ss_width_filter_enabled': False,
        'ss_min_dist_ms_used': float(ss_min_dist_ms),
        'ss_blank_ms_used': float(ss_blank_ms),
        'initial_blank_ms_used': float(initial_blank_ms) if initial_blank_ms is not None else 0.0,
    }
    if cs_threshold_trace is not None:
        result['cs_threshold_trace'] = cs_threshold_trace
    if ss_threshold_trace is not None:
        result['ss_threshold_trace'] = ss_threshold_trace
    return result


def get_interpolated_wave(wave, fs, upscale_factor=10):
    n_points = len(wave)
    if n_points <= 1:
        return np.arange(n_points), wave
    x_new = np.linspace(0, n_points - 1, int(n_points * upscale_factor))
    try:
        from scipy.interpolate import CubicSpline
        cs = CubicSpline(np.arange(n_points), wave)
        return x_new, cs(x_new)
    except Exception:
        # fallback to simple interpolation
        return x_new, np.interp(x_new, np.arange(n_points), wave)


def get_wave_stats(wave, time_axis_ms):
    if len(wave) == 0:
        return np.nan, np.nan
    arr = np.asarray(wave, dtype=float).ravel()
    tx = np.asarray(time_axis_ms, dtype=float).ravel()
    if arr.size == 0 or tx.size != arr.size:
        return np.nan, np.nan
    finite = np.isfinite(arr) & np.isfinite(tx)
    if not np.any(finite):
        return np.nan, np.nan
    arr = arr[finite]
    tx = tx[finite]
    if arr.size == 0:
        return np.nan, np.nan
    peak_idx = int(np.nanargmax(arr))
    n_base = max(5, int(round(0.10 * arr.size)))
    n_base = min(n_base, max(1, peak_idx)) if peak_idx > 0 else min(n_base, arr.size)
    baseline = float(np.nanmedian(arr[:n_base])) if n_base > 0 else 0.0
    y = arr - baseline
    amp = float(y[peak_idx])
    if not np.isfinite(amp) or amp <= 0:
        return amp, np.nan
    half_height = 0.5 * amp

    def _cross_time(i0, i1):
        y0 = float(y[i0] - half_height)
        y1 = float(y[i1] - half_height)
        t0 = float(tx[i0])
        t1 = float(tx[i1])
        denom = y1 - y0
        if not np.isfinite(denom) or abs(denom) < 1e-12:
            return t0
        frac = float(np.clip(-y0 / denom, 0.0, 1.0))
        return t0 + frac * (t1 - t0)

    left_t = np.nan
    for i in range(peak_idx - 1, -1, -1):
        if y[i] <= half_height <= y[i + 1]:
            left_t = _cross_time(i, i + 1)
            break
    right_t = np.nan
    for i in range(peak_idx, arr.size - 1):
        if y[i] >= half_height >= y[i + 1]:
            right_t = _cross_time(i, i + 1)
            break
    fwhm = np.nan
    if np.isfinite(left_t) and np.isfinite(right_t) and right_t > left_t:
        fwhm = float(right_t - left_t)
    else:
        try:
            widths, _, left_ips, right_ips = peak_widths(y, [peak_idx], rel_height=0.5)
            if widths.size > 0 and np.isfinite(widths[0]) and widths[0] > 0:
                sample_axis = np.arange(arr.size, dtype=float)
                lt = float(np.interp(float(left_ips[0]), sample_axis, tx))
                rt = float(np.interp(float(right_ips[0]), sample_axis, tx))
                if rt > lt:
                    fwhm = rt - lt
        except Exception:
            pass
    return amp, fwhm


def _event_fwhm_from_trace(trace, peak_idx, fs, window_ms, neighbors=(), align_ms=0):
    return measure_width(trace, peak_idx, fs, window_ms, neighbors, align_ms)['fwhm_ms']


def _result_fwhm(res, spike_type, peak):
    for row in res.get('event_widths_' + spike_type.lower(), []):
        if row['candidate_index'] == int(peak):
            return row['fwhm_ms']
    return np.nan


def _select_event_bank(peaks, max_per_cell=None):
    """Return a deterministic subset of peak indices for stats/SNR/FWHM.

    If number of peaks exceeds `max_per_cell`, select evenly spaced events
    across the full peak list to keep coverage while ensuring repeatability.
    """
    try:
        arr = np.array(peaks, dtype=int)
        if arr.size <= 0:
            return arr
        if max_per_cell is None:
            return arr
        max_n = int(max_per_cell)
        if max_n <= 0 or arr.size <= max_n:
            return arr
        idx = np.linspace(0, arr.size - 1, max_n, dtype=int)
        return arr[idx]
    except Exception:
        try:
            arr = np.array(peaks, dtype=int)
            if max_per_cell is None:
                return arr
            return arr[:int(max_per_cell)]
        except Exception:
            return np.array([], dtype=int)


def compute_event_snrs(res, spike_type='CS', fs=1000.0, window_ms=100, max_per_cell=None):
    """Compute SNRs for events in a single result dict `res`.

    Returns a list of SNRs computed as max(|wave - baseline|)/sigma where baseline
    is the mean of the first 5 samples of the window. `spike_type` is 'CS' or 'SS'.
    This helper ensures consistent SNR calculations across summaries and viewers.
    """
    snr_list = []
    if res is None:
        return snr_list
    try:
        half_win = int((window_ms / 2.0) * fs / 1000.0)
        if spike_type == 'CS':
            peaks = np.array(res.get('cs_peaks', []), dtype=int)
            trace = res.get('cs_trace', None)
            sigma = float(res.get('sigma_cs', 1.0))
        else:
            peaks = np.array(res.get('ss_peaks', []), dtype=int)
            trace = res.get('ss_trace', None)
            if trace is None:
                trace = res.get('detrended', None)
            sigma = float(res.get('raw_sigma', 1.0))

        if trace is None or peaks.size == 0:
            return snr_list

        chosen = _select_event_bank(peaks, max_per_cell=max_per_cell)
        for p in chosen:
            s = int(p - half_win); e = int(p + half_win)
            if s < 0 or e >= len(trace):
                continue
            wave = trace[s:e]
            if len(wave) != (2 * half_win):
                continue
            # local baseline and amplitude
            baseline = np.mean(wave[:5]) if len(wave) > 5 else 0.0
            amp = float(np.max(np.abs(wave - baseline)))
            if sigma == 0:
                continue
            snr = amp / float(sigma)
            snr_list.append(snr)
    except Exception:
        pass
    return snr_list


# Rebind processing helpers from extracted utils module (keeps GUI code unchanged).
from .utils.processing import (
    EVENT_SNR_POLICY,
    TEMPLATE_TARGET_FS,
    _build_parallel_template_banks,
    _resample_template_to_fs,
    apply_frame_processing,
    apply_filter,
    compute_event_snrs,
    get_interpolated_wave,
    get_wave_stats,
    process_cell_simple,
    process_cell_template_matching,
    _select_event_bank,
)


# -------------------- GUI Application --------------------
class PlotCanvas(FigureCanvas):
    def __init__(self, parent=None, width=6, height=4, dpi=100):
        # Create figure with reduced fonts for high-DPI safety
        fig = _make_figure(width, height, dpi=dpi)
        self.ax = fig.add_subplot(111)
        super().__init__(fig)
        self.setParent(parent)
        try:
            self.setSizePolicy(QtWidgets.QSizePolicy(SIZEPOLICY_EXPANDING, SIZEPOLICY_EXPANDING))
            self.updateGeometry()
        except Exception:
            pass
        fig.tight_layout()


class DetectionTabs(QtWidgets.QTabWidget):
    """Let the current settings page determine the compact upper-panel height."""
    def _page_height(self, minimum=False):
        page = self.currentWidget()
        if page is None:
            return 0
        hint = page.minimumSizeHint() if minimum else page.sizeHint()
        return hint.height() + self.tabBar().sizeHint().height() + 12

    def sizeHint(self):
        hint = super().sizeHint()
        hint.setHeight(self._page_height())
        return hint

    def minimumSizeHint(self):
        hint = super().minimumSizeHint()
        hint.setHeight(self._page_height(minimum=True))
        return hint


def _application_icon():
    """Package-relative asset path also works inside a PyInstaller bundle."""
    filename = 'spike_detector_macos.png' if sys.platform == 'darwin' else 'spike_detector.png'
    return QtGui.QIcon(str(Path(__file__).parent / 'assets' / filename))


def _display_processed_raw(data, cell_idx):
    snapshot = data.get('_saved_settings_snapshot', {})
    ui = snapshot.get('ui', {})
    raw = np.asarray(data['raw_data'][:, cell_idx], dtype=float)
    valid = data.get('analysis_valid_mask', np.ones(len(raw), dtype=bool))
    return smooth_blanked_display(raw, data['processed_raw_data'][:, cell_idx], valid,
        int(ui.get('avg_frames', 0)), snapshot.get('params', {}).get('FRAME_PROCESSING_MODE', 'Rolling average'))


def _trace_view_window(data, params, width, slider, auto_start):
    valid = data.get('analysis_valid_mask')
    if valid is None:
        valid = observation_mask(len(data['time_ms']), float(data['fs']), params)
    return visualization_window(data['time_ms'], width, slider/1000.0, valid, auto_start)


class MainWindow(QtWidgets.QMainWindow):
    detection_completed = QtCore.pyqtSignal(int, int)

    def __init__(self):
        super().__init__()
        self.setWindowTitle(f'Spike detector V{APP_VERSION}')
        self.setWindowIcon(_application_icon())
        self.resize(*_scaled_size(1150, 700))

        # State
        self.master_folder = ''
        self.batch_folders = []
        self.batch_load_issues = []
        self.sessions = []  # list of session paths
        self.session_names = []
        self.loaded_sessions = {}  # session_name: data dict
        self.selected_session = None
        self.selected_cell = 0
        self._denoise_cache = {}
        self._temporary_store = TemporaryDetectionStore()

        # Baseline correction params
        self.baseline_params = {
            'method': 'Median',  # 'Disable', 'Percentile', 'Median'
            'window_ms': 30.0,
            'percentile': 20.0,
        }

        # Color scheme
        self.colors = {
            'raw': '#333333',
            'baseline': '#FFC20A',
        }

        # Detection params (defaults)
        self.params = {
            'NEGATIVE_GOING': True,
            'DETECTION_METHOD': 'Threshold',
            'COMBO_DETECTION': False,
            'SAVE_DETECTION_RESULTS': False,
            'CS_LOW_CUT_HZ': 0.0,
            'CS_HIGH_CUT_HZ': 150.0,
            'CS_THRESHOLD_SIGMA': 6.0,
            'CS_MIN_DIST_MS': 25.0,
            'CS_MIN_FWHM_MS': 4.0,
            'CS_MAX_FWHM_MS': 0.0,
            'CS_MIN_AMPLITUDE_SNR': 0.0,
            'SS_MIN_AMPLITUDE_SNR': 0.0,
            'SS_MIN_FWHM_MS': 0.0,
            'SS_LOW_CUT_HZ': 0.0,
            'SS_HIGH_CUT_HZ': 0.0,
            'SS_THRESHOLD_SIGMA': 3.0,
            'SS_MIN_DIST_MS': 4.0,
            'SS_BLANK_MS': 18.0,
            'SS_MAX_FWHM_MS': 4.5,
            'INITIAL_BLANK_MS': 150.0,
                'FINAL_BLANK_MS': 50.0,
            'CS_FILTER_ORDER': 4,
            'SS_FILTER_ORDER': 4,
            'FRAME_PROCESSING_MODE': 'Rolling average',
            'TEMPLATE_CS_WINDOW_MS': 30.0,
            'TEMPLATE_SS_WINDOW_MS': 8.0,
            'TEMPLATE_MATCH_METHOD': 'LLR Probability Vector',
            'TEMPLATE_PARALLEL': False,
            'TEMPLATE_WHITENING': False,
            'TEMPLATE_PARALLEL_GROUPS': 3,
            'TEMPLATE_PARALLEL_COMPONENTS': 2,
            'TEMPLATE_CS_SELECTED_GROUPS': None,
            'TEMPLATE_SS_SELECTED_GROUPS': None,
            'TEMPLATE_CS_SIGMA': 30.0,
            'TEMPLATE_SS_SIGMA': 5.0,
            'TEMPLATE_CS_SIMILARITY': 0.90,
            'TEMPLATE_SS_SIMILARITY': 0.80,
            'TEMPLATE_SS_LOWPASS_HZ': 700.0,
            'LOCAL_BASELINE': False,
            'LOCAL_BASELINE_SS_MS': 50.0,
            'LOCAL_BASELINE_CS_MS': 200.0,
            'DENOISE_ENABLED': False,
            'DENOISE_APPLY_TO_CS': False,
            'DENOISE_F_MIN_HZ': 3.0,
            'DENOISE_F_MAX_HZ': 1000.0,
            'DENOISE_N_FREQS': 72,
            'DENOISE_MAX_CLUSTERS': 20,
            'DENOISE_MIN_CLUSTERS': 2,
            'DENOISE_MAX_PCA_COMPONENTS': 20,
            'DENOISE_THRESHOLD_SIGMA': 1.5,
            'DENOISE_ATTENUATION_MIN': 0.25,
            'DENOISE_SOFT_THRESHOLD': False,
            'DENOISE_MOVING_CYCLES': 1.0,
            'DENOISE_MAX_TIMEPOINTS_FOR_CLUSTERING': 10000,
            'DENOISE_EVENT_REFINE_ENABLED': True,
            'DENOISE_EVENT_REFINE_WINDOW_MS': 20.0,
            'DENOISE_EVENT_REFINE_SIGMA': 2.0,
            'DENOISE_EVENT_REFINE_PC1_Z_CUTOFF': -0.5,
            'DENOISE_EVENT_REFINE_ATTENUATION': 0.6,
            'LINE_WIDTH_SCALE': 0.7,
            'RAW_SCALE_BAR_UNIT': 'Sigma',
            'STATS_CS_BG_ALPHA': 0.3,
            'STATS_SS_BG_ALPHA': 0.003,
            'STATS_DISTRIBUTION_BINS': 20,
            'STATS_PETH_PRE_MS': 20.0,
            'STATS_PETH_POST_MS': 60.0,
            'STATS_PETH_BIN_MS': 1.0,
            'STATS_SS_TREND_S': 5.0,
            'STATS_CS_TREND_S': 5.0,
            'DETECTION_VIEW_WINDOW_MS': 1000.0,
            'DETECTION_VIEW_Y_RANGE': 0.0,
            'DETECTION_VIEW_CENTER': 0,
            'DETECTION_VIEW_AUTO_START': True,
            'SLIDER_VIEW_Y_RANGE': 0.0,
            'SLIDER_VIEW_CENTER': 0,
            'SLIDER_VIEW_AUTO_START': True,
            'DENOISE_SHOW_ADVANCED': False,
            }
        _set_user_linewidth_scale(self.params.get('LINE_WIDTH_SCALE', 0.7))

        # Template banks (each can be loaded from one file or a folder)
        self.template_store = {
            'cs_templates': [],
            'ss_templates': [],
            'fs_cs': [],
            'fs_ss': [],
            'cs_sources': [],
            'ss_sources': [],
        }

        # Interactive selection state on main plot
        self.template_selection_active = False
        self._template_records = []
        self._label_drafts = {}
        self.template_selection_type = 'CS'
        self.template_selection_window_ms = 30.0
        self.template_selected_segments = {'CS': [], 'SS': []}
        self.template_selected_intervals_ms = {'CS': [], 'SS': []}
        self.btn_select_templates = None
        self.btn_abort_templates = None

        # Currently loaded data (for single-session views)
        self.data = None

        self._main_view_auto_start = True
        self._build_ui()
        self.detection_progress = QtWidgets.QProgressBar(self)
        self.detection_progress.setFixedWidth(230)
        self.detection_progress.setRange(0, 100)
        self.detection_progress.setValue(0)
        self.detection_progress.setFormat('Ready')
        self.statusBar().addWidget(self.detection_progress)
        self._default_settings_snapshot = self._current_settings_snapshot()

    def _build_ui(self):
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)

        # --- Upper block: Controls ---
        upper_layout = QtWidgets.QHBoxLayout()

        # Folder/session controls (compact folded list using QComboBox)
        btn_folder = QtWidgets.QPushButton('Select Folder')
        btn_folder.clicked.connect(self.select_folder)
        self.list_sessions = QtWidgets.QComboBox()
        self.list_sessions.setMinimumContentsLength(20)
        self.list_sessions.setSizeAdjustPolicy(QtWidgets.QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        # connect later; use currentIndexChanged without argument handling
        self.list_sessions.currentIndexChanged.connect(self.on_session_select)
        self.combo_cell = QtWidgets.QComboBox()
        self.combo_cell.currentIndexChanged.connect(self.on_cell_change)
        self.tabs_polarity = QtWidgets.QTabBar()
        self.tabs_polarity.addTab('Positive-going')
        self.tabs_polarity.addTab('Negative-going')
        self.tabs_polarity.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding,
                                        QtWidgets.QSizePolicy.Policy.Fixed)
        self.tabs_polarity.setDrawBase(False)
        self.tabs_polarity.setExpanding(True)
        self.tabs_polarity.setUsesScrollButtons(False)
        self.tabs_polarity.setElideMode(Qt.TextElideMode.ElideNone)
        self.tabs_polarity.setMinimumWidth(self.tabs_polarity.sizeHint().width())
        self.tabs_polarity.setFixedHeight(self.tabs_polarity.sizeHint().height())
        self.tabs_polarity.setToolTip('Spike direction, shared by threshold, template, Combo and batch detection. Raw traces retain recorded polarity.')
        self._sync_polarity_buttons()
        self.tabs_polarity.currentChanged.connect(lambda index: self.on_polarity_changed(index == 1))

        # Baseline correction controls

        self.combo_baseline_method = QtWidgets.QComboBox()
        self.combo_baseline_method.addItems(['Disable', 'Percentile', 'Median'])
        self.combo_baseline_method.setCurrentText(self.baseline_params['method'])
        self.combo_baseline_method.currentTextChanged.connect(self.on_baseline_param_change)
        self.spin_baseline_window = QtWidgets.QDoubleSpinBox(); self.spin_baseline_window.setRange(1.0, 1000.0); self.spin_baseline_window.setValue(self.baseline_params['window_ms'])
        self.spin_baseline_window.setSuffix(' ms')
        self.spin_baseline_window.valueChanged.connect(self.on_baseline_param_change)
        self.spin_baseline_percentile = QtWidgets.QDoubleSpinBox(); self.spin_baseline_percentile.setRange(0.0, 100.0); self.spin_baseline_percentile.setValue(self.baseline_params['percentile'])
        self.spin_baseline_percentile.setSuffix(' %')
        self.spin_baseline_percentile.valueChanged.connect(self.on_baseline_param_change)
        # Option to show baseline-corrected result (moved to full-width control row)
        self.chk_show_baseline = QtWidgets.QCheckBox('Baseline correction')
        self.chk_show_baseline.setChecked(False)
        self.chk_show_baseline.stateChanged.connect(self.update_plot)
        # Note: baseline / filter visualization checkboxes are placed
        # in the full-width control row below the separator (see controls_h)
        self.combo_frame_processing = QtWidgets.QComboBox()
        self.combo_frame_processing.addItem('Rolling average', 'Rolling average')
        self.combo_frame_processing.addItem('Mean', 'Downsampling frames')
        self._set_frame_processing_mode(self.params.get('FRAME_PROCESSING_MODE', 'Rolling average'))
        self.combo_frame_processing.currentTextChanged.connect(self.on_frame_processing_mode_changed)
        # Averaging (frames) applied to visualization and detection
        self.spin_avg_frames = QtWidgets.QSpinBox(); self.spin_avg_frames.setRange(0, 500); self.spin_avg_frames.setValue(0)
        self.spin_avg_frames.valueChanged.connect(self.update_plot)
        self.chk_denoise = QtWidgets.QCheckBox('Denoise')
        self.chk_denoise.setChecked(bool(self.params.get('DENOISE_ENABLED', False)))
        self.chk_denoise.stateChanged.connect(self.on_denoise_toggle)
        self.btn_denoise_settings = QtWidgets.QPushButton('Denoise settings')
        self.btn_denoise_settings.clicked.connect(self.open_denoising_settings)
        left_grid = QtWidgets.QGridLayout()
        left_grid.setContentsMargins(0, 0, 0, 0)
        left_grid.setHorizontalSpacing(10)
        left_grid.setVerticalSpacing(7)
        self.left_settings_grid = left_grid
        self.btn_select_folder = btn_folder
        left_grid.addWidget(btn_folder, 0, 0, 1, 2)
        self.list_sessions.setMinimumContentsLength(10)
        self.combo_cell.setMinimumContentsLength(10)
        self.combo_cell.setSizeAdjustPolicy(QtWidgets.QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        for row, label, widget in ((1, 'Session:', self.list_sessions),
                (2, 'Cell:', self.combo_cell),
                (4, 'Baseline correction:', self.combo_baseline_method),
                (5, 'Baseline window:', self.spin_baseline_window),
                (6, 'Percentile:', self.spin_baseline_percentile)):
            left_grid.addWidget(QtWidgets.QLabel(label), row, 0)
            left_grid.addWidget(widget, row, 1)
        left_grid.addWidget(self.tabs_polarity, 3, 0, 1, 2)
        frame_row = QtWidgets.QHBoxLayout()
        frame_row.setSpacing(6)
        frame_row.addWidget(self.combo_frame_processing, 1)
        self.spin_avg_frames.setFixedWidth(58)
        frame_row.addWidget(self.spin_avg_frames)
        left_grid.addWidget(QtWidgets.QLabel('Frame processing:'), 7, 0)
        left_grid.addLayout(frame_row, 7, 1)
        left_grid.addWidget(self.chk_denoise, 8, 0)
        left_grid.addWidget(self.btn_denoise_settings, 8, 1)
        left_grid.setColumnStretch(1, 1)
        # Raw trace visualization controls (grouped)
        vbox_right = QtWidgets.QVBoxLayout()
        vbox_right.setSpacing(2)
        # Title removed: separator provides sufficient visual grouping
        # Time slider + window controls replace start/end numeric boxes
        self.slider_time = QtWidgets.QSlider()
        self.slider_time.setOrientation(ORIENT_HORIZONTAL)
        self.slider_time.setMinimum(0)
        self.slider_time.setMaximum(1000)
        self.slider_time.setValue(0)
        self.slider_time.valueChanged.connect(self.on_slider_time_changed)
        self.spin_window = QtWidgets.QDoubleSpinBox(); self.spin_window.setRange(1.0, 1e6); self.spin_window.setValue(1000.0)
        self.spin_window.setSuffix(' ms')
        self.spin_window.valueChanged.connect(self.on_window_changed)
        # Note: time/window/Y-range controls are placed in a dedicated full-width
        # control row below the upper settings (see main layout), not inside
        # the right-side column. Keep widgets created here but do not add them
        # to this column to avoid duplicates.
        self.spin_zoom = QtWidgets.QDoubleSpinBox(); self.spin_zoom.setRange(0.0, 1e6); self.spin_zoom.setValue(0.0)
        self.spin_zoom.valueChanged.connect(self.update_plot)
        # Visualization checkboxes (created here so they exist when placed in control row)
        self.chk_show_cs = QtWidgets.QCheckBox('CS filter')
        self.chk_show_cs.setChecked(False)
        self.chk_show_cs.toggled.connect(self._on_chk_cs_toggled)
        self.chk_show_ss = QtWidgets.QCheckBox('SS filter')
        self.chk_show_ss.setChecked(False)
        self.chk_show_ss.toggled.connect(self._on_chk_ss_toggled)
        # Detection controls (CS/SS) added into main window (third column)
        vbox_right.addWidget(QtWidgets.QLabel('CS / SS Detection Settings'))
        self.spin_cs_low = QtWidgets.QDoubleSpinBox(); self.spin_cs_low.setRange(0.0, 5000.0); self.spin_cs_low.setValue(self.params.get('CS_LOW_CUT_HZ',0.0))
        self.spin_cs_low.valueChanged.connect(lambda v: (self.params.update({'CS_LOW_CUT_HZ': float(v)}), self.update_plot()))
        vbox_right.addWidget(QtWidgets.QLabel('CS low cut (Hz):'))
        vbox_right.addWidget(self.spin_cs_low)
        self.spin_cs_high = QtWidgets.QDoubleSpinBox(); self.spin_cs_high.setRange(0.0, 5000.0); self.spin_cs_high.setValue(self.params.get('CS_HIGH_CUT_HZ',150.0))
        self.spin_cs_high.valueChanged.connect(lambda v: (self.params.update({'CS_HIGH_CUT_HZ': float(v)}), self.update_plot()))
        vbox_right.addWidget(QtWidgets.QLabel('CS high cut (Hz):'))
        vbox_right.addWidget(self.spin_cs_high)
        self.spin_cs_thresh = QtWidgets.QDoubleSpinBox(); self.spin_cs_thresh.setRange(0.0,50.0); self.spin_cs_thresh.setDecimals(3); self.spin_cs_thresh.setSingleStep(0.05); self.spin_cs_thresh.setValue(self.params.get('CS_THRESHOLD_SIGMA',6.0))
        self.spin_cs_thresh.valueChanged.connect(lambda v: (self.params.update({'CS_THRESHOLD_SIGMA': float(v)}), self.update_plot()))
        vbox_right.addWidget(QtWidgets.QLabel('CS threshold (σ):'))
        vbox_right.addWidget(self.spin_cs_thresh)
        # CS filter order (default 4)
        self.spin_cs_order = QtWidgets.QSpinBox(); self.spin_cs_order.setRange(1, 8); self.spin_cs_order.setValue(self.params.get('CS_FILTER_ORDER', 4))
        self.spin_cs_order.valueChanged.connect(lambda v: (self.params.update({'CS_FILTER_ORDER': int(v)}), self.update_plot()))
        h_cs_order_init = QtWidgets.QHBoxLayout()
        h_cs_order_init.addWidget(QtWidgets.QLabel('CS filter order:'))
        h_cs_order_init.addWidget(self.spin_cs_order)
        vbox_right.addLayout(h_cs_order_init)
        # CS min dist moved to Advanced Settings (SettingsDialog)

        self.spin_ss_low = QtWidgets.QDoubleSpinBox(); self.spin_ss_low.setRange(0.0,5000.0); self.spin_ss_low.setValue(self.params.get('SS_LOW_CUT_HZ',0.0))
        self.spin_ss_low.valueChanged.connect(lambda v: (self.params.update({'SS_LOW_CUT_HZ': float(v)}), self.update_plot()))
        vbox_right.addWidget(QtWidgets.QLabel('SS low cut (Hz):'))
        vbox_right.addWidget(self.spin_ss_low)
        self.spin_ss_high = QtWidgets.QDoubleSpinBox(); self.spin_ss_high.setRange(0.0,5000.0); self.spin_ss_high.setValue(self.params.get('SS_HIGH_CUT_HZ',0.0))
        self.spin_ss_high.valueChanged.connect(lambda v: (self.params.update({'SS_HIGH_CUT_HZ': float(v)}), self.update_plot()))
        vbox_right.addWidget(QtWidgets.QLabel('SS high cut (Hz):'))
        vbox_right.addWidget(self.spin_ss_high)
        self.spin_ss_thresh = QtWidgets.QDoubleSpinBox(); self.spin_ss_thresh.setRange(0.0,50.0); self.spin_ss_thresh.setDecimals(3); self.spin_ss_thresh.setSingleStep(0.05); self.spin_ss_thresh.setValue(self.params.get('SS_THRESHOLD_SIGMA',3.0))
        self.spin_ss_thresh.valueChanged.connect(lambda v: (self.params.update({'SS_THRESHOLD_SIGMA': float(v)}), self.update_plot()))
        vbox_right.addWidget(QtWidgets.QLabel('SS threshold (σ):'))
        vbox_right.addWidget(self.spin_ss_thresh)
        # SS filter order (applies to both HP and LP in SS bandpass)
        self.spin_ss_order = QtWidgets.QSpinBox(); self.spin_ss_order.setRange(1, 8); self.spin_ss_order.setValue(self.params.get('SS_FILTER_ORDER', 4))
        self.spin_ss_order.valueChanged.connect(lambda v: (self.params.update({'SS_FILTER_ORDER': int(v)}), self.update_plot()))
        h_ss_order_init = QtWidgets.QHBoxLayout()
        h_ss_order_init.addWidget(QtWidgets.QLabel('SS filter order:'))
        h_ss_order_init.addWidget(self.spin_ss_order)
        vbox_right.addLayout(h_ss_order_init)
        self.spin_ss_blank = QtWidgets.QDoubleSpinBox(); self.spin_ss_blank.setRange(0.0,1000.0); self.spin_ss_blank.setValue(self.params.get('SS_BLANK_MS',18.0))
        self.spin_ss_blank.valueChanged.connect(lambda v: (self.params.update({'SS_BLANK_MS': float(v)}), self.update_plot()))
        # Trace detection button
        btn_detect = QtWidgets.QPushButton('Spike Detection')
        btn_detect.clicked.connect(self.open_detection_settings_dialog)
        btn_batch = QtWidgets.QPushButton('Batch detection')
        btn_batch.clicked.connect(self.open_batch_detection)
        # create Spike Stats button here so we can place them side-by-side later
        btn_stats = QtWidgets.QPushButton('Spike Statistics')
        btn_stats.clicked.connect(self.open_stats_viewer)
        try:
            equal_btn_w = max(int(btn_batch.sizeHint().width()), int(btn_stats.sizeHint().width()))
            btn_batch.setMinimumWidth(equal_btn_w)
            btn_stats.setMinimumWidth(equal_btn_w)
        except Exception:
            pass
        # add detect button to the right-side vbox for initial layout; it will be
        # reparented into the column layout when arranged below
        vbox_right.addWidget(btn_detect)
        vbox_right.addWidget(QtWidgets.QLabel('Info:'))
        self.text_stats = QtWidgets.QTextEdit()
        self.text_stats.setReadOnly(True)
        self.text_stats.setMaximumHeight(160)
        vbox_right.addWidget(self.text_stats)
        # upper_layout.addLayout(vbox_right)

        # The preprocessing panel keeps its natural width; detection and Info share extra space.
        upper_panel = QtWidgets.QWidget()
        upper_h = QtWidgets.QHBoxLayout()
        upper_h.setSpacing(4)
        upper_h.setContentsMargins(2, 2, 2, 2)
        col1 = QtWidgets.QVBoxLayout(); col2 = QtWidgets.QVBoxLayout(); col3 = QtWidgets.QVBoxLayout()
        col1.setSpacing(5); col2.setSpacing(6); col3.setSpacing(5)
        for column in (col1, col2, col3):
            column.setAlignment(ALIGN_TOP)
        col1.setContentsMargins(2,1,2,1); col2.setContentsMargins(2,1,2,1); col3.setContentsMargins(2,1,2,1)
        col1.addLayout(left_grid)
        raw_group = QtWidgets.QVBoxLayout()
        # increase internal spacing by ~30% for clearer separation
        raw_group.setSpacing(4)
        # explicit time controls row (center slider + window)
        h_time_local = QtWidgets.QHBoxLayout()
        lbl_center = QtWidgets.QLabel('Center:')
        h_time_local.addWidget(lbl_center)
        h_time_local.addWidget(self.slider_time)
        lbl_window = QtWidgets.QLabel('Window:')
        h_time_local.addWidget(lbl_window)
        h_time_local.addWidget(self.spin_window)
        # slightly more space between time controls (~30% more)
        h_time_local.setSpacing(3)
        # Note: per-user request, the center/window/Y-range controls are moved
        # into a single full-width control row below the upper panel. Do not
        # add them again here to avoid duplicate controls.
        col1.addLayout(raw_group)

        # Column 2: spike detection controls
        self.tabs_detection = DetectionTabs()
        self.tabs_detection.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding, QtWidgets.QSizePolicy.Policy.Maximum)
        self.chk_combo = QtWidgets.QCheckBox('Combo')
        self.chk_combo.setChecked(bool(self.params.get('COMBO_DETECTION', False)))
        self.chk_combo.toggled.connect(self.on_combo_changed)
        self.tabs_detection.setCornerWidget(self.chk_combo, Qt.Corner.TopRightCorner)

        # Threshold tab
        tab_threshold = QtWidgets.QWidget()
        lay_threshold = QtWidgets.QVBoxLayout()
        lay_threshold.setContentsMargins(8, 6, 8, 6)
        lay_threshold.setSpacing(5)
        lay_threshold.setAlignment(ALIGN_TOP)
        self.threshold_groups = {}
        for kind in ('CS', 'SS'):
            group = QtWidgets.QGroupBox(kind)
            grid = QtWidgets.QGridLayout(group)
            grid.setContentsMargins(8, 4, 8, 6)
            grid.setHorizontalSpacing(10)
            grid.setVerticalSpacing(5)
            prefix = kind.lower()
            threshold_label = QtWidgets.QLabel('Threshold (σ):')
            setattr(self, f'lbl_{prefix}_threshold', threshold_label)
            for label, widget, row, column in (
                (QtWidgets.QLabel('High-pass (Hz):'), getattr(self, f'spin_{prefix}_low'), 0, 0),
                (QtWidgets.QLabel('Low-pass (Hz):'), getattr(self, f'spin_{prefix}_high'), 0, 2),
                (QtWidgets.QLabel('Filter order:'), getattr(self, f'spin_{prefix}_order'), 1, 0),
                (threshold_label, getattr(self, f'spin_{prefix}_thresh'), 1, 2),
            ):
                grid.addWidget(label, row, column)
                widget.setMinimumWidth(65)
                grid.addWidget(widget, row, column + 1)
            for attr in (f'spin_{prefix}_low', f'spin_{prefix}_high'):
                getattr(self, attr).setSpecialValueText('')
            grid.setColumnStretch(1, 1)
            grid.setColumnStretch(3, 1)
            self.threshold_groups[kind] = group
            lay_threshold.addWidget(group)
        h_local_bl = QtWidgets.QHBoxLayout()
        self.chk_local_baseline = QtWidgets.QCheckBox('Local noise')
        self.chk_local_baseline.setChecked(bool(self.params.get('LOCAL_BASELINE', False)))
        self.chk_local_baseline.stateChanged.connect(lambda v: (self.params.update({'LOCAL_BASELINE': bool(v)}), self.update_plot()))
        h_local_bl.addWidget(self.chk_local_baseline)
        h_local_bl.addSpacing(6)
        h_local_bl.addWidget(QtWidgets.QLabel('SS win (ms):'))
        self.spin_local_ss_ms = QtWidgets.QDoubleSpinBox()
        self.spin_local_ss_ms.setRange(5.0, 5000.0)
        self.spin_local_ss_ms.setDecimals(1)
        self.spin_local_ss_ms.setSingleStep(10.0)
        self.spin_local_ss_ms.setValue(self.params.get('LOCAL_BASELINE_SS_MS', 50.0))
        self.spin_local_ss_ms.valueChanged.connect(lambda v: (self.params.update({'LOCAL_BASELINE_SS_MS': float(v)}), self.update_plot()))
        h_local_bl.addWidget(self.spin_local_ss_ms)
        h_local_bl.addWidget(QtWidgets.QLabel('CS win (ms):'))
        self.spin_local_cs_ms = QtWidgets.QDoubleSpinBox()
        self.spin_local_cs_ms.setRange(5.0, 5000.0)
        self.spin_local_cs_ms.setDecimals(1)
        self.spin_local_cs_ms.setSingleStep(10.0)
        self.spin_local_cs_ms.setValue(self.params.get('LOCAL_BASELINE_CS_MS', 200.0))
        self.spin_local_cs_ms.valueChanged.connect(lambda v: (self.params.update({'LOCAL_BASELINE_CS_MS': float(v)}), self.update_plot()))
        h_local_bl.addWidget(self.spin_local_cs_ms)
        lay_threshold.addLayout(h_local_bl)
        tab_threshold.setLayout(lay_threshold)

        # Template matching tab
        tab_template = QtWidgets.QWidget()
        lay_template = QtWidgets.QVBoxLayout()
        lay_template.setContentsMargins(8, 6, 8, 6)
        lay_template.setSpacing(6)
        lay_template.setAlignment(ALIGN_TOP)
        btn_load_cs = QtWidgets.QPushButton('Load CS templates')
        btn_load_ss = QtWidgets.QPushButton('Load SS templates')
        btn_clear_templates = QtWidgets.QPushButton('Clear')
        btn_clear_templates.setToolTip('Clear both CS and SS template banks.')
        btn_view_tpl = QtWidgets.QPushButton('View')
        btn_load_cs.clicked.connect(lambda: self.load_templates_for_type('CS'))
        btn_load_ss.clicked.connect(lambda: self.load_templates_for_type('SS'))
        btn_clear_templates.clicked.connect(self.clear_templates)
        btn_view_tpl.clicked.connect(self.open_template_viewer)
        h_tpl_load = QtWidgets.QHBoxLayout()
        h_tpl_load.addWidget(btn_load_cs)
        h_tpl_load.addWidget(btn_load_ss)
        h_tpl_load.addWidget(btn_clear_templates)
        h_tpl_load.addWidget(btn_view_tpl)
        lay_template.addLayout(h_tpl_load)
        h_tpl_parallel = QtWidgets.QHBoxLayout()
        self.chk_template_parallel = QtWidgets.QCheckBox('Parallel')
        self.chk_template_parallel.setChecked(bool(self.params.get('TEMPLATE_PARALLEL', False)))
        self.chk_template_parallel.stateChanged.connect(self.on_template_controls_changed)
        h_tpl_parallel.addWidget(self.chk_template_parallel)
        h_tpl_parallel.addSpacing(6)
        h_tpl_parallel.addWidget(QtWidgets.QLabel('Shape groups:'))
        self.spin_template_groups = QtWidgets.QSpinBox()
        self.spin_template_groups.setRange(1, 8)
        self.spin_template_groups.setValue(int(self.params.get('TEMPLATE_PARALLEL_GROUPS', 3)))
        self.spin_template_groups.setToolTip('Number of CS/SS template groups. Use View to enable individual groups.')
        self.spin_template_groups.valueChanged.connect(self.on_parallel_groups_changed)
        h_tpl_parallel.addWidget(self.spin_template_groups)
        self.chk_template_whitening = QtWidgets.QCheckBox('Whiten noise')
        self.chk_template_whitening.setChecked(bool(self.params.get('TEMPLATE_WHITENING', False)))
        self.chk_template_whitening.stateChanged.connect(self.on_template_controls_changed)
        h_tpl_parallel.addSpacing(12)
        h_tpl_parallel.addWidget(self.chk_template_whitening)
        h_tpl_parallel.addStretch(1)
        lay_template.addLayout(h_tpl_parallel)
        self.lbl_template_status = QtWidgets.QLabel('Templates: CS [0] from 0 source(s), SS [0] from 0 source(s)')
        self.lbl_template_status.setWordWrap(True)
        lay_template.addWidget(self.lbl_template_status)

        h_tmode = QtWidgets.QHBoxLayout()
        h_tmode.addWidget(QtWidgets.QLabel('Matching score:'))
        self.combo_template_method = QtWidgets.QComboBox()
        self.combo_template_method.addItem('Amplitude-fit LLR (Gaussian)', 'LLR Probability Vector')
        self.combo_template_method.addItem('Positive-core LLR (experimental)', 'Burst-aware LLR')
        self.combo_template_method.addItem('Normalized Similarity', 'Normalized Similarity')
        self.combo_template_method.setCurrentIndex(max(0, self.combo_template_method.findData(
            str(self.params.get('TEMPLATE_MATCH_METHOD', 'LLR Probability Vector')))))
        self.combo_template_method.currentTextChanged.connect(self.on_template_controls_changed)
        h_tmode.addWidget(self.combo_template_method)
        lay_template.addLayout(h_tmode)

        h_cs_sigma = QtWidgets.QHBoxLayout()
        self.lbl_template_cs_sigma = QtWidgets.QLabel('CS match response / noise MAD:')
        h_cs_sigma.addWidget(self.lbl_template_cs_sigma)
        self.spin_template_cs_sigma = QtWidgets.QDoubleSpinBox(); self.spin_template_cs_sigma.setRange(0.1, 100.0); self.spin_template_cs_sigma.setDecimals(3); self.spin_template_cs_sigma.setSingleStep(0.1); self.spin_template_cs_sigma.setValue(float(self.params.get('TEMPLATE_CS_SIGMA', 30.0)))
        self.spin_template_cs_sigma.setToolTip('LLR mode: positive template projection divided by the filtered trace’s unmasked per-sample MAD. Score line is cutoff² / 2; this is not a calibrated false-positive z-score.')
        self.spin_template_cs_sigma.valueChanged.connect(self.on_template_controls_changed)
        h_cs_sigma.addWidget(self.spin_template_cs_sigma)
        lay_template.addLayout(h_cs_sigma)

        h_ss_sigma = QtWidgets.QHBoxLayout()
        self.lbl_template_ss_sigma = QtWidgets.QLabel('SS match response / noise MAD:')
        h_ss_sigma.addWidget(self.lbl_template_ss_sigma)
        self.spin_template_ss_sigma = QtWidgets.QDoubleSpinBox(); self.spin_template_ss_sigma.setRange(0.1, 100.0); self.spin_template_ss_sigma.setDecimals(3); self.spin_template_ss_sigma.setSingleStep(0.1); self.spin_template_ss_sigma.setValue(float(self.params.get('TEMPLATE_SS_SIGMA', 5.0)))
        self.spin_template_ss_sigma.setToolTip('LLR mode: positive 3 ms template-core projection divided by the filtered trace’s unmasked per-sample MAD. This is not a calibrated false-positive z-score.')
        self.spin_template_ss_sigma.valueChanged.connect(self.on_template_controls_changed)
        h_ss_sigma.addWidget(self.spin_template_ss_sigma)
        lay_template.addLayout(h_ss_sigma)

        h_cs_sim = QtWidgets.QHBoxLayout()
        self.lbl_template_cs_sim = QtWidgets.QLabel('CS similarity (Pearson r):')
        h_cs_sim.addWidget(self.lbl_template_cs_sim)
        self.spin_template_cs_sim = QtWidgets.QDoubleSpinBox(); self.spin_template_cs_sim.setRange(0.01, 1.0); self.spin_template_cs_sim.setDecimals(2); self.spin_template_cs_sim.setSingleStep(0.05); self.spin_template_cs_sim.setValue(float(self.params.get('TEMPLATE_CS_SIMILARITY', 0.90)))
        self.spin_template_cs_sim.valueChanged.connect(self.on_template_controls_changed)
        h_cs_sim.addWidget(self.spin_template_cs_sim)
        lay_template.addLayout(h_cs_sim)

        h_ss_sim = QtWidgets.QHBoxLayout()
        self.lbl_template_ss_sim = QtWidgets.QLabel('SS similarity (Pearson r):')
        h_ss_sim.addWidget(self.lbl_template_ss_sim)
        self.spin_template_ss_sim = QtWidgets.QDoubleSpinBox(); self.spin_template_ss_sim.setRange(0.01, 1.0); self.spin_template_ss_sim.setDecimals(2); self.spin_template_ss_sim.setSingleStep(0.05); self.spin_template_ss_sim.setValue(float(self.params.get('TEMPLATE_SS_SIMILARITY', 0.80)))
        self.spin_template_ss_sim.valueChanged.connect(self.on_template_controls_changed)
        h_ss_sim.addWidget(self.spin_template_ss_sim)
        lay_template.addLayout(h_ss_sim)

        h_lowpass = QtWidgets.QHBoxLayout()
        h_lowpass.addWidget(QtWidgets.QLabel('SS matching low-pass (Hz):'))
        self.spin_template_lowpass = QtWidgets.QDoubleSpinBox(); self.spin_template_lowpass.setRange(0.0, 5000.0); self.spin_template_lowpass.setDecimals(0); self.spin_template_lowpass.setSingleStep(50.0); self.spin_template_lowpass.setValue(float(self.params.get('TEMPLATE_SS_LOWPASS_HZ', 700.0)))
        self.spin_template_lowpass.valueChanged.connect(self.on_template_controls_changed)
        h_lowpass.addWidget(self.spin_template_lowpass)
        lay_template.addLayout(h_lowpass)

        tab_template.setLayout(lay_template)

        self.tabs_detection.addTab(tab_threshold, 'Threshold')
        self.tabs_detection.addTab(tab_template, 'Template Matching')
        self.tabs_detection.currentChanged.connect(self.on_detection_tab_changed)
        try:
            default_idx = 1 if self.params.get('DETECTION_METHOD', 'Threshold') == 'Template Matching' else 0
            self.tabs_detection.setCurrentIndex(default_idx)
            self.on_detection_tab_changed(default_idx)
        except Exception:
            pass
        col2.addWidget(self.tabs_detection)

        self.group_spike_qc = QtWidgets.QGroupBox('Spike QC')
        qc_grid = QtWidgets.QGridLayout(self.group_spike_qc)
        qc_grid.setContentsMargins(10, 6, 10, 8)
        qc_grid.setHorizontalSpacing(8)
        qc_grid.setVerticalSpacing(5)
        self.qc_inputs = {}
        for row, kind in enumerate(('CS', 'SS')):
            qc_grid.addWidget(QtWidgets.QLabel(kind), row, 0)
            for col, (suffix, label) in enumerate((('MIN_AMPLITUDE_SNR', 'Min SNR'),
                    ('MIN_FWHM_MS', 'Min FWHM'), ('MAX_FWHM_MS', 'Max FWHM'))):
                key = f'{kind}_{suffix}'
                spin = QtWidgets.QDoubleSpinBox()
                spin.setRange(0, 1000)
                spin.setDecimals(1)
                spin.setFixedWidth(62 if suffix == 'MIN_AMPLITUDE_SNR' else 76)
                spin.setSingleStep(0.1)
                spin.setValue(self.params[key])
                if suffix.endswith('_MS'):
                    spin.setSuffix(' ms')
                    description = ('Minimum' if suffix.startswith('MIN') else 'Maximum') + f' {kind} FWHM on the filtered detection trace before whitening. 0 disables this limit. Unmeasurable widths are retained and flagged.'
                else:
                    description = f'Minimum {kind} amplitude SNR on the original frame-processed, baseline-corrected trace before denoising/filtering/whitening: candidate height above −25…−5 ms baseline / Gaussian-scaled noise MAD from −150…−5 ms, excluding candidate spikes. 0 disables; unavailable SNR is rejected when enabled.'
                _set_input_tooltip(spin, description)
                spin.valueChanged.connect(lambda value, name=key: self.params.__setitem__(name, float(value)))
                self.qc_inputs[key] = spin
                qc_grid.addWidget(QtWidgets.QLabel(label), row, 1 + col * 2)
                qc_grid.addWidget(spin, row, 2 + col * 2)
        col2.addWidget(self.group_spike_qc)

        # place Spike Detection and Spike Stats side-by-side with equal stretch
        h_detect = QtWidgets.QVBoxLayout()
        try:
            btn_detect.setSizePolicy(QtWidgets.QSizePolicy(SIZEPOLICY_EXPANDING, SIZEPOLICY_FIXED))
        except Exception:
            try:
                btn_detect.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
            except Exception:
                pass
        try:
            btn_stats.setSizePolicy(QtWidgets.QSizePolicy(SIZEPOLICY_EXPANDING, SIZEPOLICY_FIXED))
        except Exception:
            try:
                btn_stats.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
            except Exception:
                pass
        try:
            btn_batch.setSizePolicy(QtWidgets.QSizePolicy(SIZEPOLICY_EXPANDING, SIZEPOLICY_FIXED))
        except Exception:
            try:
                btn_batch.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
            except Exception:
                pass
        h_detect_top = QtWidgets.QHBoxLayout()
        h_detect_top.addWidget(btn_detect)
        self.chk_detection_save = QtWidgets.QCheckBox('Save')
        self.chk_detection_save.setChecked(bool(self.params.get('SAVE_DETECTION_RESULTS', False)))
        self.chk_detection_save.stateChanged.connect(
            lambda _v: self.params.__setitem__('SAVE_DETECTION_RESULTS', bool(self.chk_detection_save.isChecked()))
        )
        self.chk_detection_save.setToolTip(
            'Unchecked: temporary viewing exports only, removed when the GUI closes.\n'
            'Checked: save results in the data folder; ask before replacing old detections.'
        )
        h_detect_top.addWidget(self.chk_detection_save)
        h_detect.addLayout(h_detect_top)
        h_detect.setSpacing(5)
        h_batch_stats = QtWidgets.QHBoxLayout()
        h_batch_stats.addWidget(btn_batch, 1)
        h_batch_stats.addWidget(btn_stats, 1)
        h_detect.addLayout(h_batch_stats)

        # Column 3: advanced settings and info panel
        col3.addLayout(h_detect)
        col3.addSpacing(6)
        h_cfg = QtWidgets.QHBoxLayout()
        btn_load_cfg = QtWidgets.QPushButton('Load Settings')
        self.btn_load_session = QtWidgets.QPushButton('Load Session')
        self.btn_load_session.clicked.connect(self.open_saved_session)
        self.btn_load_session.setToolTip('Open saved detections from a recording folder or its spike_detection subfolder, restoring each session’s settings and recorded traces without rerunning detection.')
        btn_save_cfg = QtWidgets.QPushButton('Save Settings')
        btn_load_cfg.clicked.connect(self.load_all_settings)
        btn_save_cfg.clicked.connect(self.save_all_settings)
        h_cfg.addWidget(btn_load_cfg)
        h_cfg.addWidget(self.btn_load_session)
        col3.addLayout(h_cfg)
        # Color scheme is accessible from Advanced Settings (no separate main button)
        # settings + reset on one line
        btn_settings = QtWidgets.QPushButton('Advanced Settings')
        btn_settings.clicked.connect(self.open_settings)
        h_adv = QtWidgets.QHBoxLayout()
        h_adv.addWidget(btn_settings)
        h_adv.addWidget(btn_save_cfg)
        col3.addLayout(h_adv)
        col3.addWidget(QtWidgets.QLabel('Info:'))
        col3.addWidget(self.text_stats)

        # Keep the left panel compact and let the other columns absorb extra width.
        self.left_settings_panel = QtWidgets.QWidget()
        self.left_settings_panel.setLayout(col1)
        self.left_settings_panel.setSizePolicy(QtWidgets.QSizePolicy.Policy.Maximum, QtWidgets.QSizePolicy.Policy.Maximum)
        upper_h.addWidget(self.left_settings_panel, 0, ALIGN_TOP)
        upper_h.addLayout(col2, 4)
        upper_h.addLayout(col3, 3)
        upper_panel.setLayout(upper_h)
        upper_panel.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding, QtWidgets.QSizePolicy.Policy.Maximum)
        self.upper_panel = upper_panel
        # (do not cap upper panel height) place wrapper
        upper_layout_wrapper = upper_panel
        upper_layout.addWidget(upper_layout_wrapper)
        # --- Lower block: Visualization ---
        # make initial plot slightly shorter vertically (~20% shorter)
        self.canvas = PlotCanvas(self, width=10, height=3.2, dpi=100)

        # Main vertical layout with three stacked rows:
        # 1) upper settings (columns)
        # 2) narrow full-width control row (time slider, window, Y-range, save)
        # 3) large canvas for plotting
        main_layout = QtWidgets.QVBoxLayout()
        main_layout.setSpacing(6)
        main_layout.setContentsMargins(4,4,4,4)
        # Add upper settings panel (keeps previous 3-column layout)
        main_layout.addLayout(upper_layout, 0)

        # Create narrow full-width control row
        # add a thin separator line between the top three-column panel and this control row
        sep = QtWidgets.QFrame()
        _set_frame_hline(sep)
        try:
            sep.setFrameShadow(QtWidgets.QFrame.Sunken)
        except Exception:
            try:
                sep.setFrameShadow(QtWidgets.QFrame.FrameShadow.Sunken)
            except Exception:
                pass
        sep.setFixedHeight(2)
        main_layout.addWidget(sep)

        controls_widget = QtWidgets.QWidget()
        controls_h = QtWidgets.QHBoxLayout()
        controls_h.setContentsMargins(2,2,2,2)
        controls_h.addWidget(QtWidgets.QLabel('Center:'))
        controls_h.addWidget(self.slider_time)
        controls_h.addWidget(QtWidgets.QLabel('Window:'))
        controls_h.addWidget(self.spin_window)
        # (Baseline checkbox is placed in the middle panel; do not add here)
        controls_h.addWidget(QtWidgets.QLabel('Y-Range:'))
        controls_h.addWidget(self.spin_zoom)
        # Visualization toggles (Baseline, CS filter, SS filter)
        # Baseline checkbox (moved here from middle panel)
        controls_h.addSpacing(6)
        controls_h.addWidget(self.chk_show_baseline)
        # CS/SS filter checkboxes (mutually exclusive)
        controls_h.addWidget(self.chk_show_cs)
        controls_h.addWidget(self.chk_show_ss)
        self.btn_select_templates = QtWidgets.QPushButton('Select As')
        self.btn_select_templates.clicked.connect(self.toggle_template_selection_or_save)
        self.btn_select_templates.setToolTip('Select CS/SS template windows or manually label spikes across cells and sessions. Left click adds; right click removes. In label mode, Control + left click adds CS.')
        controls_h.addWidget(self.btn_select_templates)
        self.btn_abort_templates = QtWidgets.QPushButton('Abort')
        self.btn_abort_templates.clicked.connect(self.abort_template_selection)
        self.btn_abort_templates.setEnabled(False)
        controls_h.addWidget(self.btn_abort_templates)
        # Save Figure button (SVG/PNG/JPG)
        btn_save_fig = QtWidgets.QPushButton('Save Figure')
        btn_save_fig.clicked.connect(self.export_figure)
        controls_h.addStretch(1)
        controls_h.addWidget(btn_save_fig)
        controls_widget.setLayout(controls_h)
        # keep the controls row narrow
        controls_widget.setFixedHeight(52)
        main_layout.addWidget(controls_widget, 0)

        # Add canvas as the large plotting area
        main_layout.addWidget(self.canvas, 1)
        central.setLayout(main_layout)
        _apply_setting_tooltips(self)

        try:
            self.canvas.mpl_connect('button_press_event', self.on_main_plot_click)
        except Exception:
            pass

        # Hide irrelevant controls for baseline method
        self.on_baseline_param_change()
        self.on_template_controls_changed()
        self.on_combo_changed(self.chk_combo.isChecked())
        self.update_template_status_label()
        self.on_denoise_toggle()

    def _sync_polarity_buttons(self):
        negative = bool(self.params.get('NEGATIVE_GOING', True))
        self.tabs_polarity.blockSignals(True)
        self.tabs_polarity.setCurrentIndex(int(negative))
        self.tabs_polarity.blockSignals(False)

    def _restore_qc_controls(self, params):
        for key, spin in self.qc_inputs.items():
            spin.blockSignals(True)
            spin.setValue(float(params.get(key, QC_DEFAULTS[key])))
            spin.blockSignals(False)

    def on_polarity_changed(self, negative):
        self.params['NEGATIVE_GOING'] = bool(negative)
        self._sync_polarity_buttons()
        self._denoise_cache.clear()
        self.update_plot()

    def on_detection_tab_changed(self, idx):
        try:
            txt = self.tabs_detection.tabText(int(idx))
        except Exception:
            txt = 'Threshold'
        self.params['DETECTION_METHOD'] = 'Template Matching' if 'Template' in str(txt) else 'Threshold'
        self.tabs_detection.updateGeometry()
        if hasattr(self, 'upper_panel'):
            self.upper_panel.updateGeometry()

    def on_combo_changed(self, checked):
        self.params['COMBO_DETECTION'] = bool(checked)
        for kind, label in (('CS', self.lbl_cs_threshold), ('SS', self.lbl_ss_threshold)):
            label.setText('Seed (σ):' if checked else 'Threshold (σ):')

    def on_template_controls_changed(self):
        try:
            method = str(self.combo_template_method.currentData())
            self.params['TEMPLATE_MATCH_METHOD'] = method
            self.params['TEMPLATE_PARALLEL'] = bool(self.chk_template_parallel.isChecked()) if hasattr(self, 'chk_template_parallel') else False
            self.params['TEMPLATE_WHITENING'] = bool(self.chk_template_whitening.isChecked())
            self.params['TEMPLATE_PARALLEL_GROUPS'] = int(self.spin_template_groups.value())
            self.params['TEMPLATE_CS_SIGMA'] = float(self.spin_template_cs_sigma.value())
            self.params['TEMPLATE_SS_SIGMA'] = float(self.spin_template_ss_sigma.value())
            self.params['TEMPLATE_CS_SIMILARITY'] = float(self.spin_template_cs_sim.value())
            self.params['TEMPLATE_SS_SIMILARITY'] = float(self.spin_template_ss_sim.value())
            self.params['TEMPLATE_SS_LOWPASS_HZ'] = float(self.spin_template_lowpass.value())
            llr = method != 'Normalized Similarity'
            for widget in (self.lbl_template_cs_sigma, self.spin_template_cs_sigma,
                           self.lbl_template_ss_sigma, self.spin_template_ss_sigma):
                widget.setVisible(llr)
            for widget in (self.lbl_template_cs_sim, self.spin_template_cs_sim,
                           self.lbl_template_ss_sim, self.spin_template_ss_sim):
                widget.setVisible(not llr)
        except Exception:
            pass

    def on_parallel_groups_changed(self):
        self.params['TEMPLATE_PARALLEL_GROUPS'] = int(self.spin_template_groups.value())
        self.params['TEMPLATE_CS_SELECTED_GROUPS'] = None
        self.params['TEMPLATE_SS_SELECTED_GROUPS'] = None

    def open_batch_detection(self):
        BatchDetectionDialog(self).exec()

    def load_batch_folders(self, folders):
        """Load top-level sessions with identities unique across all selected paths."""
        from .utils.batch import discover_batch_sessions
        paths, names, loaded, issues, folders = discover_batch_sessions(
            folders, default_fs=float(self.params.get('FS', 1000.0)), time_unit='auto')
        self.batch_load_issues = issues
        if not paths:
            raise ValueError(f'No valid sessions found in {len(folders)} folder(s). Check the paths and details below.')
        self.batch_folders = folders
        self.master_folder = folders[0]
        self.sessions, self.session_names, self.loaded_sessions = paths, names, loaded
        self._denoise_cache.clear()
        self.list_sessions.blockSignals(True)
        self.list_sessions.clear()
        self.list_sessions.addItems(names)
        self.list_sessions.setCurrentIndex(0)
        self.list_sessions.blockSignals(False)
        self.on_session_select(0)
        self.text_stats.setPlainText(
            f'Loaded {len(folders)} paths, {len(paths)} sessions.\n' + '\n'.join(issues))

    def update_template_status_label(self):
        if getattr(self, 'lbl_template_status', None) is None:
            return
        cs_n = len(self.template_store.get('cs_templates', []))
        ss_n = len(self.template_store.get('ss_templates', []))
        cs_src = len(self.template_store.get('cs_sources', []))
        ss_src = len(self.template_store.get('ss_sources', []))
        info = f"CS [{cs_n}] from {cs_src} source(s), SS [{ss_n}] from {ss_src} source(s)"
        self.lbl_template_status.setText(info)

    def _read_template_npz(self, npz_path):
        out = {'cs_list': [], 'ss_list': [], 'fs_cs_list': [], 'fs_ss_list': []}
        try:
            d = np.load(npz_path, allow_pickle=True)
        except Exception:
            return out

        try:
            fs_default = float(d['fs']) if 'fs' in d else None
        except Exception:
            fs_default = None

        def _append_template(key_arr, key_fs, out_arr, out_fs):
            try:
                raw_arr = d[key_arr]
            except Exception:
                return
            local_fs = None
            try:
                local_fs = float(d[key_fs]) if key_fs in d else fs_default
            except Exception:
                local_fs = fs_default
            try:
                arr = np.asarray(raw_arr)
                if arr.dtype == object:
                    rows = [np.asarray(r, dtype=float).ravel() for r in list(arr)]
                elif arr.ndim == 1:
                    rows = [np.asarray(arr, dtype=float).ravel()]
                else:
                    rows = [np.asarray(r, dtype=float).ravel() for r in arr]
            except Exception:
                rows = []
            for rr in rows:
                if rr.size > 3 and np.all(np.isfinite(rr)):
                    out_arr.append(rr)
                    out_fs.append(local_fs)

        if 'template_cs' in d:
            _append_template('template_cs', 'fs_cs', out['cs_list'], out['fs_cs_list'])
        if 'cs_waveforms' in d:
            _append_template('cs_waveforms', 'fs_cs', out['cs_list'], out['fs_cs_list'])
        if 'template_ss' in d:
            _append_template('template_ss', 'fs_ss', out['ss_list'], out['fs_ss_list'])
        if 'ss_waveforms' in d:
            _append_template('ss_waveforms', 'fs_ss', out['ss_list'], out['fs_ss_list'])
        return out

    def _merge_templates_for_type(self, spike_type, info, source_path):
        if spike_type == 'CS':
            self.template_store['cs_templates'].extend(info.get('cs_list', []))
            self.template_store['fs_cs'].extend(info.get('fs_cs_list', []))
            if source_path not in self.template_store['cs_sources']:
                self.template_store['cs_sources'].append(source_path)
        else:
            self.template_store['ss_templates'].extend(info.get('ss_list', []))
            self.template_store['fs_ss'].extend(info.get('fs_ss_list', []))
            if source_path not in self.template_store['ss_sources']:
                self.template_store['ss_sources'].append(source_path)

    def _pick_file_or_folder(self, caption):
        fpaths, _ = QFileDialog.getOpenFileNames(self, caption + ' (single/multiple files)', os.path.expanduser('~'), 'NPZ Files (*.npz)')
        if fpaths and len(fpaths) > 0:
            return list(fpaths)
        return []

    def load_templates_for_type(self, spike_type='CS'):
        p = self._pick_file_or_folder(f'Load {spike_type} templates')
        if not p:
            return
        if spike_type == 'CS':
            self.params['TEMPLATE_CS_SELECTED_GROUPS'] = None
            self.template_store['cs_templates'] = []
            self.template_store['fs_cs'] = []
            self.template_store['cs_sources'] = []
        else:
            self.params['TEMPLATE_SS_SELECTED_GROUPS'] = None
            self.template_store['ss_templates'] = []
            self.template_store['fs_ss'] = []
            self.template_store['ss_sources'] = []

        if isinstance(p, (list, tuple)):
            files = [fp for fp in p if isinstance(fp, str) and fp.lower().endswith('.npz') and os.path.isfile(fp)]
        elif isinstance(p, str) and os.path.isfile(p):
            files = [p]
        elif isinstance(p, str) and os.path.isdir(p):
            files = sorted(glob.glob(os.path.join(p, '*.npz')))
        else:
            files = []
        if len(files) == 0:
            QMessageBox.warning(self, 'No templates', 'No NPZ template files selected/found.')
            return
        for fp in files:
            info = self._read_template_npz(fp)
            self._merge_templates_for_type(spike_type, info, fp)
        self.update_template_status_label()

    def clear_templates(self):
        if getattr(self, '_detection_running', False):
            return
        for key in ('cs_templates', 'fs_cs', 'cs_sources',
                    'ss_templates', 'fs_ss', 'ss_sources'):
            self.template_store[key] = []
        self.params['TEMPLATE_CS_SELECTED_GROUPS'] = None
        self.params['TEMPLATE_SS_SELECTED_GROUPS'] = None
        self.update_template_status_label()

    def _get_current_window_mask(self, t):
        data = self.loaded_sessions[self.selected_session]
        params = data.get('_saved_detection_params', self.params)
        start_time, end_time = _trace_view_window(data, params, float(self.spin_window.value()),
            self.slider_time.value(), self._main_view_auto_start)
        return (t >= start_time) & (t <= end_time)

    def _get_current_display_signal_full(self):
        if not self.selected_session or self.selected_session not in self.loaded_sessions:
            return None, None, None
        data = self.loaded_sessions[self.selected_session]
        idx = max(0, self.selected_cell)
        raw = data['raw_data'][:, idx]
        t = data['time_ms']
        fs = float(data['fs'])
        frames = int(self.spin_avg_frames.value()) if hasattr(self, 'spin_avg_frames') else 0
        saved_view = bool(data.get('loaded_detection_result'))
        if saved_view:
            raw_proc = _display_processed_raw(data, idx)
            baseline = np.asarray(data['baseline_traces'][:, idx])
        else:
            raw_proc, baseline, _ = protected_preprocess(raw, fs, self.params, self.baseline_params, frames, self._get_frame_processing_mode())
        method = (data['_saved_settings_snapshot']['baseline_params'].get('method', '')
                  if saved_view else self.baseline_params.get('method', ''))
        use_baseline_vis = (method != 'Disable' and getattr(self, 'chk_show_baseline', None) and self.chk_show_baseline.isChecked())
        vis_source = (raw_proc - baseline) if use_baseline_vis else raw_proc
        if saved_view and (self.chk_show_cs.isChecked() or self.chk_show_ss.isChecked()):
            kind = 'cs' if self.chk_show_cs.isChecked() else 'ss'
            res = data['results'][idx]
            vis_signal = res[kind+'_trace'] * (-1 if res['negative_going'] else 1)
        elif getattr(self, 'chk_show_cs', None) and self.chk_show_cs.isChecked():
            vis_signal = protected_filter(vis_source, fs, self.params, low=float(self.spin_cs_low.value()), high=float(self.spin_cs_high.value()), order=int(self.spin_cs_order.value()))
        elif getattr(self, 'chk_show_ss', None) and self.chk_show_ss.isChecked():
            vis_signal = protected_filter(vis_source, fs, self.params, low=float(self.spin_ss_low.value()), high=float(self.spin_ss_high.value()), order=int(self.spin_ss_order.value()))
        else:
            vis_signal = vis_source
        return np.asarray(vis_signal, dtype=float), np.asarray(t), float(fs)

    def _get_current_template_signal_full(self):
        if not self.selected_session or self.selected_session not in self.loaded_sessions:
            return None, None, None
        data = self.loaded_sessions[self.selected_session]
        idx = max(0, self.selected_cell)
        raw = np.asarray(data['raw_data'][:, idx], dtype=float)
        t = np.asarray(data['time_ms'], dtype=float)
        fs = float(data['fs'])
        frames = int(self.spin_avg_frames.value()) if hasattr(self, 'spin_avg_frames') else 0
        if data.get('loaded_detection_result'):
            raw_proc = _display_processed_raw(data, idx)
            baseline = np.asarray(data['baseline_traces'][:, idx])
        else:
            raw_proc, baseline, _ = protected_preprocess(raw, fs, self.params, self.baseline_params, frames, self._get_frame_processing_mode())
        sig = raw_proc - baseline
        if bool(data.get('_saved_detection_params', self.params).get('NEGATIVE_GOING', True)):
            sig = -sig
        return np.asarray(sig, dtype=float), t, fs

    def _get_current_corrected_signal_full(self):
        if not self.selected_session or self.selected_session not in self.loaded_sessions:
            return None, None, None
        data = self.loaded_sessions[self.selected_session]
        idx = max(0, self.selected_cell)
        raw = np.asarray(data['raw_data'][:, idx], dtype=float)
        t = np.asarray(data['time_ms'], dtype=float)
        fs = float(data['fs'])
        frames = int(self.spin_avg_frames.value()) if hasattr(self, 'spin_avg_frames') else 0
        if data.get('loaded_detection_result'):
            raw_proc = _display_processed_raw(data, idx)
            baseline = np.asarray(data['baseline_traces'][:, idx])
        else:
            raw_proc, baseline, _ = protected_preprocess(raw, fs, self.params, self.baseline_params, frames, self._get_frame_processing_mode())
        corrected = raw_proc - baseline
        valid = data.get('analysis_valid_mask') if data.get('loaded_detection_result') else observation_mask(len(t), fs, self.params)
        return np.asarray(corrected, dtype=float)[valid], t[valid], fs

    def _get_waveform_source_trace_for_stats(self, sdata, cell_idx):
        """Return a unified waveform source trace for SNR/FWHM stats.

        Uses the corrected original trace, not the denoised detection trace, so
        waveform amplitudes, SNR, and FWHM remain measured on the raw signal.
        """
        try:
            if sdata is None or 'raw_data' not in sdata:
                return None
            results = sdata.get('results', [])
            if cell_idx < len(results) and results[cell_idx] is not None and 'stats_source_trace' in results[cell_idx]:
                return results[cell_idx]['stats_source_trace']
            raw_mat = np.asarray(sdata['raw_data'])
            i = int(cell_idx)
            if raw_mat.ndim != 2 or i < 0 or i >= int(raw_mat.shape[1]):
                return None
            fs = float(sdata.get('fs', 1000.0))
            raw_cell = np.asarray(raw_mat[:, i], dtype=float)
            frames = int(self.spin_avg_frames.value()) if hasattr(self, 'spin_avg_frames') else 0
            mode = self._get_frame_processing_mode() if hasattr(self, '_get_frame_processing_mode') else 'Rolling average'
            raw_proc, baseline, valid = protected_preprocess(raw_cell, fs, self.params, self.baseline_params, frames, mode)
            trace = np.asarray(raw_proc - baseline, dtype=float)
            trace[~valid] = np.nan
            if bool(self.params.get('NEGATIVE_GOING', True)):
                trace = -np.asarray(trace, dtype=float)
            return np.asarray(trace, dtype=float)
        except Exception:
            return None

    def _apply_ss_fwhm_filter(self, res, sdata, cell_idx):
        """Retain uncertain widths, but distinguish them from measured passes."""
        if 'spike_qc' in res:
            return res
        peaks = np.asarray(res.get('ss_peaks', []), dtype=int)
        cs_peaks = np.asarray(res.get('cs_peaks', []), dtype=int)
        source = self._get_waveform_source_trace_for_stats(sdata, cell_idx)
        if source is None:
            raise ValueError('Unable to construct the waveform source for width measurement.')
        # Preserve the actual measurement source against later GUI setting edits.
        res['stats_source_trace'] = np.asarray(source, dtype=float)
        template_mode = str(res.get('det_method', '')).startswith('Template Matching')
        width_source = np.asarray(res.get('ss_trace', source), dtype=float) if template_mode else source
        res['ss_width_source'] = 'filtered SS detection trace' if template_mode else 'baseline-corrected trace'
        rows = measure_widths(width_source, peaks, float(sdata['fs']), _stats_window_ms('SS'),
                              neighbors=cs_peaks, align_ms=res.get('width_alignment_ms', 0))
        limit = float(self.params.get('SS_MAX_FWHM_MS', 4.5))
        enabled = limit > 0
        keep = []
        for row in rows:
            if np.isfinite(row['fwhm_ms']):
                row['decision'] = 'fail' if enabled and row['fwhm_ms'] > limit else 'pass'
            else:
                row['decision'] = 'uncertain'
            if row['decision'] != 'fail':
                keep.append(row['candidate_index'])
        res['ss_peaks'] = np.asarray(keep, dtype=int)
        res['ss_width_candidates'] = rows
        res['event_widths_ss'] = [r for r in rows if r['candidate_index'] in keep]
        res['event_widths_cs'] = [r for r in res.get('cs_width_candidates', []) if r['candidate_index'] in cs_peaks]
        res['ss_fwhm_filter_enabled'] = enabled
        res['ss_fwhm_filter_max_ms'] = limit
        res['ss_fwhm_filter_removed'] = len(peaks)-len(keep)
        res['ss_fwhm_filter_uncertain'] = sum(r['decision'] == 'uncertain' for r in res['event_widths_ss'])
        return res

    def _reset_template_selection_button_text(self):
        if self.btn_select_templates is None:
            return
        self.btn_select_templates.setText(('Save Labels' if self.template_selection_type == 'LABEL' else 'Save Templates') if self.template_selection_active else 'Select As')
        if self.btn_abort_templates is not None:
            self.btn_abort_templates.setEnabled(bool(self.template_selection_active))

    def abort_template_selection(self):
        self._template_records.clear()
        self._label_drafts.clear()
        self.template_selection_active = False
        self.template_selected_segments['CS'] = []
        self.template_selected_segments['SS'] = []
        self.template_selected_intervals_ms['CS'] = []
        self.template_selected_intervals_ms['SS'] = []
        self._reset_template_selection_button_text()
        self.update_plot()

    def toggle_template_selection_or_save(self):
        if not isinstance(self.data, dict):
            QMessageBox.warning(self, 'No Data', 'Load a recording first.')
            return
        if self.template_selection_active:
            if self.template_selection_type == 'LABEL':
                self.save_selected_labels()
            else:
                self.save_selected_templates()
            return
        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle('Select As')
        form = QtWidgets.QFormLayout(dlg)
        combo_type = QtWidgets.QComboBox(dlg)
        combo_type.addItem('CS template', 'CS')
        combo_type.addItem('SS template', 'SS')
        combo_type.addItem('Spike label', 'LABEL')
        spin_cs_w = QtWidgets.QDoubleSpinBox(dlg); spin_cs_w.setRange(1.0, 200.0); spin_cs_w.setDecimals(1); spin_cs_w.setSuffix(' ms')
        spin_ss_w = QtWidgets.QDoubleSpinBox(dlg); spin_ss_w.setRange(1.0, 100.0); spin_ss_w.setDecimals(1); spin_ss_w.setSuffix(' ms')
        spin_cs_w.setValue(float(self.params.get('TEMPLATE_CS_WINDOW_MS', 30.0)))
        spin_ss_w.setValue(float(self.params.get('TEMPLATE_SS_WINDOW_MS', 8.0)))
        _set_input_tooltip(combo_type, SETTING_TOOLTIPS['combo_type'])
        _set_input_tooltip(spin_cs_w, SETTING_TOOLTIPS['spin_cs_w'])
        _set_input_tooltip(spin_ss_w, SETTING_TOOLTIPS['spin_ss_w'])
        form.addRow('Type:', combo_type)
        form.addRow('CS window:', spin_cs_w)
        form.addRow('SS window:', spin_ss_w)
        help_label = QtWidgets.QLabel('Templates: left click selects a window; right click removes it. Labels: left click adds SS; Control + left click adds CS; right click removes the nearest label. Selections stay with their original cell/session.')
        help_label.setWordWrap(True)
        form.addRow(help_label)
        combo_type.currentIndexChanged.connect(lambda _i: (spin_cs_w.setEnabled(combo_type.currentData() != 'LABEL'), spin_ss_w.setEnabled(combo_type.currentData() != 'LABEL')))
        try:
            bb_buttons = QtWidgets.QDialogButtonBox.StandardButton.Ok | QtWidgets.QDialogButtonBox.StandardButton.Cancel
        except Exception:
            bb_buttons = QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel
        btn_box = QtWidgets.QDialogButtonBox(bb_buttons, parent=dlg)
        btn_box.accepted.connect(dlg.accept)
        btn_box.rejected.connect(dlg.reject)
        form.addRow(btn_box)
        try:
            accepted_code = QtWidgets.QDialog.DialogCode.Accepted
        except Exception:
            accepted_code = QtWidgets.QDialog.Accepted
        if dlg.exec() != accepted_code:
            return

        self.params['TEMPLATE_CS_WINDOW_MS'] = float(spin_cs_w.value())
        self.params['TEMPLATE_SS_WINDOW_MS'] = float(spin_ss_w.value())
        self.template_selection_type = str(combo_type.currentData())
        self.template_selection_window_ms = float(self.params['TEMPLATE_CS_WINDOW_MS'] if self.template_selection_type == 'CS' else self.params['TEMPLATE_SS_WINDOW_MS'])
        self.template_selection_active = True
        if self.template_selection_type == 'LABEL':
            try:
                self._label_draft()
            except (ValueError, OSError) as exc:
                self.template_selection_active = False
                QMessageBox.warning(self, 'Load Labels', str(exc))
        self._reset_template_selection_button_text()
        self.update_plot()

    def _annotation_session_id(self, data=None):
        data = self.data if data is None else data
        if data.get('source_session_id'):
            return str(data['source_session_id'])
        return str(Path(data.get('session_path') or Path(data.get('source_folder', self.master_folder))/self.selected_session).resolve())

    def _label_draft(self):
        sid = self._annotation_session_id()
        if sid not in self._label_drafts:
            saved = self.data if self.data.get('is_manual_labels') else None
            if saved is None:
                destination = output_paths(self.data, self.master_folder)[0]
                label_path = destination.with_name(destination.stem.removesuffix('_analyzed')+'_labels.npz')
                if label_path.is_file():
                    saved = load_saved_detection(label_path)
                    if (saved['cell_names'] != self.data['cell_names'] or
                            not np.array_equal(saved['time_ms'], self.data['time_ms']) or
                            not np.array_equal(saved['raw_data'], self.data['raw_data'])):
                        raise ValueError('Existing manual labels do not match this recording; kept them unchanged.')
            events = [{kind: (np.asarray(saved['results'][i][kind.lower()+'_peaks'], int).tolist() if saved is not None else [])
                       for kind in ('CS', 'SS')} for i in range(len(self.data['cell_names']))]
            self._label_drafts[sid] = dict(data=self.data, events=events,
                settings=self._current_settings_snapshot(),
                visited=set(saved.get('label_metadata', {}).get('labelled_cells', [i for i, ev in enumerate(events) if any(ev.values())])) if saved is not None else set(), dirty=False,
                viewed_intervals={int(k): v for k,v in saved.get('label_metadata', {}).get('viewed_intervals_ms', {}).items()} if saved is not None else {}, name=self.selected_session)
        draft = self._label_drafts[sid]
        return draft

    def on_main_plot_click(self, event):
        try:
            self._handle_annotation_click(event)
        except (ValueError, OSError) as exc:
            QMessageBox.warning(self, 'Annotation', str(exc))

    def _handle_annotation_click(self, event):
        if not self.template_selection_active or event is None or event.inaxes is None or event.xdata is None:
            return
        if event.button not in (1, 3):
            return
        if getattr(self.canvas, 'toolbar', None) is not None and self.canvas.toolbar.mode:
            return
        sid, cell = self._annotation_session_id(), max(0, self.selected_cell)
        t, fs = np.asarray(self.data['time_ms']), float(self.data['fs'])
        center = int(np.argmin(np.abs(t-float(event.xdata))))
        if self.template_selection_type == 'LABEL':
            draft = self._label_draft()
            labels = draft['events'][cell]
            if event.button == 3:
                choices = [(abs(event.inaxes.transData.transform((t[p], 0))[0]-event.x), kind, p)
                           for kind in ('CS','SS') for p in labels[kind]]
                if choices:
                    distance, kind, peak = min(choices)
                    if distance <= 10:
                        labels[kind].remove(peak); draft['dirty'] = True; draft['visited'].add(cell)
            else:
                if not observation_mask(len(t), fs, draft['settings']['params'])[center]:
                    self.statusBar().showMessage('This sample is in a recording boundary blank; no label added.')
                    return
                key = str(getattr(event, 'key', '') or '').lower()
                control = ('control' in key or 'ctrl' in key or
                           bool(QtWidgets.QApplication.keyboardModifiers() & Qt.KeyboardModifier.ControlModifier))
                draft['visited'].add(cell)
                kind = 'CS' if control else 'SS'
                other = 'SS' if control else 'CS'
                if center in labels[other]:
                    labels[other].remove(center); draft['dirty'] = True
                if center not in labels[kind]:
                    labels[kind].append(center); labels[kind].sort(); draft['dirty'] = True
                window = self._get_current_window_mask(t)
                draft['viewed_intervals'].setdefault(cell, []).append([float(t[window][0]), float(t[window][-1])])
        elif event.button == 3:
            choices = [(abs(r['center_ms']-event.xdata), i) for i, r in enumerate(self._template_records)
                       if r['session_id'] == sid and r['cell'] == cell and r['start_ms'] <= event.xdata <= r['end_ms']]
            if choices:
                self._template_records.pop(min(choices)[1])
        else:
            sig, _, _ = self._get_current_template_signal_full()
            half = int(round(self.template_selection_window_ms*fs/2000))
            indices = np.arange(center-half, center+half+1)
            valid = observation_mask(len(t), fs, self.params)
            if len(indices) < 4 or indices[0] < 0 or indices[-1] >= len(t) or not np.all(valid[indices]):
                self.statusBar().showMessage('Select a complete template window within the observed recording interval.')
                return
            start, end = float(t[indices[0]]), float(t[indices[-1]])
            if any(r['session_id'] == sid and r['cell'] == cell and r['kind'] == self.template_selection_type and r.get('center_index') == center for r in self._template_records):
                return
            profile = self.data.get('_saved_settings_snapshot') or self._current_settings_snapshot()
            self._template_records.append(dict(session_id=sid, session=self.selected_session,
                cell=cell, cell_name=self.data['cell_names'][cell], kind=self.template_selection_type,
                center_ms=float(t[center]), center_index=center, start_ms=start, end_ms=end, fs=fs,
                segment=np.asarray(sig[indices]).copy(), negative_going=bool(profile['params'].get('NEGATIVE_GOING', True)),
                baseline_params=dict(profile['baseline_params']), frames=profile['ui']['avg_frames'],
                frame_mode=profile['params'].get('FRAME_PROCESSING_MODE', 'Rolling average')))
        self.update_plot()

    def save_selected_labels(self):
        if getattr(self, '_label_save_worker', None) is not None:
            return
        current = self._label_draft()
        current['visited'].add(max(0, self.selected_cell))  # Explicit Save also supports an empty current-cell label set.
        plans = []
        for sid, draft in self._label_drafts.items():
            if not draft['visited'] and not draft['dirty']:
                continue
            destination = output_paths(draft['data'], self.master_folder)[0]
            destination = destination.with_name(destination.stem.removesuffix('_analyzed')+'_labels.npz')
            job = dict(draft, settings=copy.deepcopy(draft['settings']),
                       events=copy.deepcopy(draft['events']), visited=set(draft['visited']),
                       viewed_intervals=copy.deepcopy(draft['viewed_intervals']))
            plans.append((sid, job, destination))
        existing = [p for _, _, dest in plans for p in (dest, dest.with_name(dest.stem+'_settings.json')) if p.exists()]
        if existing and not self._confirm_result_replacement(existing):
            return
        approved = {str(p.resolve()) for p in existing}
        self.centralWidget().setEnabled(False)
        self.detection_progress.setRange(0, 0)
        self.detection_progress.setFormat('Saving Labels…')
        worker = _DetectionCellThread(lambda: self._write_label_sessions(plans, approved), self)
        self._label_save_worker = worker
        worker.result_ready.connect(self._labels_save_ready)
        worker.finished.connect(worker.deleteLater)
        worker.start()

    def _write_label_sessions(self, plans, approved):
        errors, completed = [], []
        for sid, draft, destination in plans:
            stage = stage_cfg = None
            try:
                data, settings = draft['data'], draft['settings']
                params = settings['params']; params['COMBO_DETECTION'] = False
                denoise = default_denoise_config()
                for name in denoise:
                    key = 'DENOISE_'+name.upper()
                    if key in params:
                        denoise[name] = params[key]
                view = dict(data)
                view.pop('_control_context', None)
                view['results'] = [manual_result(data['raw_data'][:, i], data['fs'], settings, events,
                    _detect_cell, denoise) for i, events in enumerate(draft['events'])]
                for kind in ('cs','ss'):
                    view['spike_times_'+kind] = [data['time_ms'][r[kind+'_peaks']] for r in view['results']]
                view['result_method'] = 'Manual labels'
                view['effective_settings'] = effective_settings(params, settings['baseline_params'], settings['ui']['avg_frames'], data['fs'], len(data['time_ms']))
                payload = self._build_detection_export(view, settings=settings)
                label_meta = dict(version=1, source_session_id=sid,
                    source_session=draft['name'], labelled_cells=sorted(draft['visited']),
                    cell_names=data['cell_names'], completeness='partial; absence of a label is not a confirmed negative',
                    initial_source='empty or previously saved manual labels; automatic detections never imported',
                    viewed_intervals_ms=draft['viewed_intervals'], qc_rejection_applied=False,
                    timestamp_convention='nearest native input sample; original time origin preserved')
                payload['label_metadata_json'] = json.dumps(json_safe(label_meta))
                stage = Path(self._temporary_store.allocate(destination.stem))
                np.savez_compressed(stage, **payload)
                stage_cfg = stage.with_name(stage.stem+'_settings.json')
                cfg = dict(settings, results_file=destination.name,
                           analysis_settings=json.loads(payload['analysis_settings_json']))
                stage_cfg.write_text(json.dumps(cfg, indent=2))
                # Validate before replacing any prior label file.
                load_saved_detection(stage)
                publish_detection(stage, stage_cfg, destination, approved)
                restored = load_saved_detection(destination)
                preserved = {key: data[key] for key in ('session_name','session_path','source_folder','output_basename') if key in data}
                completed.append((sid, restored, preserved, str(destination)))
            except Exception as exc:
                errors.append(f"{draft['name']}: {exc}")
            finally:
                for path in (stage, stage_cfg):
                    if path is not None:
                        try:
                            path.unlink(missing_ok=True)
                        except OSError as exc:
                            errors.append(f'Temporary cleanup deferred: {exc}')
        return completed, errors

    def _labels_save_ready(self, payload, error):
        self._label_save_worker.wait(1000)
        self._label_save_worker = None
        self.centralWidget().setEnabled(True)
        self.detection_progress.setRange(0, 1); self.detection_progress.setValue(1)
        self.detection_progress.setFormat('Ready')
        completed, errors = payload if error is None else ([], [str(error)])
        for sid, restored, preserved, destination in completed:
            data = self._label_drafts[sid]['data']
            data.clear(); data.update(restored); data.update(preserved)
        if errors:
            QMessageBox.warning(self, 'Save Labels', 'Some labels could not be saved; drafts retained.\n'+'\n'.join(errors))
        else:
            self._label_drafts.clear(); self.template_selection_active = False
            self._reset_template_selection_button_text()
        if completed and self.data.get('is_manual_labels'):
            self._restore_saved_run_settings(self.data)
        self.update_plot()
        if completed:
            self.statusBar().showMessage(f'Saved manual labels for {len(completed)} session(s). Spike Statistics now uses these labels.')
            QMessageBox.information(self, 'Labels Saved', '\n'.join(row[3] for row in completed))

    def save_selected_templates(self):
        st = self.template_selection_type
        records = [r for r in self._template_records if r['kind'] == st]
        segs = [r['segment'] for r in records]
        if len(segs) == 0:
            QMessageBox.warning(self, 'No templates', 'No selected periods yet. Click on the trace to select template windows.')
            return
        _, _, fs = self._get_current_template_signal_full()
        if fs is None:
            QMessageBox.warning(self, 'No data', 'No valid trace available for saving templates.')
            return
        filename, _ = QFileDialog.getSaveFileName(self, 'Save templates NPZ', os.path.expanduser('~/templates_selected.npz'), 'NPZ Files (*.npz)')
        if not filename:
            return
        if not filename.lower().endswith('.npz'):
            filename += '.npz'

        old = {}
        if os.path.exists(filename):
            try:
                with np.load(filename, allow_pickle=True) as old_npz:
                    old = {k: old_npz[k] for k in old_npz.files}
            except Exception:
                old = {}

        payload = dict(old)
        target_fs = float(TEMPLATE_TARGET_FS)
        upsampled = [_resample_template_to_fs(np.asarray(r['segment'], dtype=float).ravel(), r['fs'], target_fs) for r in records]
        payload['fs'] = float(target_fs)
        payload[st.lower()+'_selection_metadata_json'] = json.dumps([{k:v for k,v in r.items() if k != 'segment'} for r in records])
        seg_arr = np.array(upsampled, dtype=object)
        if st == 'CS':
            payload['cs_waveforms'] = seg_arr
            try:
                lens = [len(np.asarray(s).ravel()) for s in upsampled]
                min_len = int(np.min(lens))
                stack = np.vstack([np.asarray(s).ravel()[:min_len] for s in upsampled])
                payload['template_cs'] = np.mean(stack, axis=0)
                payload['fs_cs'] = float(target_fs)
            except Exception:
                pass
        else:
            payload['ss_waveforms'] = seg_arr
            try:
                lens = [len(np.asarray(s).ravel()) for s in upsampled]
                min_len = int(np.min(lens))
                stack = np.vstack([np.asarray(s).ravel()[:min_len] for s in upsampled])
                payload['template_ss'] = np.mean(stack, axis=0)
                payload['fs_ss'] = float(target_fs)
            except Exception:
                pass

        np.savez_compressed(filename, **payload)
        QMessageBox.information(self, 'Saved', f'{len(segs)} {st} template segment(s) saved to {filename}')

        # reload just-saved file into matching bank for this type
        info = self._read_template_npz(filename)
        if st == 'CS':
            self.template_store['cs_templates'] = []
            self.template_store['fs_cs'] = []
            self.template_store['cs_sources'] = []
        else:
            self.template_store['ss_templates'] = []
            self.template_store['fs_ss'] = []
            self.template_store['ss_sources'] = []
        self._merge_templates_for_type(st, info, filename)
        self.update_template_status_label()

        self.template_selection_active = False
        self._template_records = [r for r in self._template_records if r['kind'] != st]
        self.template_selected_segments[st] = []
        self.template_selected_intervals_ms[st] = []
        self._reset_template_selection_button_text()
        self.update_plot()

    def open_color_scheme_dialog(self):
        dlg = ColorSchemeDialog(self)
        if dlg.exec():
            scheme = dlg.get_scheme()
            self.colors.update(scheme)
            self.update_plot()

    def open_detection_settings_dialog(self):
        self.start_detection_async(open_viewer=True)
        
    
    def on_baseline_param_change(self):
        method = self.combo_baseline_method.currentText()
        self.baseline_params['method'] = method
        self.baseline_params['window_ms'] = float(self.spin_baseline_window.value())
        self.baseline_params['percentile'] = float(self.spin_baseline_percentile.value())
        # Show/hide controls
        self.spin_baseline_percentile.setEnabled(method == 'Percentile')
        # If baseline is disabled, disable the 'Show baseline-corrected' option
        try:
            if getattr(self, 'chk_show_baseline', None) is not None:
                if method == 'Disable':
                    try:
                        self.chk_show_baseline.setChecked(False)
                    except Exception:
                        pass
                    try:
                        self.chk_show_baseline.setEnabled(False)
                    except Exception:
                        pass
                else:
                    try:
                        self.chk_show_baseline.setEnabled(True)
                    except Exception:
                        pass
        except Exception:
            pass
        self.update_plot()

    def on_frame_processing_mode_changed(self):
        try:
            self.params['FRAME_PROCESSING_MODE'] = self._get_frame_processing_mode()
        except Exception:
            pass
        self.update_plot()

    def _set_frame_processing_mode(self, mode):
        # Keep the historical stored value so old settings and archived runs agree.
        mode = 'Downsampling frames' if str(mode).casefold() == 'mean' else str(mode)
        self.combo_frame_processing.setCurrentIndex(max(0, self.combo_frame_processing.findData(mode)))

    def _get_frame_processing_mode(self):
        try:
            return str(self.combo_frame_processing.currentData())
        except Exception:
            return str(self.params.get('FRAME_PROCESSING_MODE', 'Rolling average'))

    def on_denoise_toggle(self, *_args):
        try:
            self.params['DENOISE_ENABLED'] = bool(self.chk_denoise.isChecked())
            try:
                self._denoise_cache.clear()
            except Exception:
                pass
            if hasattr(self, 'lbl_denoise_status') and self.lbl_denoise_status is not None:
                self.lbl_denoise_status.setText('Denoise: ON' if self.params['DENOISE_ENABLED'] else 'Denoise: OFF')
        except Exception:
            pass
        self.update_plot()

    def _get_denoise_config(self):
        cfg = default_denoise_config()
        cfg.update({
            'enabled': bool(self.params.get('DENOISE_ENABLED', False)),
            'apply_to_cs': bool(self.params.get('DENOISE_APPLY_TO_CS', False)),
            'f_min_hz': float(self.params.get('DENOISE_F_MIN_HZ', cfg['f_min_hz'])),
            'f_max_hz': float(self.params.get('DENOISE_F_MAX_HZ', cfg['f_max_hz'])),
            'n_freqs': int(self.params.get('DENOISE_N_FREQS', cfg['n_freqs'])),
            'max_clusters': int(self.params.get('DENOISE_MAX_CLUSTERS', cfg['max_clusters'])),
            'min_clusters': int(self.params.get('DENOISE_MIN_CLUSTERS', cfg['min_clusters'])),
            'max_pca_components': int(self.params.get('DENOISE_MAX_PCA_COMPONENTS', cfg['max_pca_components'])),
            'threshold_sigma': float(self.params.get('DENOISE_THRESHOLD_SIGMA', cfg['threshold_sigma'])),
            'attenuation_min': float(self.params.get('DENOISE_ATTENUATION_MIN', cfg['attenuation_min'])),
            'soft_threshold': bool(self.params.get('DENOISE_SOFT_THRESHOLD', cfg['soft_threshold'])),
            'moving_cycles': float(self.params.get('DENOISE_MOVING_CYCLES', cfg['moving_cycles'])),
            'max_timepoints_for_clustering': int(self.params.get('DENOISE_MAX_TIMEPOINTS_FOR_CLUSTERING', cfg['max_timepoints_for_clustering'])),
            'event_refine_enabled': bool(self.params.get('DENOISE_EVENT_REFINE_ENABLED', cfg['event_refine_enabled'])),
            'event_refine_window_ms': float(self.params.get('DENOISE_EVENT_REFINE_WINDOW_MS', cfg['event_refine_window_ms'])),
            'event_refine_sigma': float(self.params.get('DENOISE_EVENT_REFINE_SIGMA', cfg['event_refine_sigma'])),
            'event_refine_pc1_z_cutoff': float(self.params.get('DENOISE_EVENT_REFINE_PC1_Z_CUTOFF', cfg['event_refine_pc1_z_cutoff'])),
            'event_refine_attenuation': float(self.params.get('DENOISE_EVENT_REFINE_ATTENUATION', cfg['event_refine_attenuation'])),
        })
        return cfg

    def _denoise_cache_token(self):
        keys = [
            'DENOISE_F_MIN_HZ', 'DENOISE_F_MAX_HZ', 'DENOISE_N_FREQS',
            'DENOISE_MAX_CLUSTERS', 'DENOISE_MIN_CLUSTERS', 'DENOISE_MAX_PCA_COMPONENTS',
            'DENOISE_THRESHOLD_SIGMA', 'DENOISE_ATTENUATION_MIN', 'DENOISE_SOFT_THRESHOLD',
            'DENOISE_MOVING_CYCLES', 'DENOISE_MAX_TIMEPOINTS_FOR_CLUSTERING',
            'DENOISE_EVENT_REFINE_ENABLED', 'DENOISE_EVENT_REFINE_WINDOW_MS',
            'DENOISE_EVENT_REFINE_SIGMA', 'DENOISE_EVENT_REFINE_PC1_Z_CUTOFF',
            'DENOISE_EVENT_REFINE_ATTENUATION', 'FRAME_PROCESSING_MODE', 'INITIAL_BLANK_MS', 'FINAL_BLANK_MS',
        ]
        vals = tuple((k, self.params.get(k, None)) for k in keys)
        try:
            vals += (('BASELINE_METHOD', self.baseline_params.get('method')),)
            vals += (('BASELINE_WINDOW_MS', float(self.baseline_params.get('window_ms', 0.0))),)
            vals += (('BASELINE_PERCENTILE', float(self.baseline_params.get('percentile', 0.0))),)
        except Exception:
            pass
        try:
            vals += (('AVG_FRAMES', int(self.spin_avg_frames.value())),)
        except Exception:
            pass
        return vals

    def _apply_denoise_trace(self, corrected_trace, fs, cache_key=None):
        x = np.asarray(corrected_trace, dtype=float).ravel()
        if not bool(self.params.get('DENOISE_ENABLED', False)):
            return x, {'ok': False, 'error': 'disabled'}
        key = None
        if cache_key is not None:
            try:
                if x.size > 0:
                    mid = int(x.size // 2)
                    trace_fingerprint = (
                        float(np.nanmean(x)),
                        float(x[0]),
                        float(x[mid]),
                        float(x[-1]),
                    )
                else:
                    trace_fingerprint = (0.0, 0.0, 0.0, 0.0)
                key = (cache_key, int(x.size), float(fs), trace_fingerprint, self._denoise_cache_token())
                cached = self._denoise_cache.get(key)
                if cached is not None:
                    return np.asarray(cached[0], dtype=float), dict(cached[1])
            except Exception:
                key = None
        cfg = self._get_denoise_config()
        start, stop = observation_bounds(len(x), fs, self.params.get('INITIAL_BLANK_MS', 150), self.params.get('FINAL_BLANK_MS', 50))
        if stop-start < 128:
            raise ValueError('Not enough observed samples for denoising.')
        observed_y, meta = adaptive_wavelet_denoise(x[start:stop], fs, cfg=cfg)
        y = np.pad(observed_y, (start, len(x)-stop), mode='edge')
        if key is not None:
            try:
                if len(self._denoise_cache) > 24:
                    self._denoise_cache.clear()
                self._denoise_cache[key] = (np.asarray(y, dtype=float), dict(meta))
            except Exception:
                pass
        try:
            if hasattr(self, 'lbl_denoise_status') and self.lbl_denoise_status is not None:
                if meta.get('ok', False):
                    self.lbl_denoise_status.setText(
                        f"Denoise: ON | k={int(meta.get('n_clusters', 1))} | atten={100.0 * float(np.mean(np.asarray(meta.get('attenuation_mask', np.ones_like(x))) < 0.99)):.1f}%"
                    )
                else:
                    self.lbl_denoise_status.setText('Denoise: ON (fallback)')
        except Exception:
            pass
        return np.asarray(y, dtype=float), meta

    def open_denoising_settings(self):
        dlg = DenoisingSettingsDialog(parent=self)
        if dlg.exec():
            self.update_plot()

    def _on_chk_cs_toggled(self, checked):
        try:
            if checked and getattr(self, 'chk_show_ss', None) is not None:
                # enforce mutual exclusion
                self.chk_show_ss.setChecked(False)
        except Exception:
            pass
        try:
            self.update_plot()
        except Exception:
            pass

    def _on_chk_ss_toggled(self, checked):
        try:
            if checked and getattr(self, 'chk_show_cs', None) is not None:
                # enforce mutual exclusion
                self.chk_show_cs.setChecked(False)
        except Exception:
            pass
        try:
            self.update_plot()
        except Exception:
            pass


    def open_settings(self):
        dlg = SettingsDialog(self)
        if dlg.exec():
            # dialog updates parent.params and parent.colors directly
            self.update_plot()

    def _current_settings_snapshot(self):
        if not (isinstance(self.data, dict) and self.data.get('loaded_detection_result')):
            self._sync_detection_controls_to_params()
        return {
            'version': 1,
            'app_version': APP_VERSION,
            'params': dict(self.params),
            'baseline_params': dict(self.baseline_params),
            'colors': dict(self.colors),
            'template_sources': {
                'CS': list(self.template_store.get('cs_sources', [])),
                'SS': list(self.template_store.get('ss_sources', [])),
            },
            'ui': {
                'center_slider': int(self.slider_time.value()) if hasattr(self, 'slider_time') else 0,
                'start_at_observation': bool(self._main_view_auto_start),
                'window_ms': float(self.spin_window.value()) if hasattr(self, 'spin_window') else 1000.0,
                'y_range': float(self.spin_zoom.value()) if hasattr(self, 'spin_zoom') else 0.0,
                'avg_frames': int(self.spin_avg_frames.value()) if hasattr(self, 'spin_avg_frames') else 0,
                'baseline_method': str(self.combo_baseline_method.currentText()) if hasattr(self, 'combo_baseline_method') else self.baseline_params.get('method', 'Median'),
                'baseline_window_ms': self.baseline_params.get('window_ms', 30.0),
                'baseline_percentile': self.baseline_params.get('percentile', 20.0),
                'show_baseline': bool(self.chk_show_baseline.isChecked()) if hasattr(self, 'chk_show_baseline') else False,
                'show_cs': bool(self.chk_show_cs.isChecked()) if hasattr(self, 'chk_show_cs') else False,
                'show_ss': bool(self.chk_show_ss.isChecked()) if hasattr(self, 'chk_show_ss') else False,
                'detection_tab_index': int(self.tabs_detection.currentIndex()) if hasattr(self, 'tabs_detection') else 0,
            },
        }

    def save_all_settings(self):
        try:
            cfg = self._current_settings_snapshot()
            filename, _ = QFileDialog.getSaveFileName(self, 'Save settings', os.path.expanduser('~/spike_detector_settings.json'), 'JSON Files (*.json)')
            if not filename:
                return
            if not filename.lower().endswith('.json'):
                filename += '.json'
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(cfg, f, indent=2)
            QMessageBox.information(self, 'Saved', f'Settings saved to {filename}')
        except Exception as e:
            QMessageBox.critical(self, 'Save Settings Error', str(e))

    def _sync_detection_controls_to_params(self):
        self._sync_polarity_buttons()
        try:
            self.params['COMBO_DETECTION'] = bool(self.chk_combo.isChecked())
            self.params['SAVE_DETECTION_RESULTS'] = bool(self.chk_detection_save.isChecked())
            self.params['TEMPLATE_WHITENING'] = bool(self.chk_template_whitening.isChecked())
            if hasattr(self, 'spin_cs_low'):
                self.params['CS_LOW_CUT_HZ'] = float(self.spin_cs_low.value())
            if hasattr(self, 'spin_cs_high'):
                self.params['CS_HIGH_CUT_HZ'] = float(self.spin_cs_high.value())
            if hasattr(self, 'spin_cs_thresh'):
                self.params['CS_THRESHOLD_SIGMA'] = float(self.spin_cs_thresh.value())
            if hasattr(self, 'spin_ss_low'):
                self.params['SS_LOW_CUT_HZ'] = float(self.spin_ss_low.value())
            if hasattr(self, 'spin_ss_high'):
                self.params['SS_HIGH_CUT_HZ'] = float(self.spin_ss_high.value())
            if hasattr(self, 'spin_ss_thresh'):
                self.params['SS_THRESHOLD_SIGMA'] = float(self.spin_ss_thresh.value())
            if hasattr(self, 'spin_ss_blank'):
                self.params['SS_BLANK_MS'] = float(self.spin_ss_blank.value())
            if hasattr(self, 'spin_cs_order'):
                self.params['CS_FILTER_ORDER'] = int(self.spin_cs_order.value())
            if hasattr(self, 'spin_ss_order'):
                self.params['SS_FILTER_ORDER'] = int(self.spin_ss_order.value())
        except Exception:
            pass

    def load_all_settings(self, checked=False, *, snapshot=None, settings_path=None, quiet=False):
        try:
            if snapshot is None:
                filename, _ = QFileDialog.getOpenFileName(self, 'Load settings', os.path.expanduser('~'), 'JSON Files (*.json)')
                if not filename:
                    return False
                with open(filename, 'r', encoding='utf-8') as f:
                    cfg = json.load(f)
            else:
                filename = settings_path or os.path.join(os.getcwd(), 'settings.json')
                cfg = copy.deepcopy(snapshot)
            if not isinstance(cfg, dict):
                raise ValueError('Invalid settings file format.')

            blockers = [QtCore.QSignalBlocker(w) for w in self.findChildren(QtWidgets.QWidget)
                        if isinstance(w, (QtWidgets.QAbstractSpinBox, QtWidgets.QComboBox, QtWidgets.QCheckBox, QtWidgets.QTabBar, QtWidgets.QTabWidget, QtWidgets.QSlider))
                        and w is not self.tabs_detection.tabBar()]
            loaded_params = cfg.get('params', {})
            loaded_baseline = cfg.get('baseline_params', {})
            loaded_colors = cfg.get('colors', {})
            loaded_ui = cfg.get('ui', {})
            loaded_template_sources = cfg.get('template_sources')
            legacy_qc = isinstance(loaded_params, dict) and any(key in loaded_params for key in LEGACY_QC_KEYS)

            if isinstance(loaded_params, dict):
                if 'DETECTION_OVERRIDE' in loaded_params:
                    loaded_params.setdefault('SAVE_DETECTION_RESULTS', bool(loaded_params.pop('DETECTION_OVERRIDE')))
                loaded_params.pop('TEMPLATE_SS_MIN_FWHM_MS', None)
                self.params.pop('TEMPLATE_SS_MIN_FWHM_MS', None)
                if 'SS_BLANK_MS' in loaded_params:
                    for key in ('SS_MASK_PRE_MS', 'SS_MASK_POST_MS'):
                        if key not in loaded_params:
                            self.params.pop(key, None)
                for prefix in ('DETECTION', 'SLIDER'):
                    if prefix+'_VIEW_CENTER' in loaded_params:
                        loaded_params.setdefault(prefix+'_VIEW_AUTO_START', False)
                loaded_params = migrate_qc_settings(loaded_params)
                for key in LEGACY_QC_KEYS:
                    self.params.pop(key, None)
                self.params.update(loaded_params)
            if isinstance(loaded_baseline, dict):
                self.baseline_params.update(loaded_baseline)
            if isinstance(loaded_colors, dict):
                self.colors.update(loaded_colors)
            # Widget signals can write back into params while controls are restored.
            # Read every saved control from this stable copy instead.
            settings_params = dict(self.params)
            self._sync_polarity_buttons()
            self._restore_qc_controls(settings_params)

            missing_templates = []
            if isinstance(loaded_template_sources, dict):
                restored_store = {key: [] for key in self.template_store}
                for kind, prefix in (('CS', 'cs'), ('SS', 'ss')):
                    sources = loaded_template_sources.get(kind, [])
                    if not isinstance(sources, list):
                        raise ValueError(f'Invalid {kind} template source list in settings file.')
                    for source in sources:
                        if not isinstance(source, str):
                            raise ValueError(f'Invalid {kind} template source in settings file.')
                        source_path = os.path.abspath(os.path.join(os.path.dirname(filename), source))
                        if not os.path.isfile(source_path):
                            missing_templates.append(f'{kind}: {source}')
                            continue
                        try:
                            info = self._read_template_npz(source_path)
                        except Exception as exc:
                            missing_templates.append(f'{kind}: {source} ({exc})')
                            continue
                        templates = info.get(f'{prefix}_list', [])
                        if not templates:
                            missing_templates.append(f'{kind}: {source} (no usable templates)')
                            continue
                        restored_store[f'{prefix}_templates'].extend(templates)
                        restored_store[f'fs_{prefix}'].extend(info[f'fs_{prefix}_list'])
                        restored_store[f'{prefix}_sources'].append(source_path)
                self.template_store = restored_store
                self.update_template_status_label()

            _set_user_linewidth_scale(self.params.get('LINE_WIDTH_SCALE', 0.7))

            try:
                self.combo_baseline_method.setCurrentText(str(loaded_ui.get('baseline_method', self.baseline_params.get('method', 'Median'))))
            except Exception:
                try:
                    self.combo_baseline_method.setCurrentText(str(self.baseline_params.get('method', 'Median')))
                except Exception:
                    pass
            try:
                self.spin_baseline_window.setValue(float(loaded_ui.get('baseline_window_ms', self.baseline_params.get('window_ms', 30.0))))
            except Exception:
                pass
            try:
                self.spin_baseline_percentile.setValue(float(loaded_ui.get('baseline_percentile', self.baseline_params.get('percentile', 20.0))))
            except Exception:
                pass
            try:
                self.slider_time.setValue(int(loaded_ui.get('center_slider', self.slider_time.value())))
                self._main_view_auto_start = bool(loaded_ui.get('start_at_observation', 'center_slider' not in loaded_ui))
            except Exception:
                pass
            try:
                self.spin_window.setValue(float(loaded_ui.get('window_ms', self.spin_window.value())))
            except Exception:
                pass
            try:
                self.spin_zoom.setValue(float(loaded_ui.get('y_range', self.spin_zoom.value())))
            except Exception:
                pass
            try:
                self.spin_avg_frames.setValue(int(loaded_ui.get('avg_frames', self.spin_avg_frames.value())))
            except Exception:
                pass
            try:
                self.chk_show_baseline.setChecked(bool(loaded_ui.get('show_baseline', self.chk_show_baseline.isChecked())))
            except Exception:
                pass
            try:
                self.chk_show_cs.setChecked(bool(loaded_ui.get('show_cs', self.chk_show_cs.isChecked())))
            except Exception:
                pass
            try:
                self.chk_show_ss.setChecked(bool(loaded_ui.get('show_ss', self.chk_show_ss.isChecked())))
            except Exception:
                pass

            try:
                self.spin_cs_low.setValue(float(settings_params.get('CS_LOW_CUT_HZ', self.spin_cs_low.value())))
                self.spin_cs_high.setValue(float(settings_params.get('CS_HIGH_CUT_HZ', self.spin_cs_high.value())))
                self.spin_cs_thresh.setValue(float(settings_params.get('CS_THRESHOLD_SIGMA', self.spin_cs_thresh.value())))
                self.spin_cs_order.setValue(int(settings_params.get('CS_FILTER_ORDER', self.spin_cs_order.value())))
                self.spin_ss_low.setValue(float(settings_params.get('SS_LOW_CUT_HZ', self.spin_ss_low.value())))
                self.spin_ss_high.setValue(float(settings_params.get('SS_HIGH_CUT_HZ', self.spin_ss_high.value())))
                self.spin_ss_thresh.setValue(float(settings_params.get('SS_THRESHOLD_SIGMA', self.spin_ss_thresh.value())))
                self.spin_ss_order.setValue(int(settings_params.get('SS_FILTER_ORDER', self.spin_ss_order.value())))
                self.spin_ss_blank.setValue(float(settings_params.get('SS_BLANK_MS', self.spin_ss_blank.value())))
                self._set_frame_processing_mode(settings_params.get('FRAME_PROCESSING_MODE', self._get_frame_processing_mode()))
                self.combo_template_method.setCurrentIndex(max(0, self.combo_template_method.findData(
                    str(settings_params.get('TEMPLATE_MATCH_METHOD', 'LLR Probability Vector')))))
                self.chk_template_parallel.setChecked(bool(settings_params.get('TEMPLATE_PARALLEL', False)))
                self.chk_template_whitening.setChecked(bool(settings_params.get('TEMPLATE_WHITENING', False)))
                self.spin_template_groups.blockSignals(True)
                self.spin_template_groups.setValue(int(settings_params.get('TEMPLATE_PARALLEL_GROUPS', 3)))
                self.spin_template_groups.blockSignals(False)
                self.spin_template_cs_sigma.setValue(float(settings_params.get('TEMPLATE_CS_SIGMA', self.spin_template_cs_sigma.value())))
                self.spin_template_ss_sigma.setValue(float(settings_params.get('TEMPLATE_SS_SIGMA', self.spin_template_ss_sigma.value())))
                self.spin_template_cs_sim.setValue(float(settings_params.get('TEMPLATE_CS_SIMILARITY', self.spin_template_cs_sim.value())))
                self.spin_template_ss_sim.setValue(float(settings_params.get('TEMPLATE_SS_SIMILARITY', self.spin_template_ss_sim.value())))
                self.spin_template_lowpass.setValue(float(settings_params.get('TEMPLATE_SS_LOWPASS_HZ', self.spin_template_lowpass.value())))
                self.chk_local_baseline.setChecked(bool(settings_params.get('LOCAL_BASELINE', self.chk_local_baseline.isChecked())))
                self.spin_local_ss_ms.setValue(float(settings_params.get('LOCAL_BASELINE_SS_MS', self.spin_local_ss_ms.value())))
                self.spin_local_cs_ms.setValue(float(settings_params.get('LOCAL_BASELINE_CS_MS', self.spin_local_cs_ms.value())))
                self.chk_detection_save.setChecked(bool(settings_params.get('SAVE_DETECTION_RESULTS', self.chk_detection_save.isChecked())))
                self.chk_denoise.setChecked(bool(settings_params.get('DENOISE_ENABLED', self.chk_denoise.isChecked())))
                self.chk_combo.setChecked(bool(settings_params.get('COMBO_DETECTION', False)))
            except Exception:
                pass

            try:
                if hasattr(self, 'tabs_detection') and self.tabs_detection is not None:
                    idx = int(loaded_ui.get('detection_tab_index', self.tabs_detection.currentIndex()))
                    idx = max(0, min(idx, self.tabs_detection.count() - 1))
                    self.tabs_detection.setCurrentIndex(idx)
                    self.on_detection_tab_changed(idx)
            except Exception:
                pass

            blockers.clear()
            self.on_combo_changed(self.chk_combo.isChecked())
            self.params.pop('INPUT_TIME_UNIT', None)
            self.on_baseline_param_change()
            self.on_template_controls_changed()
            self.on_denoise_toggle()
            self.params.update(settings_params)
            if isinstance(loaded_baseline, dict):
                self.baseline_params.update(loaded_baseline)
            try:
                self._denoise_cache.clear()
            except Exception:
                pass
            self.update_plot()
            note = ('\n\nSpike QC now controls amplitude SNR and width for every detection mode. Old projection/filtered-height gates were removed; they are not amplitude SNR. Review Spike QC before rerunning.' if legacy_qc else '')
            if (cfg.get('app_version') != APP_VERSION and
                    self.params.get('TEMPLATE_MATCH_METHOD') == 'LLR Probability Vector'):
                note += ('\n\nReview the LLR CS/SS response/MAD cutoffs when loading settings '
                        'from a different app version.')
                self.text_stats.append(note.strip())
            if missing_templates:
                note += ('\n\nCould not restore template sources:\n' +
                         '\n'.join(missing_templates))
            self._settings_restore_warnings = missing_templates
            if not quiet:
                QMessageBox.information(self, 'Loaded', f'Settings loaded from {filename}{note}')
            return True
        except Exception as e:
            if quiet:
                raise
            QMessageBox.critical(self, 'Load Settings Error', str(e))
            return False

    def _confirm_discard_annotations(self):
        if not (self._template_records or self._label_drafts):
            return True
        answer = QMessageBox.question(self, 'Unsaved Annotations',
            'Opening another folder discards unsaved labels/template selections. Continue?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Cancel)
        if answer != QMessageBox.StandardButton.Yes:
            return False
        self.abort_template_selection()
        return True

    def open_saved_session(self):
        if getattr(self, '_saved_load_worker', None) is not None:
            return
        folder = QFileDialog.getExistingDirectory(self, 'Load Saved Detection Folder', self.master_folder or os.path.expanduser('~'))
        if not folder or not self._confirm_discard_annotations():
            return
        self.centralWidget().setEnabled(False)
        self.detection_progress.setRange(0, 0)
        self.detection_progress.setFormat('Loading Saved Session…')
        worker = _DetectionCellThread(lambda: load_saved_detection_folder(folder), self)
        self._saved_load_worker = worker
        worker.result_ready.connect(self._saved_session_ready)
        worker.finished.connect(worker.deleteLater)
        worker.start()

    def _saved_session_ready(self, payload, error):
        worker = self._saved_load_worker
        worker.wait(1000)
        self._saved_load_worker = None
        self.centralWidget().setEnabled(True)
        self.detection_progress.setRange(0, 1)
        self.detection_progress.setValue(1)
        self.detection_progress.setFormat('Ready')
        try:
            if error is not None:
                raise error
            self._activate_saved_sessions(payload)
        except Exception as exc:
            QMessageBox.warning(self, 'Load Session', str(exc))
            return
        QtCore.QTimer.singleShot(0, self.open_detection_viewer)

    def load_saved_folder(self, folder):
        """Synchronous entry for scripts/tests; UI loading uses the worker above."""
        return self._activate_saved_sessions(load_saved_detection_folder(folder))

    def _activate_saved_sessions(self, payload):
        folder, loaded, issues = payload
        self._denoise_cache.clear()
        self.template_selection_active = False
        self.template_selected_intervals_ms = {'CS': [], 'SS': []}
        self.template_selected_segments = {'CS': [], 'SS': []}
        self._reset_template_selection_button_text()
        self.master_folder = folder
        self.batch_folders, self.batch_load_issues = [], issues
        self.loaded_sessions = loaded
        self.session_names = list(loaded)
        self.sessions = [data['session_path'] for data in loaded.values()]
        self.list_sessions.blockSignals(True)
        self.list_sessions.clear()
        self.list_sessions.addItems(self.session_names)
        self.list_sessions.setCurrentIndex(0)
        self.list_sessions.blockSignals(False)
        self.on_session_select(0)
        self.statusBar().showMessage(f'Saved detection folder: {folder} | sessions: {len(loaded)} | skipped: {len(issues)}')
        if issues:
            self.text_stats.append('Skipped saved results:\n'+'\n'.join(issues))
        return len(loaded), sum(len(data['results']) for data in loaded.values())

    def _restore_saved_run_settings(self, data):
        saved = data['_saved_settings_snapshot']
        cfg = copy.deepcopy(self._default_settings_snapshot)
        for key in ('params', 'baseline_params', 'ui', 'colors'):
            cfg[key].update(copy.deepcopy(saved.get(key, {})))
        cfg['ui']['start_at_observation'] = saved.get('ui', {}).get('start_at_observation', 'center_slider' not in saved.get('ui', {}))
        for prefix in ('DETECTION', 'SLIDER'):
            prior = saved.get('params', {})
            cfg['params'][prefix+'_VIEW_AUTO_START'] = prior.get(prefix+'_VIEW_AUTO_START', prefix+'_VIEW_CENTER' not in prior)
        cfg['app_version'] = saved.get('app_version', '')
        cfg['template_sources'] = copy.deepcopy(saved.get('template_sources', {'CS': [], 'SS': []}))
        self.params = copy.deepcopy(cfg['params'])
        self.baseline_params = copy.deepcopy(cfg['baseline_params'])
        self.load_all_settings(snapshot=cfg, settings_path=os.path.join(data['_saved_settings_base'], 'settings.json'), quiet=True)

    def select_folder(self):
        folder = QFileDialog.getExistingDirectory(self, 'Select Master Folder', os.path.expanduser('~'))
        if folder and self._confirm_discard_annotations():
            self.master_folder = folder
            self.statusBar().showMessage(f'Master folder: {folder}')
            self.refresh_sessions()

    def _list_table_files_in_dir(self, folder_path):
        return list_table_files(folder_path)

    def _session_dir_has_supported_data(self, folder_path):
        try:
            if glob.glob(os.path.join(folder_path, '*_analyzed.npz')):
                return True
            if self._list_table_files_in_dir(folder_path):
                return True

            # Also check centralized parent spike_detection exports.
            parent = os.path.dirname(folder_path)
            sd_dir = os.path.join(parent, 'spike_detection')
            folder_name = os.path.basename(folder_path)
            if os.path.isfile(os.path.join(sd_dir, folder_name + '_analyzed.npz')):
                return True
            if glob.glob(os.path.join(sd_dir, folder_name + '*_analyzed.npz')):
                return True
        except Exception:
            return False
        return False

    def _count_sessions_and_cells(self, candidates):
        """Return (n_sessions, total_cells, cells_per_session list)
        candidates: list of file or directory paths"""
        total_cells = 0
        cells_per = []
        for s in candidates:
            try:
                if os.path.isfile(s):
                    if s.lower().endswith('.npz'):
                        npz = np.load(s, allow_pickle=True)
                        n = len(npz['cell_names']) if 'cell_names' in npz else 0
                    elif s.lower().endswith('.xlsx') or s.lower().endswith('.csv'):
                        # read header only
                        if s.lower().endswith('.xlsx'):
                            df = pd.read_excel(s, nrows=0, engine='openpyxl')
                        else:
                            df = pd.read_csv(s, nrows=0)
                        n = max(0, df.shape[1] - 1)
                    else:
                        n = 0
                else:
                    # directory: look for analyzed npz or xlsx inside
                    npz_list = glob.glob(os.path.join(s, '*_analyzed.npz'))
                    table_list = self._list_table_files_in_dir(s)
                    if npz_list:
                        npz = np.load(npz_list[0], allow_pickle=True)
                        n = len(npz['cell_names']) if 'cell_names' in npz else 0
                    elif table_list:
                        first_tbl = table_list[0]
                        if first_tbl.lower().endswith('.xlsx'):
                            df = pd.read_excel(first_tbl, nrows=0, engine='openpyxl')
                        else:
                            df = pd.read_csv(first_tbl, nrows=0)
                        n = max(0, df.shape[1] - 1)
                    else:
                        n = 0
            except Exception:
                n = 0
            cells_per.append(n)
            total_cells += n
        return len(candidates), total_cells, cells_per
    def open_slider_viewer(self):
        if self.data is None:
            QMessageBox.warning(self, 'No data', 'Load a session first')
            return
        dlg = SliderViewerDialog(self.data, parent=self)
        dlg.exec()

    def run_detection_all(self):
        if getattr(self, '_detection_running', False):
            return 0, 0
        self._detection_running = True
        self.centralWidget().setEnabled(False)
        try:
            self._sync_detection_controls_to_params()
            self.on_template_controls_changed()
            self.on_detection_tab_changed(self.tabs_detection.currentIndex())
            self._denoise_cache.clear()
            return self._run_detection_all()
        finally:
            self.centralWidget().setEnabled(True)
            self._detection_running = False

    def _run_detection_all(self):
        """Synchronous driver retained for programmatic callers and tests."""
        steps = self._detection_steps()
        try:
            kind, job = next(steps)
            done = 0
            total = sum(d['raw_data'].shape[1] for d in self.loaded_sessions.values()
                        if isinstance(d, dict) and 'raw_data' in d)
            self._detection_done, self._detection_total = 0, total
            self._set_detection_progress(done, total)
            while True:
                try:
                    result = job()
                except Exception as exc:
                    kind, job = steps.throw(exc)
                else:
                    if kind == 'cell':
                        done += 1
                        self._detection_done = done
                        self._set_detection_progress(done, total)
                    kind, job = steps.send(result)
        except StopIteration as stop:
            sessions, cells = stop.value or (0, 0)
            self.detection_progress.setFormat(f'Finished: {sessions} sessions, {cells} cells')
            return sessions, cells

    def _set_detection_progress(self, done, total):
        self.detection_progress.setRange(0, max(1, total))
        self.detection_progress.setValue(done)
        self.detection_progress.setFormat(f'{done}/{total} cells · %p%')

    def start_detection_async(self, open_viewer=False):
        """Run every expensive cell calculation on a worker thread."""
        if getattr(self, '_detection_running', False):
            return False
        self._sync_detection_controls_to_params()
        self.on_template_controls_changed()
        self.on_detection_tab_changed(self.tabs_detection.currentIndex())
        self._denoise_cache.clear()
        self._detection_running = True
        self._open_viewer_after_detection = bool(open_viewer)
        self._detection_done = 0
        self._detection_total = sum(d['raw_data'].shape[1] for d in self.loaded_sessions.values()
                                    if isinstance(d, dict) and 'raw_data' in d)
        self._set_detection_progress(0, self._detection_total)
        self.centralWidget().setEnabled(False)
        self._detection_iterator = self._detection_steps()
        self._detection_started = False
        self._detection_threads = []
        QtCore.QTimer.singleShot(0, lambda: self._advance_detection())
        return True

    def _advance_detection(self, result=None, error=None):
        try:
            if error is not None:
                kind, job = self._detection_iterator.throw(error)
            elif self._detection_started:
                kind, job = self._detection_iterator.send(result)
            else:
                kind, job = next(self._detection_iterator)
                self._detection_started = True
                self._detection_total = sum(d['raw_data'].shape[1]
                    for d in self.loaded_sessions.values()
                    if isinstance(d, dict) and 'raw_data' in d)
                self._set_detection_progress(0, self._detection_total)
        except StopIteration as stop:
            sessions, cells = stop.value or (0, 0)
            self._finish_detection_async(sessions, cells)
            return
        except Exception as exc:
            self.text_stats.append(f'Detection error: {exc}')
            self._finish_detection_async(0, 0)
            return
        self._active_detection_job_kind = kind
        worker = _DetectionCellThread(job, self)
        self._active_detection_thread = worker
        self._detection_threads.append(worker)
        worker.result_ready.connect(self._cell_detection_ready)
        worker.finished.connect(lambda w=worker: self._detection_threads.remove(w)
                                if w in self._detection_threads else None)
        worker.finished.connect(worker.deleteLater)
        worker.start()

    def _cell_detection_ready(self, result, error):
        # result_ready is emitted immediately before QThread.run returns.
        # Reap it before reporting completion or allowing the window to close.
        self._active_detection_thread.wait(1000)
        if self._active_detection_job_kind == 'cell':
            self._detection_done += 1
            self._set_detection_progress(self._detection_done, self._detection_total)
        QtCore.QTimer.singleShot(0, lambda: self._advance_detection(result, error))

    def _finish_detection_async(self, sessions, cells):
        self._detection_running = False
        self.centralWidget().setEnabled(True)
        self.detection_progress.setFormat(f'Finished: {sessions} sessions, {cells} cells'
                                          if sessions else 'No results')
        self.detection_completed.emit(sessions, cells)
        if self._open_viewer_after_detection and sessions:
            selected = self.loaded_sessions.get(self.selected_session, {})
            if any(r is not None for r in selected.get('results', [])):
                QtCore.QTimer.singleShot(0, self.open_detection_viewer)

    def closeEvent(self, event):
        if getattr(self, '_label_save_worker', None) is not None:
            event.ignore()
            self.statusBar().showMessage('Labels are being saved; close after saving finishes.')
            return
        if getattr(self, '_saved_load_worker', None) is not None:
            event.ignore()
            self.statusBar().showMessage('Saved session is still loading; close after it finishes.')
            return
        if (getattr(self, '_detection_running', False) or
                any(thread.isRunning() for thread in getattr(self, '_detection_threads', []))):
            event.ignore()
            self.statusBar().showMessage('Detection is still running; close after it finishes.')
            return
        if self._template_records or any(d.get('dirty') for d in self._label_drafts.values()):
            answer = QMessageBox.question(self, 'Unsaved Annotations',
                'Discard unsaved labels/template selections and close?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Cancel)
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
        try:
            self._temporary_store.close()
        except OSError as exc:
            self.statusBar().showMessage(f'Temporary cleanup deferred to next launch: {exc}')
        super().closeEvent(event)

    def _confirm_result_replacement(self, paths):
        box = QMessageBox(self)
        box.setWindowTitle('Replace saved detection results?')
        box.setIcon(QMessageBox.Icon.Warning)
        box.setText('Saved detection results already exist. Replace these results and their settings files?')
        box.setInformativeText(f'{len(paths)} existing files. Expand Details to review the paths.')
        box.setDetailedText('\n'.join(str(path) for path in paths))
        box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel)
        box.setDefaultButton(QMessageBox.StandardButton.Cancel)
        return box.exec() == QMessageBox.StandardButton.Yes

    def _detection_steps(self):
        if self.template_selection_active:
            QMessageBox.warning(self, 'Annotation Active', 'Save Labels / Save Templates or Abort before starting detection.')
            return 0, 0
        if not self.sessions:
            QMessageBox.warning(self, 'No data', 'No sessions loaded. Select a folder first.')
            return 0, 0

        combo_enabled = bool(self.params.get('COMBO_DETECTION', False))
        detection_method = 'Template Matching' if combo_enabled else self.params.get('DETECTION_METHOD', 'Threshold')
        if detection_method == 'Template Matching' and not combo_enabled:
            cs_n = len(self.template_store.get('cs_templates', []))
            ss_n = len(self.template_store.get('ss_templates', []))
            if cs_n == 0 and ss_n == 0:
                QMessageBox.warning(self, 'Templates missing', 'Template Matching is selected, but no CS/SS template is loaded.')
                return 0, 0

        if len(self.session_names) < len(self.sessions):
            self.session_names = [
                self.session_names[i] if i < len(self.session_names) and self.session_names[i] else os.path.basename(p)
                for i, p in enumerate(self.sessions)
            ]

        # Ensure all sessions from the session list are loaded into memory
        for idx, session_path in enumerate(self.sessions):
            try:
                session_name = self.session_names[idx]
            except Exception:
                session_name = os.path.basename(session_path)
            if session_name not in self.loaded_sessions:
                d = self.load_session(session_path)
                if d is not None:
                    self.loaded_sessions[session_name] = d

        save_requested = bool(self.params.get('SAVE_DETECTION_RESULTS', False))
        plans = {name: output_paths(self.loaded_sessions[name], self.master_folder)
                 for name in self.session_names if name in self.loaded_sessions}
        existing = sorted({path for _, paths in plans.values() for path in paths if path.exists()})
        if save_requested and existing and not self._confirm_result_replacement(existing):
            self.text_stats.setPlainText('Detection cancelled; saved results preserved.')
            return 0, 0
        approved_existing = {str(path.resolve()) for path in existing} if save_requested else set()

        total_cells = 0
        sessions_done = 0
        n_saved_main = 0
        n_saved_temp = 0
        run_errors = []
        completed_names = []

        # Aggregation containers for global statistics across all sessions/cells
        global_cs_rates = []
        global_ss_rates = []
        global_cs_snrs = []
        global_ss_snrs = []
        global_cs_fwhm = []
        global_ss_fwhm = []

        session_items = []
        for idx, session_path in enumerate(self.sessions):
            try:
                sname = self.session_names[idx]
            except Exception:
                sname = os.path.basename(session_path)
            session_items.append((idx, sname))

        n_sessions = len(session_items)
        for sess_idx, sname in session_items:
            data = self.loaded_sessions.get(sname, None)
            if data is None:
                continue
            try:
                # announce session start
                try:
                    if hasattr(self, 'text_stats') and self.text_stats is not None:
                        # single-line status: overwrite with current session
                        self.text_stats.setPlainText(f"Processing session {sess_idx+1}/{n_sessions}: {sname}")
                        QtWidgets.QApplication.processEvents()
                except Exception:
                    pass
                fs = validate_session(data)
                effective = effective_settings(self.params, self.baseline_params,
                    self.spin_avg_frames.value(), fs, len(data['time_ms']))
                data['effective_settings'] = effective
                n_cells = data['raw_data'].shape[1]
                for key in ('loaded_detection_result', '_saved_settings_snapshot',
                            '_saved_detection_params', 'processed_raw_data', 'baseline_traces',
                            'is_manual_labels', 'label_metadata', 'analysis_valid_mask', 'result_method'):
                    data.pop(key, None)
                data.pop('results_file', None)
                data.pop('settings_file', None)
                data['results'] = [None] * n_cells
                data['spike_times_cs'] = [np.array([])] * n_cells
                data['spike_times_ss'] = [np.array([])] * n_cells
                data['_control_context'] = {
                    'params': dict(self.params),
                    'baseline_params': dict(self.baseline_params),
                    'frames': int(self.spin_avg_frames.value()),
                    'frame_mode': self._get_frame_processing_mode(),
                    'templates': {key: list(value) for key, value in self.template_store.items()},
                    'denoise_cfg': self._get_denoise_config(),
                }
                for i in range(n_cells):
                    raw = data['raw_data'][:, i]
                    frames = int(self.spin_avg_frames.value())
                    frame_mode = self._get_frame_processing_mode()
                    params = dict(self.params)
                    baseline_params = dict(self.baseline_params)
                    templates = {key: list(value) for key, value in self.template_store.items()}
                    denoise_cfg = self._get_denoise_config()
                    res = yield ('cell', lambda raw=raw, fs=fs, params=params,
                        baseline_params=baseline_params, frames=frames,
                        frame_mode=frame_mode, templates=templates, denoise_cfg=denoise_cfg:
                        _detect_cell(raw, fs, params, baseline_params, frames,
                                     frame_mode, templates, denoise_cfg))
                    res = self._apply_ss_fwhm_filter(res, data, i)
                    data['results'][i] = res
                    data['spike_times_cs'][i] = np.asarray(data['time_ms'])[res['cs_peaks']]
                    data['spike_times_ss'][i] = np.asarray(data['time_ms'])[res['ss_peaks']]
                total_cells += n_cells
                sessions_done += 1
                completed_names.append(sname)
                # Prepare temporary viewing exports; optionally publish beside the source
                try:
                    self.detection_progress.setFormat(f'Saving session {sess_idx+1}/{n_sessions}…')
                    QtWidgets.QApplication.processEvents()
                    session_src = data.get('session_path', None)
                    base = sname
                    if session_src and os.path.isfile(session_src):
                        base = os.path.splitext(os.path.basename(session_src))[0]
                    base = data.get('output_basename', base)
                    # Always stage complete viewing exports before publication.
                    save_target = str(self._temporary_store.allocate(base))
                    # Prepare arrays for saving to match notebook structure and downstream analyses.
                    try:
                        save_payload = self._build_detection_export(data)
                        yield ('save', lambda save_target=save_target, payload=save_payload:
                               np.savez_compressed(save_target, **payload))
                        settings_target = os.path.splitext(save_target)[0] + '_settings.json'
                        settings_snapshot = self._current_settings_snapshot()
                        settings_snapshot.update({
                            'settings_kind': 'spike_detection_sidecar',
                            'results_file': os.path.basename(save_target),
                            'analysis_settings': json.loads(save_payload['analysis_settings_json']),
                        })
                        with open(settings_target, 'w', encoding='utf-8') as f:
                            json.dump(settings_snapshot, f, indent=2)
                        data['results_file'] = save_target
                        data['settings_file'] = settings_target
                        data['temporary_result'] = True
                        n_saved_temp += 1
                        if save_requested:
                            destination = plans[sname][0]
                            yield ('save', lambda result=save_target, settings=settings_target, dest=destination:
                                publish_detection(result, settings, dest, approved_existing))
                            data['results_file'] = str(destination)
                            data['settings_file'] = str(destination.with_name(destination.stem + '_settings.json'))
                            data['temporary_result'] = False
                            n_saved_temp -= 1
                            n_saved_main += 1
                            os.remove(save_target)
                            os.remove(settings_target)
                        self._set_detection_progress(
                            getattr(self, '_detection_done', total_cells),
                            getattr(self, '_detection_total', sum(
                                d['raw_data'].shape[1] for d in self.loaded_sessions.values()
                                if isinstance(d, dict) and 'raw_data' in d)))
                        # update single-line status to indicate session finished
                        try:
                            if hasattr(self, 'text_stats') and self.text_stats is not None:
                                self.text_stats.setPlainText(f"Finished session {sess_idx+1}/{n_sessions}: {sname}")
                                QtWidgets.QApplication.processEvents()
                        except Exception:
                            pass
                    except Exception as e:
                        run_errors.append(f"Save failed: {sname}: {e}")
                        print(run_errors[-1])
                except Exception:
                    pass
            except Exception as e:
                # continue on error with other sessions
                data.pop('results_file', None)
                data.pop('settings_file', None)
                data['results'] = [None] * len(data.get('cell_names', []))
                data['spike_times_cs'] = [np.array([]) for _ in data['results']]
                data['spike_times_ss'] = [np.array([]) for _ in data['results']]
                run_errors.append(f"Detection failed: {sname}: {e}")
                print(run_errors[-1])
                continue
        # After all sessions processed: compute overall averaged statistics across sessions/cells
        try:
            for sname in completed_names:
                data = self.loaded_sessions[sname]
                try:
                    res_list = data.get('results', [])
                    if not res_list:
                        continue
                    fs = float(data.get('fs', 1000.0))
                    tvec = np.array(data.get('time_ms', []))
                    duration_s = tvec.size / fs if tvec.size > 1 else np.nan
                    for cell_idx, res in enumerate(res_list):
                        if res is None:
                            continue
                        trace_for_stats = self._get_waveform_source_trace_for_stats(data, cell_idx)
                        global_cs_fwhm.extend(row['fwhm_ms'] for row in res.get('event_widths_cs', []) if np.isfinite(row['fwhm_ms']))
                        global_ss_fwhm.extend(row['fwhm_ms'] for row in res.get('event_widths_ss', []) if np.isfinite(row['fwhm_ms']))
                        try:
                            if duration_s and duration_s > 0:
                                global_cs_rates.append(len(res.get('cs_peaks', [])) / (np.sum(~res.get('recording_exclusion_mask', np.zeros(len(tvec), bool)))/fs))
                                global_ss_rates.append(len(res.get('ss_peaks', [])) / (np.sum(~res.get('recording_exclusion_mask', np.zeros(len(tvec), bool)))/fs))
                        except Exception:
                            pass
                        # CS events
                        try:
                            cs_window_ms = _stats_window_ms('CS')
                            cs_half_win = int((cs_window_ms / 2.0) * fs / 1000.0)
                            cs_peaks = np.array(res.get('cs_peaks', []), dtype=int)
                            cs_source = np.asarray(trace_for_stats, dtype=float) if trace_for_stats is not None else res.get('cs_trace', None)
                            if cs_source is not None and cs_peaks.size > 0:
                                cs_event_snrs = compute_event_snrs(
                                    res,
                                    'CS',
                                    fs,
                                    window_ms=cs_window_ms,
                                    max_per_cell=None,
                                    trace_override=cs_source,
                                )
                                global_cs_snrs.extend(cs_event_snrs)
                        except Exception:
                            pass
                        # SS events
                        try:
                            ss_window_ms = _stats_window_ms('SS')
                            ss_half_win = int((ss_window_ms / 2.0) * fs / 1000.0)
                            ss_peaks = np.array(res.get('ss_peaks', []), dtype=int)
                            ss_source = np.asarray(trace_for_stats, dtype=float) if trace_for_stats is not None else (res.get('ss_trace', None) if res.get('ss_trace', None) is not None else res.get('detrended', None))
                            if ss_source is not None and ss_peaks.size > 0:
                                ss_event_snrs = compute_event_snrs(
                                    res,
                                    'SS',
                                    fs,
                                    window_ms=ss_window_ms,
                                    max_per_cell=None,
                                    trace_override=ss_source,
                                )
                                global_ss_snrs.extend(ss_event_snrs)
                        except Exception:
                            pass
                except Exception:
                    continue
            cs_r_mean, cs_r_std, cs_r_n = mean_std_count(global_cs_rates)
            ss_r_mean, ss_r_std, ss_r_n = mean_std_count(global_ss_rates)
            cs_snr_mean, cs_snr_std, cs_snr_n = mean_std_count(global_cs_snrs)
            ss_snr_mean, ss_snr_std, ss_snr_n = mean_std_count(global_ss_snrs)
            cs_fwhm_mean, cs_fwhm_std, cs_fwhm_n = mean_std_count(global_cs_fwhm)
            ss_fwhm_mean, ss_fwhm_std, ss_fwhm_n = mean_std_count(global_ss_fwhm)

            # Replace info panel content with concise overall summary
            try:
                if hasattr(self, 'text_stats') and self.text_stats is not None:
                    summary = []
                    summary.append(f'Detection finished: {sessions_done} sessions, {total_cells} cells')
                    if getattr(self, 'batch_folders', []):
                        summary.append(f'Batch paths: {len(self.batch_folders)}')
                        for folder in self.batch_folders:
                            folder_names = [n for n in self.session_names
                                            if self.loaded_sessions[n].get('source_folder') == folder]
                            done = [n for n in folder_names if n in completed_names]
                            cells = sum(self.loaded_sessions[n]['raw_data'].shape[1] for n in done)
                            summary.append(f'  {folder}: {len(done)}/{len(folder_names)} sessions, {cells} cells')
                        summary.extend(getattr(self, 'batch_load_issues', []))
                    summary.extend(run_errors)
                    if bool(self.params.get('SAVE_DETECTION_RESULTS', False)):
                        summary.append('Save: ON (permanent exports; existing results require confirmation)')
                    else:
                        summary.append('Save: OFF (temporary viewing exports; cleaned on close or next launch)')
                    summary.append(f'Saved files: {n_saved_main} main, {n_saved_temp} temporary')
                    summary.append(f"Method: {detection_method}")
                    if combo_enabled:
                        summary.append('Combo: Threshold seeds → temporary cell/session templates → template matching')
                        summary.append(f"Seed cutoffs: CS {self.params['CS_THRESHOLD_SIGMA']:g}, SS {self.params['SS_THRESHOLD_SIGMA']:g} × MAD; minimum 3 clean seeds per type")
                        for name in completed_names:
                            for cell, res in zip(self.loaded_sessions[name]['cell_names'], self.loaded_sessions[name]['results']):
                                info = res['combo']
                                summary.append(f"  {name} / {cell}: " + '; '.join(
                                    f"{kind.upper()} {info[kind]['seeds']} seeds, {info[kind]['clean']} clean, {info[kind]['kernels']} kernels ({info[kind]['source']})"
                                    for kind in ('cs', 'ss')))
                    summary.append('Rates: events / full recording duration (including excluded intervals)')
                    summary.append(f'SS exclusion: before CS {mask_windows(self.params)[0]:g} ms; after CS {mask_windows(self.params)[1]:g} ms')
                    for name in completed_names:
                        sd = self.loaded_sessions[name]
                        ef = sd['effective_settings']
                        summary.append(f"  {name}: input time={self.loaded_sessions[name].get('input_time_unit', 'ms')}, fs={ef['fs_hz']:g} Hz, baseline={ef['baseline_window_ms']:g} ms; filters={ef['filters']}")
                        for warning in self.loaded_sessions[name].get('load_warnings', []):
                            summary.append(f'  Input warning: {warning}')
                    uncertain = sum(r.get('ss_fwhm_filter_uncertain', 0) for name in completed_names for r in self.loaded_sessions[name]['results'])
                    cs_uncertain = sum(row['decision'] == 'uncertain' for name in completed_names for r in self.loaded_sessions[name]['results'] for row in r.get('event_widths_cs', []))
                    summary.append(f'Uncertain widths retained, excluded from width summaries: CS {cs_uncertain}; SS {uncertain}')
                    if detection_method == 'Template Matching':
                        template_method = self.params.get('TEMPLATE_MATCH_METHOD', 'LLR Probability Vector')
                        template_method_label = ('Amplitude-fit LLR (Gaussian)'
                            if template_method == 'LLR Probability Vector' else
                            'Positive-core LLR (experimental)'
                            if template_method == 'Burst-aware LLR' else template_method)
                        summary.append(
                            f"Template mode: {template_method_label} | "
                            + ('Loaded fallback banks: ' if combo_enabled else '') +
                            f"CS templates: {len(self.template_store.get('cs_templates', []))}, "
                            f"SS templates: {len(self.template_store.get('ss_templates', []))}"
                        )
                        selection_text = ('automatic groups: all supported; manual group choices apply to fallback banks'
                            if combo_enabled else
                            f"CS enabled={self.params.get('TEMPLATE_CS_SELECTED_GROUPS') or 'all'}, "
                            f"SS enabled={self.params.get('TEMPLATE_SS_SELECTED_GROUPS') or 'all'}")
                        summary.append(f"Parallel matching: {'ON' if bool(self.params.get('TEMPLATE_PARALLEL', False)) else 'OFF'}; "
                                       f"groups={self.params.get('TEMPLATE_PARALLEL_GROUPS', 3)}, "
                                       f"PCA components={self.params.get('TEMPLATE_PARALLEL_COMPONENTS', 2)}; "
                                       + selection_text)
                        summary.append(f"SS spacing: {self.params.get('SS_MIN_DIST_MS', 4.0):.2f} ms (Advanced Settings)")
                        whitening_counts = {'applied': 0, 'skipped': 0}
                        whitening_reasons = set()
                        for session in (self.loaded_sessions[name] for name in completed_names):
                            for result in session.get('results', []):
                                if not result:
                                    continue
                                report = result.get('template_whitening', {})
                                if report.get('requested'):
                                    for kind in ('cs', 'ss'):
                                        status = report.get(kind, {})
                                        whitening_counts['applied' if status.get('applied') else 'skipped'] += 1
                                        if not status.get('applied'):
                                            whitening_reasons.add(status.get('reason', 'unavailable'))
                        summary.append(f"Noise whitening: {'ON' if self.params.get('TEMPLATE_WHITENING', False) else 'OFF'}; "
                            f"applied to {whitening_counts['applied']} cell/type tracks, skipped {whitening_counts['skipped']}" +
                            (f" ({'; '.join(sorted(whitening_reasons))})" if whitening_reasons else ''))
                        summary.append(f"Template SS low-pass: {self.params.get('TEMPLATE_SS_LOWPASS_HZ', 700.0):g} Hz; SS widths measured on filtered detection trace")
                        if self.params.get('TEMPLATE_MATCH_METHOD') == 'Normalized Similarity':
                            summary.append(
                                f"Similarity thresholds: CS r={self.params.get('TEMPLATE_CS_SIMILARITY', 0.90):.2f}, "
                                f"SS r={self.params.get('TEMPLATE_SS_SIMILARITY', 0.80):.2f}; "
                                "amplitude/width checks use Spike QC"
                            )
                        else:
                            summary.append(
                                f"Template response/MAD cutoffs (not calibrated z-scores): "
                                f"CS={self.params.get('TEMPLATE_CS_SIGMA', 30.0):.2f}, "
                                f"SS={self.params.get('TEMPLATE_SS_SIGMA', 5.0):.2f}; "
                                "amplitude/width checks use Spike QC"
                            )
                            if self.params.get('TEMPLATE_MATCH_METHOD') == 'Burst-aware LLR':
                                summary.append('Experimental positive-core SS: positive 3 ms template core; '
                                    'no anchor, proximity, or full-waveform correlation gate. '
                                    'CS uses standard amplitude-fit LLR.')
                        for spike_type in ('cs', 'ss'):
                            reports = [r.get(f'{spike_type}_candidate_diagnostics', {})
                                       for name in completed_names for r in self.loaded_sessions[name]['results'] if r is not None]
                            counts = [('score peaks', 'score_peaks'), ('masked', 'masked'),
                                      ('matched response rejected', 'response_rejected')]
                            counts.append(('spacing rejected', 'refractory_rejected'))
                            summary.append(f"{spike_type.upper()} candidates: " + ', '.join(
                                f'{label} {sum(int(report.get(key, 0)) for report in reports)}'
                                for label, key in counts))
                    else:
                        summary.append(
                            f"Simple threshold criteria: SS height >= {self.params.get('SS_THRESHOLD_SIGMA', 3.0):.2f}xMAD, "
                            f"CS FWHM > {self.params.get('CS_MIN_FWHM_MS', 4.0):.2f} ms, "
                            f"SS min distance = {self.params.get('SS_MIN_DIST_MS', 4.0):.2f} ms, "
                            f"SS pre/post exclusion = {mask_windows(self.params)[0]:.2f}/{mask_windows(self.params)[1]:.2f} ms, "
                            f"SS max FWHM = "
                            f"({self.params.get('SS_MAX_FWHM_MS', 4.5):.2f} ms), "
                            f"initial blank = {self.params.get('INITIAL_BLANK_MS', 150.0):.2f} ms"
                        )
                    summary.append('Spike QC: ' + '; '.join(
                        f"{kind}: min amplitude SNR {self.params[f'{kind}_MIN_AMPLITUDE_SNR']:g}, FWHM {self.params[f'{kind}_MIN_FWHM_MS']:g}–{self.params[f'{kind}_MAX_FWHM_MS']:g} ms" for kind in ('CS', 'SS')))
                    for kind in ('cs', 'ss'):
                        qc_reports = [r.get('spike_qc', {}).get(kind, {}) for name in completed_names
                                      for r in self.loaded_sessions[name]['results'] if r is not None]
                        summary.append(f'{kind.upper()} QC: ' + ', '.join(
                            f"{label} {sum(report.get(key, 0) for report in qc_reports)}"
                            for label, key in [('amplitude SNR rejected', 'amplitude_rejected'),
                                ('SNR unavailable', 'amplitude_unavailable'), ('width rejected', 'width_rejected')] ))
                    summary.append('Overall CS:')
                    summary.append(f'  Rate: {cs_r_mean:.2f}±{cs_r_std:.2f} Hz (cells: {cs_r_n}) | SNR: {cs_snr_mean:.2f}±{cs_snr_std:.2f} (events: {cs_snr_n}) | FWHM: {cs_fwhm_mean:.2f}±{cs_fwhm_std:.2f} ms (events: {cs_fwhm_n})')
                    summary.append('Overall SS:')
                    summary.append(f'  Rate: {ss_r_mean:.2f}±{ss_r_std:.2f} Hz (cells: {ss_r_n}) | SNR: {ss_snr_mean:.2f}±{ss_snr_std:.2f} (events: {ss_snr_n}) | FWHM: {ss_fwhm_mean:.2f}±{ss_fwhm_std:.2f} ms (events: {ss_fwhm_n})')
                    self.text_stats.setPlainText('\n'.join(summary))
                    self._scroll_info_to_bottom()
            except Exception:
                pass
        except Exception:
            pass

        return sessions_done, total_cells

    def _build_detection_export(self, data, settings=None):
        settings = copy.deepcopy(settings if settings is not None else self._current_settings_snapshot())
        params, baseline_params = settings['params'], settings['baseline_params']
        time_ms = np.array(data.get('time_ms', []))
        raw_data = np.array(data.get('raw_data', []))
        fs_save = float(data.get('fs', 1000.0))
        avg_frames_save = int(settings['ui']['avg_frames'])
        frame_mode_save = params.get('FRAME_PROCESSING_MODE', 'Rolling average')
        # Build cs_traces and ss_traces column-stacked if results exist
        cs_traces = np.array([])
        ss_traces = np.array([])
        raw_sigmas = np.array([])
        processed_raw_data = np.array([])
        baseline_traces = np.array([])
        event_snr_cs = []
        event_snr_ss = []
        event_fwhm_cs = []
        event_fwhm_ss = []
        event_minus_dff_percent_cs = []
        event_minus_dff_percent_ss = []
        event_waveforms_minus_dff_percent_cs = []
        event_waveforms_minus_dff_percent_ss = []
        res_list = data.get('results', [])
        if res_list and len(time_ms) > 0:
            n_samples = len(time_ms)
            cs_traces = np.column_stack([r.get('cs_trace', np.zeros(n_samples)) if r is not None else np.zeros(n_samples) for r in res_list])
            ss_traces = np.column_stack([r.get('ss_trace', np.zeros(n_samples)) if r is not None else np.zeros(n_samples) for r in res_list])
            raw_sigmas = np.array([r.get('raw_sigma', np.nan) if r is not None else np.nan for r in res_list])
            proc_cols = []
            base_cols = []
            for cell_i in range(raw_data.shape[1] if raw_data.ndim == 2 else 0):
                raw_cell_i = np.asarray(raw_data[:, cell_i], dtype=float)
                raw_proc_i, base_i, _ = protected_preprocess(raw_cell_i, fs_save, params, baseline_params, avg_frames_save, frame_mode_save)
                proc_cols.append(np.asarray(raw_proc_i, dtype=float))
                base_cols.append(np.asarray(base_i, dtype=float))
            if len(proc_cols) > 0:
                processed_raw_data = np.column_stack(proc_cols)
                baseline_traces = np.column_stack(base_cols)

            def _minus_dff_at_event(raw_proc_arr, baseline_arr, peak_idx, spike_type):
                p0 = int(peak_idx)
                n = int(raw_proc_arr.size)
                win_ms = _stats_window_ms(spike_type)
                half = max(2, int(round((win_ms * 0.25 / 1000.0) * fs_save)))
                s0 = max(0, p0 - half)
                e0 = min(n, p0 + half + 1)
                if e0 <= s0:
                    return np.nan
                local = np.asarray(raw_proc_arr[s0:e0]).copy()
                valid_here = ~data['results'][0]['recording_exclusion_mask'][s0:e0]
                local[~valid_here] = np.nan
                if not np.any(np.isfinite(local)):
                    return np.nan
                if bool(params.get('NEGATIVE_GOING', True)):
                    pk = int(s0 + np.nanargmin(local))
                else:
                    pk = int(s0 + np.nanargmax(local))
                f0 = float(baseline_arr[pk]) if 0 <= pk < baseline_arr.size else np.nan
                if (not np.isfinite(f0)) or abs(f0) <= 1e-12:
                    return np.nan
                dff = 100.0 * (float(raw_proc_arr[pk]) - f0) / abs(f0)
                return float(-dff if bool(params.get('NEGATIVE_GOING', True)) else dff)

            def _event_waveforms_minus_dff(raw_proc_arr, baseline_arr, peaks, spike_type):
                out = []
                half = int(round((_stats_window_ms(spike_type) / 2.0 / 1000.0) * fs_save))
                if half < 2:
                    return np.array([], dtype=object)
                for pp in np.asarray(peaks, dtype=int).ravel():
                    s0 = int(pp) - half
                    e0 = int(pp) + half
                    if s0 < 0 or e0 > raw_proc_arr.size or np.any(data['results'][0]['recording_exclusion_mask'][s0:e0]):
                        continue
                    denom = np.where(np.abs(baseline_arr[s0:e0]) > 1e-12, np.abs(baseline_arr[s0:e0]), np.nan)
                    w = 100.0 * (raw_proc_arr[s0:e0] - baseline_arr[s0:e0]) / denom
                    if bool(params.get('NEGATIVE_GOING', True)):
                        w = -w
                    out.append(np.asarray(w, dtype=float))
                return np.array(out, dtype=object)

            for cell_i, r in enumerate(res_list):
                if r is None:
                    event_snr_cs.append(np.array([], dtype=float))
                    event_snr_ss.append(np.array([], dtype=float))
                    event_fwhm_cs.append(np.array([], dtype=float))
                    event_fwhm_ss.append(np.array([], dtype=float))
                    event_minus_dff_percent_cs.append(np.array([], dtype=float))
                    event_minus_dff_percent_ss.append(np.array([], dtype=float))
                    event_waveforms_minus_dff_percent_cs.append(np.array([], dtype=object))
                    event_waveforms_minus_dff_percent_ss.append(np.array([], dtype=object))
                    continue
                trace_stats = self._get_waveform_source_trace_for_stats(data, cell_i)
                if trace_stats is None:
                    trace_stats = np.asarray(r.get('detrended', np.zeros(n_samples)), dtype=float)
                cs_peaks_i = np.asarray(r.get('cs_peaks', []), dtype=int)
                ss_peaks_i = np.asarray(r.get('ss_peaks', []), dtype=int)
                try:
                    cs_snr_i = np.asarray(compute_event_snrs(r, 'CS', fs_save, window_ms=_stats_window_ms('CS'), max_per_cell=None, trace_override=trace_stats), dtype=float)
                except Exception:
                    cs_snr_i = np.array([], dtype=float)
                try:
                    ss_snr_i = np.asarray(compute_event_snrs(r, 'SS', fs_save, window_ms=_stats_window_ms('SS'), max_per_cell=None, trace_override=trace_stats), dtype=float)
                except Exception:
                    ss_snr_i = np.array([], dtype=float)
                cs_fwhm_i = np.asarray([row['fwhm_ms'] for row in r.get('event_widths_cs', [])], dtype=float)
                ss_fwhm_i = np.asarray([row['fwhm_ms'] for row in r.get('event_widths_ss', [])], dtype=float)
                if len(cs_snr_i) != len(cs_peaks_i) or len(ss_snr_i) != len(ss_peaks_i):
                    raise ValueError('Event SNR export does not match the labelled/detected event count.')
                raw_proc_i = processed_raw_data[:, cell_i] if processed_raw_data.ndim == 2 and cell_i < processed_raw_data.shape[1] else np.asarray(raw_data[:, cell_i], dtype=float)
                base_i = baseline_traces[:, cell_i] if baseline_traces.ndim == 2 and cell_i < baseline_traces.shape[1] else np.zeros_like(raw_proc_i)
                event_snr_cs.append(cs_snr_i)
                event_snr_ss.append(ss_snr_i)
                event_fwhm_cs.append(cs_fwhm_i)
                event_fwhm_ss.append(ss_fwhm_i)
                event_minus_dff_percent_cs.append(np.asarray([_minus_dff_at_event(raw_proc_i, base_i, pp, 'CS') for pp in cs_peaks_i], dtype=float))
                event_minus_dff_percent_ss.append(np.asarray([_minus_dff_at_event(raw_proc_i, base_i, pp, 'SS') for pp in ss_peaks_i], dtype=float))
                for kind, peaks, values in (('cs', cs_peaks_i, event_minus_dff_percent_cs[-1]), ('ss', ss_peaks_i, event_minus_dff_percent_ss[-1])):
                    r['event_minus_dff_percent_'+kind] = values.copy()
                    r['dff_indices_'+kind] = peaks.copy()
                event_waveforms_minus_dff_percent_cs.append(_event_waveforms_minus_dff(raw_proc_i, base_i, cs_peaks_i, 'CS'))
                event_waveforms_minus_dff_percent_ss.append(_event_waveforms_minus_dff(raw_proc_i, base_i, ss_peaks_i, 'SS'))
        else:
            cs_traces = np.array([])
            ss_traces = np.array([])
            raw_sigmas = np.array([])


        analysis_settings = {
            'app_version': APP_VERSION,
            'detection_method': data.get('result_method', params.get('DETECTION_METHOD', 'Threshold')),
            'combo_detection': bool(params.get('COMBO_DETECTION', False)),
            'template_whitening_cells': [res.get('template_whitening') for res in data['results']],
            'combo_cells': [res.get('combo') for res in data['results']] if params.get('COMBO_DETECTION') else [],
            'timestamp_convention': 'input time_ms, original origin preserved',
            'input_time_unit': data.get('input_time_unit', 'ms'),
            'input_warnings': list(data.get('load_warnings', [])),
            'effective_settings': data.get('effective_settings', {}),
            'width_policy': 'candidate-centered; uncertain retained with NaN',
            'observation_policy': 'initial/final blanks excluded before preprocessing, detection and analysis; analysis_valid_mask is authoritative; raw_data retains original excluded samples for viewing',
            'ss_mask_policy': 'pre/post exclusion without signal zeroing; template support also excluded',
            'baseline_params': dict(baseline_params),
            'frame_processing_mode': frame_mode_save,
            'avg_frames': int(avg_frames_save),
            'negative_going': bool(params.get('NEGATIVE_GOING', True)),
            'params': dict(params),
            'stats_windows_ms': {'CS': _stats_window_ms('CS'), 'SS': _stats_window_ms('SS')},
            'event_snr_policy': dict(EVENT_SNR_POLICY),
            'event_metric_units': {
                'event_minus_dff_percent': '-dF/F (%) for negative-going traces',
                'event_snr': 'amplitude / local MAD sigma, matching Spike Statistics',
                'event_fwhm_ms': 'FWHM in ms, matching Spike Statistics source traces',
            },
        }

        cs_masks = np.column_stack([r['cs_exclusion_mask'] for r in data['results']])
        ss_masks = np.column_stack([r['ss_exclusion_mask'] for r in data['results']])
        width_report = [{key: r.get(key, []) for key in
            ('cs_width_candidates', 'ss_width_candidates', 'event_widths_cs', 'event_widths_ss')}
            for r in data['results']]
        width_report = [{key: [{field: (None if isinstance(value, (float, np.floating)) and not np.isfinite(value) else value)
            for field, value in row.items()} for row in rows] for key, rows in cell.items()} for cell in width_report]
        runtime_fields = ('det_method', 'threshold_mode', 'negative_going', 'local_baseline',
            'sigma_cs', 'sigma_ss', 'cs_threshold_used', 'ss_threshold_used',
            'cs_candidate_diagnostics', 'ss_candidate_diagnostics', 'width_alignment_ms',
            'template_whitening', 'combo', 'denoise_enabled', 'denoise_meta',
            'ss_fwhm_filter_removed', 'ss_fwhm_filter_uncertain', 'ss_width_source',
            'cs_detection_enabled', 'ss_detection_enabled', 'manual_labels')
        runtime = [{key: r[key] for key in runtime_fields if key in r} for r in data['results']]
        extra_traces = {key + 's': np.column_stack([
            r.get(key, np.full(n_samples, np.nan)) for r in data['results']])
            for key in ('cs_similarity_trace', 'ss_similarity_trace', 'cs_threshold_trace', 'ss_threshold_trace')}
        save_payload = dict(
                            **extra_traces,
                            source_session_json=json.dumps(dict(source_session_id=self._annotation_session_id(data), output_basename=output_paths(data, self.master_folder)[0].stem.removesuffix('_analyzed'))),
                            analysis_valid_mask=~np.asarray(data['results'][0]['recording_exclusion_mask'], dtype=bool),
                            detection_runtime_json=json.dumps(json_safe(runtime), allow_nan=False),
                            gui_settings_json=json.dumps(settings),
                            cs_exclusion_mask=cs_masks, ss_exclusion_mask=ss_masks,
                            recording_duration_s=len(time_ms)/fs_save,
                            analysis_duration_s=float(np.sum(~data['results'][0]['recording_exclusion_mask'])/fs_save),
                            valid_duration_cs_s=np.sum(~cs_masks, axis=0)/fs_save,
                            valid_duration_ss_s=np.sum(~ss_masks, axis=0)/fs_save,
                            width_quality_json=json.dumps(width_report, allow_nan=False),
                            spike_qc_json=json.dumps([r.get('spike_qc', {}) for r in data['results']], allow_nan=False),
                            time_ms=time_ms,
                            raw_data=raw_data,
                            processed_raw_data=processed_raw_data,
                            baseline_traces=baseline_traces,
                            cs_traces=cs_traces,
                            ss_traces=ss_traces,
                            spike_times_cs=np.array(data.get('spike_times_cs', []), dtype=object),
                            spike_times_ss=np.array(data.get('spike_times_ss', []), dtype=object),
                            cell_names=np.array(data.get('cell_names', [])),
                            fs=fs_save,
                            raw_sigmas=raw_sigmas,
                            event_snr_cs=np.array(event_snr_cs, dtype=object),
                            event_snr_ss=np.array(event_snr_ss, dtype=object),
                            event_fwhm_cs=np.array(event_fwhm_cs, dtype=object),
                            event_fwhm_ss=np.array(event_fwhm_ss, dtype=object),
                            event_minus_dff_percent_cs=np.array(event_minus_dff_percent_cs, dtype=object),
                            event_minus_dff_percent_ss=np.array(event_minus_dff_percent_ss, dtype=object),
                            event_waveforms_minus_dff_percent_cs=np.array(event_waveforms_minus_dff_percent_cs, dtype=object),
                            event_waveforms_minus_dff_percent_ss=np.array(event_waveforms_minus_dff_percent_ss, dtype=object),
                            analysis_settings_json=json.dumps(analysis_settings),
                            baseline_params_json=json.dumps(dict(baseline_params)),
                            detection_params_json=json.dumps(dict(params)))
        return save_payload

    def open_detection_viewer(self):
        # prefer using currently selected session data from loaded_sessions
        data = None
        if self.selected_session and self.selected_session in self.loaded_sessions:
            data = self.loaded_sessions[self.selected_session]
        elif self.data is not None:
            data = self.data
        if data is None or 'results' not in data:
            QMessageBox.warning(self, 'No detection', 'Run detection first (Spike Detection).')
            return
        # Ensure results contain at least one non-empty entry for plotting
        try:
            results = data.get('results', [])
            if not any([r is not None for r in results]):
                QMessageBox.warning(self, 'No detection', 'Run detection first (Spike Detection). No valid results found.')
                return
        except Exception:
            QMessageBox.warning(self, 'No detection', 'Run detection first (Spike Detection).')
            return
        dlg = DetectionViewerDialog(data, parent=self)
        dlg.exec()

    def open_stats_viewer(self):
        if self.data is None or 'results' not in self.data:
            QMessageBox.warning(self, 'No detection', 'Run detection first (Run Detection (all cells)).')
            return
        dlg = StatsViewerDialog(self.data, parent=self)
        dlg.exec()

    def open_template_viewer(self):
        dlg = TemplateViewerDialog(self.template_store, parent=self)
        dlg.exec()

    def reset_app(self):
        try:
            buttons = QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            reply = QMessageBox.question(self, 'Reset App', 'Reset application state and clear loaded sessions?', buttons)
            yes_btn = QMessageBox.StandardButton.Yes
        except Exception:
            # Fallback for bindings where StandardButton namespace differs
            buttons = QMessageBox.Yes | QMessageBox.No if hasattr(QMessageBox, 'Yes') else 1 | 0
            reply = QMessageBox.question(self, 'Reset App', 'Reset application state and clear loaded sessions?', buttons)
            yes_btn = QMessageBox.Yes if hasattr(QMessageBox, 'Yes') else 1
        if reply != yes_btn:
            return False
        # Clear loaded data and UI
        try:
            self.loaded_sessions = {}
            self._template_records.clear(); self._label_drafts.clear()
            self.template_selection_active = False
            self._reset_template_selection_button_text()
            self._denoise_cache = {}
            self.batch_folders = []
            self.batch_load_issues = []
            self.sessions = []
            self.session_names = []
            self.list_sessions.clear()
            self.combo_cell.clear()
            self.data = None
            self.selected_session = None
            self.selected_cell = 0
            # reset params to defaults
            self.params = {
                'NEGATIVE_GOING': True,
                'DETECTION_METHOD': 'Threshold',
                'COMBO_DETECTION': False,
                'SAVE_DETECTION_RESULTS': False,
                'CS_LOW_CUT_HZ': 0.0,
                'CS_HIGH_CUT_HZ': 150.0,
                'CS_THRESHOLD_SIGMA': 6.0,
                'CS_MIN_DIST_MS': 25.0,
                'CS_MIN_FWHM_MS': 4.0,
                'CS_MAX_FWHM_MS': 0.0,
                'CS_MIN_AMPLITUDE_SNR': 0.0,
                'SS_MIN_AMPLITUDE_SNR': 0.0,
                'SS_MIN_FWHM_MS': 0.0,
                'SS_LOW_CUT_HZ': 0.0,
                'SS_HIGH_CUT_HZ': 0.0,
                'SS_THRESHOLD_SIGMA': 3.0,
                'SS_MIN_DIST_MS': 4.0,
                'SS_BLANK_MS': 18.0,
                'SS_MAX_FWHM_MS': 4.5,
                'INITIAL_BLANK_MS': 150.0,
                'FINAL_BLANK_MS': 50.0,
                'CS_FILTER_ORDER': 4,
                'SS_FILTER_ORDER': 4,
                'FRAME_PROCESSING_MODE': 'Rolling average',
                'TEMPLATE_CS_WINDOW_MS': 30.0,
                'TEMPLATE_SS_WINDOW_MS': 8.0,
                'TEMPLATE_MATCH_METHOD': 'LLR Probability Vector',
                'TEMPLATE_PARALLEL': False,
                'TEMPLATE_WHITENING': False,
                'TEMPLATE_PARALLEL_GROUPS': 3,
                'TEMPLATE_PARALLEL_COMPONENTS': 2,
                'TEMPLATE_CS_SELECTED_GROUPS': None,
                'TEMPLATE_SS_SELECTED_GROUPS': None,
                'TEMPLATE_CS_SIGMA': 30.0,
                'TEMPLATE_SS_SIGMA': 5.0,
                'TEMPLATE_CS_SIMILARITY': 0.90,
                'TEMPLATE_SS_SIMILARITY': 0.80,
                'TEMPLATE_SS_LOWPASS_HZ': 700.0,
                'LOCAL_BASELINE': False,
                'LOCAL_BASELINE_SS_MS': 50.0,
                'LOCAL_BASELINE_CS_MS': 200.0,
                'DENOISE_ENABLED': False,
                'DENOISE_APPLY_TO_CS': False,
                'DENOISE_F_MIN_HZ': 3.0,
                'DENOISE_F_MAX_HZ': 1000.0,
                'DENOISE_N_FREQS': 72,
                'DENOISE_MAX_CLUSTERS': 20,
                'DENOISE_MIN_CLUSTERS': 2,
                'DENOISE_MAX_PCA_COMPONENTS': 20,
                'DENOISE_THRESHOLD_SIGMA': 1.5,
                'DENOISE_ATTENUATION_MIN': 0.25,
                'DENOISE_SOFT_THRESHOLD': False,
                'DENOISE_MOVING_CYCLES': 1.0,
                'DENOISE_MAX_TIMEPOINTS_FOR_CLUSTERING': 10000,
                'DENOISE_EVENT_REFINE_ENABLED': True,
                'DENOISE_EVENT_REFINE_WINDOW_MS': 20.0,
                'DENOISE_EVENT_REFINE_SIGMA': 2.0,
                'DENOISE_EVENT_REFINE_PC1_Z_CUTOFF': -0.5,
                'DENOISE_EVENT_REFINE_ATTENUATION': 0.6,
                'LINE_WIDTH_SCALE': 0.7,
                'RAW_SCALE_BAR_UNIT': 'Sigma',
                'STATS_CS_BG_ALPHA': 0.3,
                'STATS_SS_BG_ALPHA': 0.003,
                'STATS_DISTRIBUTION_BINS': 20,
                'STATS_PETH_PRE_MS': 20.0,
                'STATS_PETH_POST_MS': 60.0,
                'STATS_PETH_BIN_MS': 1.0,
                'STATS_SS_TREND_S': 5.0,
                'STATS_CS_TREND_S': 5.0,
                'DETECTION_VIEW_WINDOW_MS': 1000.0,
                'DETECTION_VIEW_Y_RANGE': 0.0,
                'DETECTION_VIEW_CENTER': 0,
                'DETECTION_VIEW_AUTO_START': True,
                'SLIDER_VIEW_Y_RANGE': 0.0,
                'SLIDER_VIEW_CENTER': 0,
                'SLIDER_VIEW_AUTO_START': True,
                'DENOISE_SHOW_ADVANCED': False,
            }
            # Template widget signals write back all matching controls together.
            # Read reset targets from an immutable snapshot while restoring them.
            template_defaults = dict(self.params)
            self._sync_polarity_buttons()
            self._restore_qc_controls(self.params)
            _set_user_linewidth_scale(self.params.get('LINE_WIDTH_SCALE', 0.7))
            self.template_store = {
                'cs_templates': [],
                'ss_templates': [],
                'fs_cs': [],
                'fs_ss': [],
                'cs_sources': [],
                'ss_sources': [],
            }
            # reset baseline params and UI controls
            self.baseline_params = {
                'method': 'Median',
                'window_ms': 30.0,
                'percentile': 20.0,
            }
            self.combo_baseline_method.setCurrentText(self.baseline_params['method'])
            self.slider_time.setValue(0)
            self.spin_window.setValue(1000.0)
            self._main_view_auto_start = True
            self.spin_baseline_window.setValue(self.baseline_params['window_ms'])
            self.spin_baseline_percentile.setValue(self.baseline_params['percentile'])
            # reset detection UI controls
            try:
                self.spin_cs_low.setValue(self.params['CS_LOW_CUT_HZ'])
                self.chk_combo.setChecked(False)
                self.spin_cs_high.setValue(self.params['CS_HIGH_CUT_HZ'])
                self.spin_cs_thresh.setValue(self.params['CS_THRESHOLD_SIGMA'])
                # CS min dist moved to Advanced Settings — keep parent.params in sync
                # ensure main UI does not refer to removed widget
                self.spin_ss_low.setValue(self.params['SS_LOW_CUT_HZ'])
                self.spin_ss_high.setValue(self.params['SS_HIGH_CUT_HZ'])
                self.spin_ss_thresh.setValue(self.params['SS_THRESHOLD_SIGMA'])
                self.spin_ss_blank.setValue(self.params['SS_BLANK_MS'])
                self._set_frame_processing_mode(self.params['FRAME_PROCESSING_MODE'])
                self.combo_template_method.setCurrentIndex(max(0, self.combo_template_method.findData(
                    template_defaults['TEMPLATE_MATCH_METHOD'])))
                if hasattr(self, 'chk_template_parallel') and self.chk_template_parallel is not None:
                    self.chk_template_parallel.setChecked(bool(template_defaults.get('TEMPLATE_PARALLEL', False)))
                self.chk_template_whitening.setChecked(False)
                self.spin_template_groups.setValue(template_defaults['TEMPLATE_PARALLEL_GROUPS'])
                self.spin_template_cs_sigma.setValue(template_defaults['TEMPLATE_CS_SIGMA'])
                self.spin_template_ss_sigma.setValue(template_defaults['TEMPLATE_SS_SIGMA'])
                self.spin_template_cs_sim.setValue(template_defaults['TEMPLATE_CS_SIMILARITY'])
                self.spin_template_ss_sim.setValue(template_defaults['TEMPLATE_SS_SIMILARITY'])
                self.spin_template_lowpass.setValue(template_defaults['TEMPLATE_SS_LOWPASS_HZ'])
                if hasattr(self, 'chk_local_baseline') and self.chk_local_baseline is not None:
                    self.chk_local_baseline.setChecked(False)
                if hasattr(self, 'spin_local_ss_ms') and self.spin_local_ss_ms is not None:
                    self.spin_local_ss_ms.setValue(50.0)
                if hasattr(self, 'spin_local_cs_ms') and self.spin_local_cs_ms is not None:
                    self.spin_local_cs_ms.setValue(200.0)
            except Exception:
                pass
            try:
                if hasattr(self, 'tabs_detection') and self.tabs_detection is not None:
                    self.tabs_detection.setCurrentIndex(0)
                if hasattr(self, 'chk_detection_save') and self.chk_detection_save is not None:
                    self.chk_detection_save.setChecked(False)
                self.update_template_status_label()
            except Exception:
                pass
            # clear canvas and stats
            try:
                self.canvas.figure.clf()
                self.canvas.ax = self.canvas.figure.add_subplot(111)
                self.canvas.draw()
            except Exception:
                pass
            try:
                self.text_stats.clear()
            except Exception:
                pass
        except Exception as e:
            QMessageBox.critical(self, 'Reset Error', f'Failed to reset application: {e}')
            return False
        return True

    def refresh_sessions(self):
        if not self.master_folder:
            QMessageBox.warning(self, 'No folder', 'Please select a master folder first.')
            return
        self._main_view_auto_start = True
        self.batch_folders = []
        self.batch_load_issues = []
        self._denoise_cache.clear()
        self.data = None
        self.selected_session = None
        candidates = []
        names = []
        preloaded = {}
        skipped_invalid = 0
        import_errors = []
        import_errors.extend(cleanup_legacy_temporaries(self.master_folder))
        # Top-level files only: do not traverse subfolders for session discovery.
        try:
            default_fs = float(self.params.get('FS', 1000.0))
            for name in sorted(os.listdir(self.master_folder)):
                fp = os.path.join(self.master_folder, name)
                if not os.path.isfile(fp) or is_excel_lock_file(fp):
                    continue
                ext = os.path.splitext(name)[1].lower()
                if ext in {'.xlsx', '.csv', '.npz'}:
                    try:
                        data = load_session_path(fp, default_fs=default_fs, time_unit='auto')
                        raw = np.asarray(data.get('raw_data', []), dtype=float)
                        t = np.asarray(data.get('time_ms', []), dtype=float)
                        cell_names = list(data.get('cell_names', []))
                        if raw.ndim != 2 or raw.shape[0] < 2 or raw.shape[1] < 1 or t.size < 2 or len(cell_names) < 1:
                            skipped_invalid += 1
                            continue
                        candidates.append(fp)
                        names.append(name)
                        preloaded[name] = data
                    except Exception as exc:
                        skipped_invalid += 1
                        import_errors.append(f'{name}: {exc}')
        except Exception:
            pass
        self.sessions = candidates
        self.session_names = names
        # populate compact combo box
        self.list_sessions.clear()
        for n in self.session_names:
            self.list_sessions.addItem(n)
        self.loaded_sessions = preloaded
        try:
            self.statusBar().showMessage(
                f'Master folder: {self.master_folder} | sessions: {len(candidates)}, skipped invalid: {skipped_invalid}'
            )
        except Exception:
            pass
        if self.sessions:
            # set current index and explicitly call handler to load session
            self.list_sessions.setCurrentIndex(0)
            try:
                self.on_session_select(0)
            except Exception:
                pass

        if import_errors:
            self.text_stats.setPlainText('Import rejected files:\n' + '\n'.join(import_errors))

    def on_session_select(self, idx=None):
        # idx may be passed from QComboBox signal or we read currentIndex
        try:
            if idx is None:
                idx = int(self.list_sessions.currentIndex())
        except Exception:
            return
        if idx < 0 or idx >= len(self.sessions):
            return
        session_path = self.sessions[idx]
        session_name = self.session_names[idx]
        self.selected_session = session_name
        if session_name not in self.loaded_sessions:
            data = self.load_session(session_path)
            if data is not None:
                self.loaded_sessions[session_name] = data
        # set current data reference for single-session visualizations
        if self.selected_session in self.loaded_sessions:
            self.data = self.loaded_sessions[self.selected_session]
            self.selected_cell = 0
            if self.data.get('loaded_detection_result'):
                self._restore_saved_run_settings(self.data)
        self.update_cell_selector()
        self.update_plot()

    def load_session(self, session_path):
        try:
            return load_session_path(session_path, default_fs=float(self.params.get('FS', 1000.0)), time_unit='auto')
        except FileNotFoundError as e:
            QMessageBox.warning(self, 'No data', str(e))
            return None
        except ValueError as e:
            QMessageBox.warning(self, 'Unsupported file', str(e))
            return None
        except Exception as e:
            QMessageBox.warning(self, 'Load error', f'Failed to load session: {e}')
            return None

    def update_cell_selector(self):
        self.combo_cell.clear()
        if self.selected_session and self.selected_session in self.loaded_sessions:
            data = self.loaded_sessions[self.selected_session]
            for name in data['cell_names']:
                self.combo_cell.addItem(name)
            self.combo_cell.setCurrentIndex(0)
            self.selected_cell = 0

    def on_cell_change(self):
        self.selected_cell = self.combo_cell.currentIndex()
        self.update_plot()

    def update_info_text(self):
        if not self.selected_session or self.selected_session not in self.loaded_sessions:
            return
        data = self.loaded_sessions[self.selected_session]
        idx = max(0, self.selected_cell)
        t = data['time_ms']
        duration_s = len(t) / float(data['fs'])
        n_samples = len(t)
        fs = float(data['fs'])
        txt = f"Session: {self.selected_session}\n"
        session_path = data.get('session_path', None) or data.get('path', None) or data.get('source_path', None)
        if session_path:
            txt += f"Path: {session_path}\n"
        txt += f"Cell: {data['cell_names'][idx]}\n"
        txt += f"Input time unit: {data.get('input_time_unit', 'ms')} (automatic)\n"
        txt += f"Duration: {duration_s:.2f} s\n"
        observed = data.get('analysis_valid_mask', observation_mask(len(t), fs, self.params))
        txt += f"Observed for analysis: {np.sum(observed)/fs:.3f} s (recording boundary blanks excluded)\n"
        txt += f"Samples: {n_samples}\n"
        for warning in data.get('load_warnings', []):
            txt += f"Input warning: {warning}\n"
        txt += f"Fs: {fs:.0f} Hz"
        if self.template_selection_active and self.template_selection_type == 'LABEL':
            txt += '\nManual label measurements use the preprocessing snapshot captured for this session at entry.'
        if data.get('loaded_detection_result'):
            txt += '\nSaved detection loaded; displaying recorded preprocessing. Edited settings apply to a new detection.'
            txt += f"\nResults: {data['results_file']}"
            for warning in getattr(self, '_settings_restore_warnings', []):
                txt += f'\nTemplate source unavailable: {warning}'
        self.text_stats.setPlainText(txt)
        self._scroll_info_to_top()

    def _scroll_info_to_bottom(self):
        try:
            cursor = self.text_stats.textCursor()
            cursor.movePosition(QtGui.QTextCursor.MoveOperation.End)
            self.text_stats.setTextCursor(cursor)
        except Exception:
            try:
                self.text_stats.moveCursor(QtGui.QTextCursor.End)
            except Exception:
                pass
        try:
            bar = self.text_stats.verticalScrollBar()
            bar.setValue(bar.maximum())
        except Exception:
            pass

    def _scroll_info_to_top(self):
        try:
            bar = self.text_stats.verticalScrollBar()
            bar.setValue(bar.minimum())
        except Exception:
            pass

    def on_slider_time_changed(self):
        self._main_view_auto_start = False
        self.slider_position = self.slider_time.value() / 1000.0
        self.update_plot()

    def on_window_changed(self):
        # Update window size from control and refresh plot
        try:
            self.window_ms = float(self.spin_window.value())
        except Exception:
            self.window_ms = float(self.window_ms)
        self.update_plot()

    def update_plot(self):
        self.canvas.figure.clf()
        ax = self.canvas.figure.add_subplot(111)
        # ensure top and right spines are hidden even when no data is plotted
        try:
            ax.spines['top'].set_visible(False)
        except Exception:
            pass
        try:
            ax.spines['right'].set_visible(False)
        except Exception:
            pass
        if not self.selected_session or self.selected_session not in self.loaded_sessions:
            ax.text(0.5, 0.5, 'No data loaded', ha='center')
            self.canvas.draw()
            return
        data = self.loaded_sessions[self.selected_session]
        idx = max(0, self.selected_cell)
        raw = data['raw_data'][:, idx]
        t = data['time_ms']
        fs = float(data['fs'])
        # Apply averaging (smoothing) if requested, then compute baseline on processed signal
        frames = int(self.spin_avg_frames.value()) if hasattr(self, 'spin_avg_frames') else 0
        saved_view = bool(data.get('loaded_detection_result'))
        if saved_view:
            raw_proc = _display_processed_raw(data, idx)
            baseline = np.asarray(data['baseline_traces'][:, idx])
        else:
            raw_proc, baseline, _ = protected_preprocess(raw, fs, self.params, self.baseline_params, frames, self._get_frame_processing_mode())
        # Use the first observed timestamp until the user explicitly navigates.
        start_time, end_time = _trace_view_window(data, data.get('_saved_detection_params', self.params),
            float(self.spin_window.value()), self.slider_time.value(), self._main_view_auto_start)
        mask = (t >= start_time) & (t <= end_time)
        # Plot: either raw + baseline OR baseline-corrected (replace raw)
        # If baseline method is 'Disable', do not apply or show baseline correction
        # Plot selection: raw / baseline-corrected / CS-filter / SS-filter (CS/SS mutually exclusive)
        method = (data['_saved_settings_snapshot']['baseline_params'].get('method', '')
                  if saved_view else self.baseline_params.get('method', ''))
        use_baseline_vis = (method != 'Disable' and getattr(self, 'chk_show_baseline', None) and self.chk_show_baseline.isChecked())
        try:
            vis_source = (raw_proc - baseline) if use_baseline_vis else raw_proc
        except Exception:
            vis_source = raw_proc

        denoise_meta = None
        if not saved_view and bool(self.params.get('DENOISE_ENABLED', False)):
            try:
                corrected_src = np.asarray(raw_proc - baseline, dtype=float)
                cache_key = (self.selected_session, int(idx), 'main_plot')
                vis_source, denoise_meta = self._apply_denoise_trace(corrected_src, fs, cache_key=cache_key)
            except Exception:
                denoise_meta = {'ok': False, 'error': 'preview_denoise_failed'}
                vis_source = np.asarray(vis_source, dtype=float)

        # If any of the visualization checkboxes are active, force black plotting
        # and suppress figure legend for clarity per user request.
        try:
            any_vis_override = False
            if (getattr(self, 'chk_show_baseline', None) and self.chk_show_baseline.isChecked()) or \
               (getattr(self, 'chk_show_cs', None) and self.chk_show_cs.isChecked()) or \
               (getattr(self, 'chk_show_ss', None) and self.chk_show_ss.isChecked()):
                any_vis_override = True
            # Determine the main display color when override is active (follow raw color scheme)
            if any_vis_override:
                try:
                    color_main = self.colors.get('raw', '#333333')
                except Exception:
                    color_main = '#333333'
            else:
                color_main = None
        except Exception:
            any_vis_override = False
            color_main = None

        # If CS filter visualization is requested
        if getattr(self, 'chk_show_cs', None) and self.chk_show_cs.isChecked():
            try:
                cs_vis = (data['results'][idx]['cs_trace'] * (-1 if data['results'][idx]['negative_going'] else 1) if saved_view else protected_filter(vis_source, fs, self.params, low=float(self.spin_cs_low.value()), high=float(self.spin_cs_high.value()), order=int(self.spin_cs_order.value())))
                vis_for_ylim = cs_vis
                plot_color = color_main if color_main is not None else self.colors.get('baseline', '#FFC20A')
                ax.plot(t[mask], cs_vis[mask], color=plot_color, lw=_get_linewidth(1.2), label='CS filter')
            except Exception:
                vis_for_ylim = vis_source
                plot_color = color_main if color_main is not None else self.colors.get('raw', '#333333')
                ax.plot(t[mask], vis_source[mask], color=plot_color, lw=_get_linewidth(1), label='Raw')

        # If SS filter visualization is requested
        elif getattr(self, 'chk_show_ss', None) and self.chk_show_ss.isChecked():
            try:
                ss_vis = (data['results'][idx]['ss_trace'] * (-1 if data['results'][idx]['negative_going'] else 1) if saved_view else protected_filter(vis_source, fs, self.params, low=float(self.spin_ss_low.value()), high=float(self.spin_ss_high.value()), order=int(self.spin_ss_order.value())))
                vis_for_ylim = ss_vis
                plot_color = color_main if color_main is not None else '#2ca02c'
                ax.plot(t[mask], ss_vis[mask], color=plot_color, lw=_get_linewidth(1.2), label='SS filter')
            except Exception:
                vis_for_ylim = vis_source
                plot_color = color_main if color_main is not None else self.colors.get('raw', '#333333')
                ax.plot(t[mask], vis_source[mask], color=plot_color, lw=_get_linewidth(1), label='Raw')

        else:
            # Default: plot raw or baseline-corrected depending on checkbox
            vis_for_ylim = vis_source
            if not saved_view and bool(self.params.get('DENOISE_ENABLED', False)):
                lbl = 'Denoised'
            else:
                lbl = 'Baseline-corrected' if use_baseline_vis else 'Raw'
            plot_color = color_main if color_main is not None else self.colors.get('raw', '#333333')
            ax.plot(t[mask], vis_source[mask], color=plot_color, alpha=0.9, lw=_get_linewidth(1), label=lbl)
            # Optionally overlay baseline (when baseline method active and available)
            try:
                # Hide baseline overlay when simplified/black view is active
                if not any_vis_override and method != 'Disable' and baseline is not None:
                    ax.plot(t[mask], baseline[mask], color=self.colors.get('baseline', '#FFC20A'), ls='--', lw=_get_linewidth(2), label='Baseline')
            except Exception:
                pass

        try:
            if bool(self.params.get('DENOISE_ENABLED', False)) and isinstance(denoise_meta, dict):
                info = 'k=na'
                if denoise_meta.get('ok', False):
                    k = int(denoise_meta.get('n_clusters', 1))
                    atten = 100.0 * float(np.mean(np.asarray(denoise_meta.get('attenuation_mask', np.ones_like(vis_source))) < 0.99))
                    info = f'k={k}, atten={atten:.1f}%'
                ax.text(0.98, 0.96, f'Denoising ON ({info})', ha='right', va='top', fontsize=10, transform=ax.transAxes)
        except Exception:
            pass

        # Draw shaded selected template intervals (current type)
        try:
            for tp, col in [('CS', '#009E73'), ('SS', '#D55E00')]:
                intervals = [(r['start_ms'], r['end_ms']) for r in self._template_records if r['kind'] == tp and r['session_id'] == self._annotation_session_id() and r['cell'] == idx]
                for s_ms, e_ms in intervals:
                    if e_ms < start_time or s_ms > end_time:
                        continue
                    ax.axvspan(max(s_ms, start_time), min(e_ms, end_time), color=col, alpha=0.18, lw=0)
        except Exception:
            pass
        ax.set_xlabel('Time (ms)')
        ax.set_ylabel('Signal')
        if ((self.template_selection_active and self.template_selection_type == 'LABEL') or
                (data.get('is_manual_labels') and not self.template_selection_active)):
            try:
                draft = (self._label_draft() if self.template_selection_active else dict(
                    settings=data['_saved_settings_snapshot'], events=[{kind: r[kind.lower()+'_peaks'].tolist()
                        for kind in ('CS','SS')} for r in data['results']]))
            except (ValueError, OSError) as exc:
                draft = None
                self.statusBar().showMessage(str(exc))
            if draft is None:
                self.canvas.draw()
                return
            negative = bool(draft['settings']['params'].get('NEGATIVE_GOING', True))
            rail = .96 if not negative else .04
            for kind, color in (('CS', self.colors.get('cs_trace', '#009E73')), ('SS', self.colors.get('ss_trace', '#D55E00'))):
                points = draft['events'][idx][kind]
                for peak in points:
                    if start_time <= t[peak] <= end_time:
                        ax.plot([t[peak]], [rail], marker='_' if kind == 'CS' else '|', ls='None',
                            markersize=12, markeredgewidth=2, color=color, transform=ax.get_xaxis_transform(), gid='manual_'+kind.lower())
        valid_recording = (observation_mask(len(t), fs, draft['settings']['params']) if self.template_selection_active and self.template_selection_type == 'LABEL' else
                           data.get('analysis_valid_mask') if saved_view else observation_mask(len(t), fs, self.params))
        if valid_recording is not None:
            for left, right in recording_intervals_ms(t, fs, np.asarray(valid_recording, bool)):
                if right >= start_time and left <= end_time:
                    ax.axvspan(left, right, color='#888888', alpha=.12, lw=0, gid='boundary_blank')

        # tidy legend (no frame) unless user requested simplified black view
        try:
            if not any_vis_override:
                ax.legend(frameon=False, loc='lower left', bbox_to_anchor=(0, 1.01), ncol=2)
        except Exception:
            pass
        try:
            ax.spines['top'].set_visible(False)
        except Exception:
            pass
        try:
            ax.spines['right'].set_visible(False)
        except Exception:
            pass
        # Y-Range semantics: if spin_zoom (Y-Range) > 0, center plot on trace and show that full range.
        # If 0 => auto-scale with padding.
        y_range = float(self.spin_zoom.value()) if hasattr(self, 'spin_zoom') else 0.0
        scale_mask = mask & np.asarray(valid_recording, bool) if valid_recording is not None else mask
        if not np.any(scale_mask):
            scale_mask = mask
        if np.any(mask):
            v = vis_for_ylim[scale_mask]
            vmin = np.min(v); vmax = np.max(v)
            span = vmax - vmin
            local_std = np.std(v) if len(v) > 0 else 1.0
            if y_range <= 0.0:
                pad = max(span * 0.05, local_std * 0.5, 1e-9)
                ax.set_ylim(vmin - pad, vmax + pad)
            else:
                center = 0.5 * (vmax + vmin)
                half_range = float(y_range) / 2.0
                ax.set_ylim(center - half_range, center + half_range)
            ax.set_xlim(start_time, end_time)
        self.canvas.figure.tight_layout()
        try:
            self.canvas.draw_idle()
        except Exception:
            self.canvas.draw()
        self.update_info_text()
    def compute_baseline(self, trace, fs):
        method = self.baseline_params['method']
        window_ms = self.baseline_params['window_ms']
        window_samples = int(window_ms * fs / 1000.0)
        # safety caps to avoid extreme window sizes that kill performance
        max_samples_cap = max(5, min(len(trace)//2, 5000))
        if window_samples < 5:
            window_samples = 5
        if window_samples > max_samples_cap:
            window_samples = max_samples_cap
        if method == 'Percentile':
            percentile = self.baseline_params['percentile']
            baseline = percentile_filter(trace, percentile, size=window_samples)
        elif method == 'Median':
            from scipy.ndimage import median_filter
            baseline = median_filter(trace, size=window_samples)
        else:
            baseline = trace * 0
        return baseline

    def export_figure(self):
        if self.data is None:
            QMessageBox.warning(self, 'No data', 'Load a session and plot something first.')
            return
        try:
            filename = save_figure_with_dialog(
                lambda title, default, flt: QFileDialog.getSaveFileName(self, title, default, flt),
                self.canvas.figure,
                default_name='figure.svg',
            )
            if filename:
                QMessageBox.information(self, 'Saved', f'Figure saved as {filename}')
        except Exception as e:
            QMessageBox.critical(self, 'Error', f'Failed to save figure: {e}')
class BatchDetectionDialog(QtWidgets.QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle('Batch detection')
        self.resize(*_scaled_size(760, 460))
        self._running = False
        layout = QtWidgets.QVBoxLayout(self)
        label = QtWidgets.QLabel(
            'Enter one folder path per line, add folders, or import a text list.\n'
            'Each folder uses the current main GUI detection settings and templates.\n'
            'Only top-level CSV, XLSX and NPZ sessions are loaded. Results are saved\n'
            'temporarily for viewing, or in each folder’s spike_detection directory when save is checked.')
        label.setWordWrap(True)
        layout.addWidget(label)
        self.paths = QtWidgets.QPlainTextEdit()
        self.paths.setPlaceholderText('/path/to/folder1\n/path/to/folder2')
        self.paths.setPlainText('\n'.join(getattr(parent, 'batch_folders', [])))
        layout.addWidget(self.paths)
        row = QtWidgets.QHBoxLayout()
        self.add_button = QtWidgets.QPushButton('Add folder…')
        self.add_button.clicked.connect(self.add_folder)
        self.import_button = QtWidgets.QPushButton('Load path list…')
        self.import_button.clicked.connect(self.import_paths)
        self.run_button = QtWidgets.QPushButton('Run batch detection')
        self.run_button.clicked.connect(self.run_batch)
        self.close_button = QtWidgets.QPushButton('Close')
        self.close_button.clicked.connect(self.reject)
        for button in (self.add_button, self.import_button, self.run_button, self.close_button):
            row.addWidget(button)
        layout.addLayout(row)
        self.status = QtWidgets.QLabel('Ready. Set detection options in the main GUI before running.')
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.issue_details = QtWidgets.QPlainTextEdit()
        self.issue_details.setReadOnly(True)
        self.issue_details.setMaximumHeight(_scaled_size(100, 110)[1])
        self.issue_details.hide()
        layout.addWidget(self.issue_details)
        _apply_setting_tooltips(self)

    def add_folder(self):
        path = QFileDialog.getExistingDirectory(self, 'Add batch folder', os.path.expanduser('~'))
        if path:
            self.paths.appendPlainText(path)

    def import_paths(self):
        filename, _ = QFileDialog.getOpenFileName(self, 'Load folder paths', '', 'Text files (*.txt);;All files (*)')
        if not filename:
            return
        try:
            with open(filename, encoding='utf-8-sig') as stream:
                lines = stream.read().splitlines()
            # Relative entries in imported lists are relative to that list file.
            from .utils.batch import normalize_folder_paths
            self.paths.appendPlainText('\n'.join(normalize_folder_paths(
                lines, base_dir=os.path.dirname(filename))))
        except (OSError, UnicodeError) as exc:
            QMessageBox.warning(self, 'Path list error', str(exc))

    def run_batch(self):
        if self._running:
            return
        parent = self.parent()
        if getattr(parent, '_detection_running', False):
            self.status.setText('Detection is already running in the main window.')
            return
        if not self.paths.toPlainText().strip():
            QMessageBox.warning(self, 'No paths', 'Enter at least one folder path.')
            return
        parent.on_detection_tab_changed(parent.tabs_detection.currentIndex())
        if (parent.params.get('DETECTION_METHOD') == 'Template Matching' and not parent.params.get('COMBO_DETECTION') and
                not any(len(parent.template_store.get(key, [])) for key in ('cs_templates', 'ss_templates'))):
            QMessageBox.warning(self, 'Templates missing', 'Load CS or SS templates in the main GUI first.')
            return
        self._running = True
        self.issue_details.clear()
        self.issue_details.hide()
        self.close_button.setText('Close (detection continues)')
        for widget in (self.paths, self.add_button, self.import_button, self.run_button):
            widget.setEnabled(False)
        try:
            self.status.setText('Loading folders…')
            QtWidgets.QApplication.processEvents()
            parent.load_batch_folders(self.paths.toPlainText().splitlines())
            if parent.batch_load_issues:
                self.issue_details.setPlainText('\n'.join(parent.batch_load_issues))
                self.issue_details.show()
            self.status.setText(f'Processing {len(parent.batch_folders)} paths. Progress appears at the bottom of the main window…')
            parent.detection_completed.connect(self._batch_finished)
            if not parent.start_detection_async():
                parent.detection_completed.disconnect(self._batch_finished)
                raise RuntimeError('Detection is already running.')
        except Exception as exc:
            self.status.setText(f'Batch failed: {exc}')
            self.issue_details.setPlainText('\n'.join(parent.batch_load_issues) or str(exc))
            self.issue_details.show()
            self._running = False
            self.close_button.setText('Close')
            for widget in (self.paths, self.add_button, self.import_button, self.run_button):
                widget.setEnabled(True)

    def _batch_finished(self, sessions, cells):
        try:
            self.parent().detection_completed.disconnect(self._batch_finished)
        except (TypeError, RuntimeError):
            pass
        self.status.setText(f'Finished: {sessions} sessions, {cells} cells. See Info for all paths and any errors. '
                            'Close this window to view Spike Statistics → Path / Session / Cell.')
        self._running = False
        self.close_button.setText('Close')
        for widget in (self.paths, self.add_button, self.import_button, self.run_button):
            widget.setEnabled(True)

    def reject(self):
        super().reject()


class DetectionSettingsDialog(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Detection Settings')
        self.resize(*_scaled_size(400, 400))
        self.parent_win = parent
        layout = QtWidgets.QVBoxLayout()
        form = QtWidgets.QFormLayout()
        p = parent.params if parent is not None else {}
        # Filtering settings
        self.spin_cs_low = QtWidgets.QDoubleSpinBox(); self.spin_cs_low.setRange(0.0, 5000.0); self.spin_cs_low.setValue(p.get('CS_LOW_CUT_HZ',0.0))
        self.spin_cs_high = QtWidgets.QDoubleSpinBox(); self.spin_cs_high.setRange(0.0, 5000.0); self.spin_cs_high.setValue(p.get('CS_HIGH_CUT_HZ',150.0))
        self.spin_cs_thresh = QtWidgets.QDoubleSpinBox(); self.spin_cs_thresh.setRange(0.0, 50.0); self.spin_cs_thresh.setValue(p.get('CS_THRESHOLD_SIGMA',6.0))
        self.spin_ss_low = QtWidgets.QDoubleSpinBox(); self.spin_ss_low.setRange(0.0,5000.0); self.spin_ss_low.setValue(p.get('SS_LOW_CUT_HZ',0.0))
        self.spin_ss_high = QtWidgets.QDoubleSpinBox(); self.spin_ss_high.setRange(0.0,5000.0); self.spin_ss_high.setValue(p.get('SS_HIGH_CUT_HZ',0.0))
        self.spin_ss_thresh = QtWidgets.QDoubleSpinBox(); self.spin_ss_thresh.setRange(0.0,50.0); self.spin_ss_thresh.setValue(p.get('SS_THRESHOLD_SIGMA',3.0))
        form.addRow('CS low cut (Hz):', self.spin_cs_low)
        form.addRow('CS high cut (Hz):', self.spin_cs_high)
        form.addRow('CS threshold (σ):', self.spin_cs_thresh)
        # CS min dist is managed in Advanced Settings (SettingsDialog)
        form.addRow('SS low cut (Hz):', self.spin_ss_low)
        form.addRow('SS high cut (Hz):', self.spin_ss_high)
        form.addRow('SS threshold (σ):', self.spin_ss_thresh)
        # SS min dist / SS blank moved to Advanced Settings (use parent.params)
        layout.addLayout(form)
        btns = QtWidgets.QHBoxLayout()
        ok = QtWidgets.QPushButton('OK'); cancel = QtWidgets.QPushButton('Cancel')
        ok.clicked.connect(self.accept); cancel.clicked.connect(self.reject)
        btns.addStretch(1); btns.addWidget(ok); btns.addWidget(cancel)
        layout.addLayout(btns)
        self.setLayout(layout)
        _apply_setting_tooltips(self)
    def get_params(self):
        return {
            'CS_LOW_CUT_HZ': float(self.spin_cs_low.value()),
            'CS_HIGH_CUT_HZ': float(self.spin_cs_high.value()),
            'CS_THRESHOLD_SIGMA': float(self.spin_cs_thresh.value()),
            'CS_MIN_DIST_MS': float(self.parent_win.params.get('CS_MIN_DIST_MS', 25.0)) if hasattr(self, 'parent_win') and self.parent_win is not None else 25.0,
            'CS_MIN_FWHM_MS': float(self.parent_win.params.get('CS_MIN_FWHM_MS', 4.0)) if hasattr(self, 'parent_win') and self.parent_win is not None else 4.0,
            'SS_LOW_CUT_HZ': float(self.spin_ss_low.value()),
            'SS_HIGH_CUT_HZ': float(self.spin_ss_high.value()),
            'SS_THRESHOLD_SIGMA': float(self.spin_ss_thresh.value()),
            'SS_MIN_DIST_MS': float(self.parent_win.params.get('SS_MIN_DIST_MS', 4.0)) if hasattr(self, 'parent_win') and self.parent_win is not None else 4.0,
            'SS_BLANK_MS': float(self.parent_win.params.get('SS_BLANK_MS', 18.0)) if hasattr(self, 'parent_win') and self.parent_win is not None else 18.0,
        }
    # (Moved compute_baseline and export_figure into MainWindow)


class SliderViewerDialog(QtWidgets.QDialog):
    def __init__(self, data, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Slider Viewer')
        # Base scaled size, then shrink further on low-resolution screens (e.g., 1080p)
        w, h = _scaled_size(1020, 700)
        try:
            app = QtWidgets.QApplication.instance()
            screen = app.primaryScreen() if app is not None else None
            scr_h = None
            if screen is not None:
                try:
                    scr_h = int(screen.size().height())
                except Exception:
                    try:
                        scr_h = int(screen.geometry().height())
                    except Exception:
                        scr_h = None
        except Exception:
            scr_h = None
        # If low-resolution screen, enforce a 30% smaller logical size
        s = _get_screen_scale()
        if scr_h is not None and scr_h <= 1080:
            # compute target size based on logical pixels (reduce influence of DPI)
            w = int(1000 * 0.7 / max(1.0, s))
            h = int(700 * 0.7 / max(1.0, s))
        else:
            self.resize(w, h)
            # when not low-res, already resized above; return early
            # (keep existing resize behavior)
            pass
        # apply final resize for low-res branch
        try:
            if scr_h is not None and scr_h <= 1080:
                self.resize(w, h)
        except Exception:
            self.resize(w, h)
        self.data = data
        self.fig = _make_figure(8, 6)
        self.canvas = FigureCanvas(self.fig)
        self.ax_raw = self.fig.add_subplot(311)
        self.ax_cs = self.fig.add_subplot(312, sharex=self.ax_raw)
        self.ax_ss = self.fig.add_subplot(313, sharex=self.ax_raw)

        # Controls
        self.slider_time = QtWidgets.QSlider()
        self.slider_time.setOrientation(ORIENT_HORIZONTAL)
        self.slider_time.setMinimum(0)
        self.slider_time.setMaximum(1000)
        view_params = getattr(parent, 'params', {})
        self._auto_start_view = bool(view_params.get('SLIDER_VIEW_AUTO_START', 'SLIDER_VIEW_CENTER' not in view_params))
        self.slider_time.setValue(int(view_params.get('SLIDER_VIEW_CENTER', 0)))
        def navigate(value):
            self._auto_start_view = False
            if parent is not None:
                parent.params['SLIDER_VIEW_AUTO_START'] = False
            self.update_plot()
        self.slider_time.valueChanged.connect(navigate)

        self.spin_zoom = QtWidgets.QDoubleSpinBox(); self.spin_zoom.setRange(0.0, 1e6); self.spin_zoom.setValue(float(view_params.get('SLIDER_VIEW_Y_RANGE', 0.0)))
        self.spin_zoom.valueChanged.connect(self.update_plot)
        if parent is not None and hasattr(parent, 'params'):
            controls = [('SLIDER_VIEW_CENTER', self.slider_time), ('SLIDER_VIEW_Y_RANGE', self.spin_zoom)]
            for key, widget in controls:
                widget.valueChanged.connect(lambda value, name=key: parent.params.__setitem__(name, value))

        # Controls row (move on top of plot)
        layout = QtWidgets.QVBoxLayout()
        hl = QtWidgets.QHBoxLayout(); hl.addWidget(QtWidgets.QLabel('Time:')); hl.addWidget(self.slider_time)
        # start time label
        self.lbl_start_time = QtWidgets.QLabel('Start: 0 ms')
        hl.addWidget(self.lbl_start_time)
        hl.addWidget(QtWidgets.QLabel('Y-Range:')); hl.addWidget(self.spin_zoom)
        # Export button
        btn_export = QtWidgets.QPushButton('Save Figure')
        btn_export.clicked.connect(self.save_figure)
        hl.addWidget(btn_export)
        layout.addLayout(hl)
        layout.addWidget(self.canvas)
        self.setLayout(layout)
        _apply_setting_tooltips(self)

        # default cell
        self.cell_idx = 0
        self.update_plot()

    def update_plot(self):
        t = self.data['time_ms']
        raw = self.data['raw_data'][:, self.cell_idx]
        fs = float(self.data['fs'])
        parent = self.parent()
        params = self.data.get('_saved_detection_params', getattr(parent, 'params', {}))
        start_time, end_time = _trace_view_window(self.data, params, 1000.0,
            self.slider_time.value(), self._auto_start_view)
        mask = (t >= start_time) & (t <= end_time)
        # update start time label
        try:
            self.lbl_start_time.setText(f'Start: {int(start_time)} ms')
        except Exception:
            pass
        zoom = float(self.spin_zoom.value())

        self.fig.suptitle(f"Cell: {self.data['cell_names'][self.cell_idx]}")
        parent = self.parent()
        colors = parent.colors if parent is not None else {'raw':'#333333','drift':'#FFC20A','cs':'#009E73','ss':'#D55E00','cs_th':'#56B4E9','ss_th':'#CC79A7'}
        params = self.data.get('_saved_detection_params', parent.params if parent is not None else {})
        self.ax_raw.clear(); self.ax_cs.clear(); self.ax_ss.clear()
        # apply frame-based averaging for visualization if enabled
        frames = int(parent.spin_avg_frames.value()) if (parent is not None and hasattr(parent, 'spin_avg_frames')) else 0
        mode = parent._get_frame_processing_mode() if (parent is not None and hasattr(parent, '_get_frame_processing_mode')) else 'Rolling average'
        if self.data.get('loaded_detection_result'):
            raw_viz = _display_processed_raw(self.data, self.cell_idx)
            baseline_gui = self.data['baseline_traces'][:, self.cell_idx]
            det = self.data['results'][self.cell_idx]
        else:
            raw_viz, baseline_gui, _ = protected_preprocess(raw, fs, params, parent.baseline_params, frames, mode)
            det = _detect_cell(raw, fs, params, parent.baseline_params, frames, mode,
                              parent.template_store, parent._get_denoise_config())

        # baseline_display should be the baseline estimated for the raw (after averaging).
        # Use the GUI baseline (computed above) or the one returned by detection if present.
        baseline_display = det.get('baseline', baseline_gui) if det.get('baseline', None) is not None else baseline_gui
        # show corrected-only or raw+baseline depending on checkbox
        if getattr(parent, 'chk_show_baseline', None) and parent.chk_show_baseline.isChecked():
            corrected = raw_viz - det['baseline']
            vis_signal = corrected
            self.ax_raw.plot(t[mask], vis_signal[mask], color=colors.get('raw', '#333333'), lw=_get_linewidth(1))
        else:
            vis_signal = raw_viz
            self.ax_raw.plot(t[mask], raw_viz[mask], color=colors.get('raw', '#333333'), lw=_get_linewidth(1))
            self.ax_raw.plot(t[mask], baseline_display[mask], color=colors.get('baseline', '#FFC20A'), ls='--', lw=_get_linewidth(1.6))

        self.ax_cs.plot(t[mask], det['cs_trace'][mask], color=colors.get('cs_trace', '#009E73'))
        if det.get('local_baseline', False) and 'cs_threshold_trace' in det:
            self.ax_cs.plot(t[mask], det['cs_threshold_trace'][mask], color=colors.get('cs_thresh', '#56B4E9'), ls='--')
        elif not det.get('loaded_local_threshold_unavailable'):
            self.ax_cs.axhline(params.get('CS_THRESHOLD_SIGMA', 6.0) * det['sigma_cs'], color=colors.get('cs_thresh', '#56B4E9'), ls='--')
        self.ax_ss.plot(t[mask], det['ss_trace'][mask], color=colors.get('ss_trace', '#D55E00'))
        if det.get('local_baseline', False) and 'ss_threshold_trace' in det:
            self.ax_ss.plot(t[mask], det['ss_threshold_trace'][mask], color=colors.get('ss_thresh', '#CC79A7'), ls='--')
        elif not det.get('loaded_local_threshold_unavailable'):
            self.ax_ss.axhline(params.get('SS_THRESHOLD_SIGMA', 3.0) * det['sigma_ss'], color=colors.get('ss_thresh', '#CC79A7'), ls='--')

        # overlay spikes
        cs_times = t[det['cs_peaks']]
        ss_times = t[det['ss_peaks']]
        self.ax_raw.plot(cs_times, [np.max(vis_signal)] * len(cs_times), 'x', color=colors.get('cs_trace', '#009E73'))
        self.ax_raw.plot(ss_times, [np.min(vis_signal)] * len(ss_times), '|', color=colors.get('ss_trace', '#D55E00'))

        self.ax_raw.set_xlim(start_time, end_time)
        if np.any(mask):
            v_lim = vis_signal[mask]
            self.ax_raw.set_ylim(np.min(v_lim) - 0.1*np.ptp(v_lim), np.max(v_lim) + 0.1*np.ptp(v_lim))

        # Apply Y-Range uniformly to raw/CS/SS axes (same semantics as main & detection viewers)
        y_range = float(self.spin_zoom.value()) if hasattr(self, 'spin_zoom') else 0.0
        if np.any(mask):
            vmin = np.min(vis_signal[mask]); vmax = np.max(vis_signal[mask])
            span = vmax - vmin
            local_std = np.std(vis_signal[mask]) if len(vis_signal[mask])>0 else 1.0
            if y_range <= 0.0:
                pad = max(span * 0.05, local_std * 0.5, 1e-9)
                ylim = (vmin - pad, vmax + pad)
            else:
                center = 0.5 * (vmax + vmin)
                half_range = float(y_range) / 2.0
                ylim = (center - half_range, center + half_range)
        else:
            ylim = (-1.0, 1.0)
        for a in [self.ax_raw, self.ax_cs, self.ax_ss]:
            a.set_ylim(ylim)

        self.canvas.draw()

    def save_figure(self):
        try:
            filename = save_figure_with_dialog(
                lambda title, default, flt: QFileDialog.getSaveFileName(self, title, default, flt),
                self.canvas.figure,
                default_name='figure.svg',
            )
            if filename:
                QMessageBox.information(self, 'Saved', f'Figure saved as {filename}')
        except Exception as e:
            QMessageBox.critical(self, 'Error', f'Failed to save figure: {e}')


class DetectionViewerDialog(QtWidgets.QDialog):
    def __init__(self, data, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Detection Viewer')
        self.resize(*_scaled_size(1000, 700))
        self.data = data
        self._polarity_control_thread = None
        self._polarity_control_target = None
        self.fig = _make_figure(8, 6)
        self.canvas = FigureCanvas(self.fig)
        self._viewer_mode = None
        self._build_axes()

        # Controls: time slider, window, zoom
        # Session and cell selectors (allow switching between loaded sessions/cells)
        self.combo_session = QtWidgets.QComboBox()
        self.combo_session.setMinimumContentsLength(10)
        self.combo_session.setSizeAdjustPolicy(QtWidgets.QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        parent = self.parent()
        session_names = []
        try:
            if parent is not None and hasattr(parent, 'session_names') and parent.session_names:
                session_names = list(parent.session_names)
            elif parent is not None and hasattr(parent, 'loaded_sessions'):
                session_names = list(parent.loaded_sessions.keys())
        except Exception:
            session_names = []
        self.combo_session.addItems(session_names)
        # try to set current session name matching provided data
        try:
            cur_name = None
            if parent is not None and parent.selected_session:
                cur_name = parent.selected_session
            elif isinstance(self.data, dict) and 'session_name' in self.data:
                cur_name = self.data.get('session_name')
            if cur_name is not None and cur_name in session_names:
                self.combo_session.setCurrentText(cur_name)
        except Exception:
            pass
        self.combo_session.currentTextChanged.connect(self._on_session_changed)

        self.combo_cell = QtWidgets.QComboBox()
        # populate cells based on initial data
        try:
            n_cells = int(self.data['raw_data'].shape[1]) if (self.data is not None and 'raw_data' in self.data) else 0
            cell_names = self.data.get('cell_names', [f'Cell {i}' for i in range(n_cells)]) if isinstance(self.data, dict) else []
            self.combo_cell.addItems(cell_names)
        except Exception:
            pass
        self.combo_cell.currentIndexChanged.connect(self._on_cell_changed)

        self.slider_time = QtWidgets.QSlider()
        self.slider_time.setOrientation(ORIENT_HORIZONTAL)
        self.slider_time.setMinimum(0)
        self.slider_time.setMaximum(1000)
        view_params = getattr(parent, 'params', {})
        self._auto_start_view = bool(view_params.get('DETECTION_VIEW_AUTO_START', 'DETECTION_VIEW_CENTER' not in view_params))
        self.slider_time.setValue(int(view_params.get('DETECTION_VIEW_CENTER', 0)))
        def navigate(value):
            self._auto_start_view = False
            if parent is not None:
                parent.params['DETECTION_VIEW_AUTO_START'] = False
            self.plot_detection()
        self.slider_time.valueChanged.connect(navigate)

        self.spin_window = QtWidgets.QDoubleSpinBox(); self.spin_window.setRange(10.0, 10000.0); self.spin_window.setValue(float(view_params.get('DETECTION_VIEW_WINDOW_MS', 1000.0)))
        self.spin_window.valueChanged.connect(self.plot_detection)
        self.spin_zoom = QtWidgets.QDoubleSpinBox(); self.spin_zoom.setRange(0.0, 1e6); self.spin_zoom.setValue(float(view_params.get('DETECTION_VIEW_Y_RANGE', 0.0)))
        self.spin_zoom.valueChanged.connect(self.plot_detection)
        if parent is not None and hasattr(parent, 'params'):
            controls = [('DETECTION_VIEW_CENTER', self.slider_time), ('DETECTION_VIEW_Y_RANGE', self.spin_zoom)]
            controls.append(('DETECTION_VIEW_WINDOW_MS', self.spin_window))
            for key, widget in controls:
                widget.valueChanged.connect(lambda value, name=key: parent.params.__setitem__(name, value))

        # Two-row control panel to avoid overly wide layout
        ctrl_top = QtWidgets.QHBoxLayout()
        ctrl_top.addWidget(QtWidgets.QLabel('Session:'))
        ctrl_top.addWidget(self.combo_session)
        ctrl_top.addWidget(QtWidgets.QLabel('Cell:'))
        ctrl_top.addWidget(self.combo_cell)
        ctrl_top.addWidget(QtWidgets.QLabel('Time'))
        ctrl_top.addWidget(self.slider_time)

        ctrl_bottom = QtWidgets.QHBoxLayout()
        # keep start time label on the bottom row to show current window start
        self.lbl_start_time = QtWidgets.QLabel('Start: 0 ms')
        ctrl_bottom.addWidget(self.lbl_start_time)
        ctrl_bottom.addWidget(QtWidgets.QLabel('Window (ms):'))
        ctrl_bottom.addWidget(self.spin_window)
        ctrl_bottom.addSpacing(8)
        ctrl_bottom.addWidget(QtWidgets.QLabel('Scale (Y-Range):'))
        ctrl_bottom.addWidget(self.spin_zoom)
        btn_extract_tpl = QtWidgets.QPushButton('Export as templates')
        btn_extract_tpl.clicked.connect(self.export_detected_templates)
        ctrl_bottom.addWidget(btn_extract_tpl)
        btn_export = QtWidgets.QPushButton('Save Figure')
        btn_export.clicked.connect(self.save_figure)
        ctrl_bottom.addStretch(1)
        ctrl_bottom.addWidget(btn_export)

        layout = QtWidgets.QVBoxLayout()
        layout.addLayout(ctrl_top)
        layout.addLayout(ctrl_bottom)
        control_row = QtWidgets.QHBoxLayout()
        self.btn_polarity_control = QtWidgets.QPushButton('Run polarity-reversed control')
        self.btn_polarity_control.setToolTip(
            'Rerun this cell with the signal inverted, using the original settings and exclusion masks.')
        self.btn_polarity_control.clicked.connect(self.run_polarity_reversed_control)
        control_row.addWidget(self.btn_polarity_control)
        control_row.addStretch(1)
        layout.addLayout(control_row)
        self.lbl_candidate_info = QtWidgets.QLabel('')
        self.lbl_candidate_info.setWordWrap(True)
        layout.addWidget(self.lbl_candidate_info)
        layout.addWidget(self.canvas)
        # Make info (ctrl_bottom) taller by increasing its stretch relative to canvas.
        # Stretch indices: 0=ctrl_top,1=ctrl_bottom,2=canvas
        layout.setStretch(0, 0)
        # restore detection viewer info panel stretch to previous value
        layout.setStretch(1, 3)
        layout.setStretch(2, 4)
        self.setLayout(layout)
        _apply_setting_tooltips(self)

        # default to first cell
        self.cell_idx = 0
        self.plot_detection()

    def _build_axes(self):
        self.fig.clf()
        self.resize(*_scaled_size(1000, 700))
        # Keep top/bottom raw panels at equal visual height to match perceived Y scaling.
        gs = self.fig.add_gridspec(4, 1, height_ratios=[1, 1, 1, 1], hspace=0.05)
        self.ax_raw_top = self.fig.add_subplot(gs[0, 0])
        self.ax_cs = self.fig.add_subplot(gs[1, 0], sharex=self.ax_raw_top)
        self.ax_ss = self.fig.add_subplot(gs[2, 0], sharex=self.ax_raw_top)
        self.ax_raw_bot = self.fig.add_subplot(gs[3, 0], sharex=self.ax_raw_top, sharey=self.ax_raw_top)
        self._viewer_mode = 'standard'

    def _on_session_changed(self, text):
        # Switch to a different session from the parent loaded sessions
        parent = self.parent()
        if parent is None:
            return
        try:
            data = parent.loaded_sessions.get(text, None)
            if data is None:
                return
            self.data = data
            if data.get('loaded_detection_result'):
                parent.list_sessions.setCurrentText(text)
            # repopulate cell list
            try:
                n_cells = int(self.data['raw_data'].shape[1])
                cell_names = self.data.get('cell_names', [f'Cell {i}' for i in range(n_cells)])
                self.combo_cell.clear()
                self.combo_cell.addItems(cell_names)
                self.cell_idx = 0
            except Exception:
                pass
            self.plot_detection()
        except Exception:
            return

    def _on_cell_changed(self, idx):
        try:
            self.cell_idx = int(idx)
        except Exception:
            self.cell_idx = 0
        self.plot_detection()

    def run_polarity_reversed_control(self):
        if self._polarity_control_thread is not None:
            return
        context = self.data.get('_control_context') if isinstance(self.data, dict) else None
        try:
            original_result = self.data['results'][self.cell_idx]
        except (KeyError, IndexError, TypeError):
            original_result = None
        if not context or original_result is None or not all(
                f'{kind}_exclusion_mask' in original_result for kind in ('cs', 'ss')):
            return
        data = self.data
        cell_idx = self.cell_idx
        raw = np.asarray(data['raw_data'][:, cell_idx], dtype=float).copy()
        fs = float(data['fs'])
        self._polarity_control_target = original_result
        self.btn_polarity_control.setEnabled(False)
        self.btn_polarity_control.setText('Running polarity control…')
        worker = _DetectionCellThread(lambda: _polarity_reversed_control(
            raw, fs, context, original_result), self)
        self._polarity_control_thread = worker
        worker.result_ready.connect(self._polarity_control_ready)
        worker.finished.connect(worker.deleteLater)
        worker.start()

    def _polarity_control_ready(self, summary, error):
        worker = self._polarity_control_thread
        if worker is not None:
            worker.wait(1000)
        self._polarity_control_thread = None
        self.btn_polarity_control.setText('Run polarity-reversed control')
        target = self._polarity_control_target
        self._polarity_control_target = None
        if target is not None:
            if error is None:
                target['polarity_control'] = summary
                target.pop('polarity_control_error', None)
            else:
                target['polarity_control_error'] = str(error)
                target.pop('polarity_control', None)
        self.plot_detection()

    def closeEvent(self, event):
        if self._polarity_control_thread is not None:
            event.ignore()
            return
        super().closeEvent(event)

    def _draw_classic_scale_bar(self, axis, visible_ms, ylim, sigma, anchor_top_y_data=None, shift_frac=0.10,
                                baseline_value=None):
        def _nice_round_time(ms_val):
            if ms_val <= 0:
                return 1.0
            exp = int(np.floor(np.log10(ms_val)))
            candidates = [1, 2, 2.5, 5, 10]
            best = None
            best_diff = None
            for m in candidates:
                cand = float(m) * (10 ** exp)
                diff = abs(cand - ms_val)
                if best is None or diff < best_diff:
                    best = cand
                    best_diff = diff
            next_cand = 10 ** (exp + 1)
            if abs(next_cand - ms_val) < best_diff:
                best = float(next_cand)
            return float(best)

        try:
            visible_ms = float(visible_ms)
        except Exception:
            visible_ms = 1.0
        target_ms = max(1.0, visible_ms / 20.0)
        nice_ms = _nice_round_time(target_ms)
        horiz_frac = float(nice_ms) / max(1e-9, visible_ms)
        horiz_frac = float(max(0.02, min(0.45, horiz_frac)))

        rx = 1.0 - 0.005
        lx = rx - horiz_frac

        span = (ylim[1] - ylim[0]) if isinstance(ylim, tuple) else max(1e-9, float(ylim))
        vertical_multiplier = 5.0
        vertical_frac = float(max(0.02, min(0.9, horiz_frac * vertical_multiplier)))
        amp_label_override = None

        def _nice_percent_label(value):
            if not np.isfinite(value) or value <= 0:
                return None
            candidates = np.asarray([1.0, 2.5, 5.0, 10.0, 15.0, 20.0, 25.0, 30.0, 40.0, 50.0, 75.0, 100.0],
                                    dtype=float)
            return float(candidates[int(np.argmin(np.abs(np.log(candidates) - np.log(value))))])

        parent = self.parent()
        params = parent.params if parent is not None else {}
        if str(params.get('RAW_SCALE_BAR_UNIT', 'Sigma')) == 'dF/F (%)':
            f0 = float(baseline_value) if baseline_value is not None else np.nan
            if np.isfinite(f0) and abs(f0) > 1e-12 and span > 0:
                target_pct = 100.0 * (vertical_frac * span) / abs(f0)
                nice_pct = _nice_percent_label(target_pct)
                if nice_pct is not None:
                    candidate_frac = (nice_pct / 100.0) * abs(f0) / span
                    if 0.02 <= candidate_frac <= 0.9:
                        vertical_frac = float(candidate_frac)
                        pct_text = f"{nice_pct:.1f}".rstrip('0').rstrip('.')
                        unit_text = '-ΔF/F' if bool(params.get('NEGATIVE_GOING', True)) else 'ΔF/F'
                        amp_label_override = f"{pct_text}% {unit_text}"
        else:
            sigma_safe = float(sigma) if sigma is not None and np.isfinite(sigma) and sigma > 0 else None
            if sigma_safe is not None and span > 0:
                actual_z = vertical_frac * span / sigma_safe
                rounded_z = max(0.5, round(actual_z * 2.0) / 2.0)
                rounded_frac = rounded_z * sigma_safe / span
                if 0.02 <= rounded_frac <= 0.9:
                    vertical_frac = rounded_frac
                    shown_z = rounded_z
                else:
                    shown_z = actual_z
                amp_label_override = f"{shown_z:.2g} " + r'$\sigma_{\mathrm{MAD}}$'

        if anchor_top_y_data is None:
            anchor_top_y_data = ylim[0] + 0.08 * span
        ty_axes = (float(anchor_top_y_data) - ylim[0]) / max(1e-9, span)
        ty_axes = float(max(ty_axes - 0.01 - shift_frac, -0.5))
        ry_axes = ty_axes - vertical_frac
        if ry_axes < -0.5:
            ry_axes = -0.5
            ty_axes = ry_axes + vertical_frac

        axis.plot([rx, rx], [ry_axes, ty_axes], transform=axis.transAxes, color='k', lw=_get_linewidth(2), clip_on=False)
        axis.plot([lx, rx], [ry_axes, ry_axes], transform=axis.transAxes, color='k', lw=_get_linewidth(2), clip_on=False)

        win_label = f"{int(nice_ms)} ms"
        raw_bar_height = float(vertical_frac * span)

        def _amplitude_label():
            if amp_label_override is not None:
                return amp_label_override
            return f"{raw_bar_height:.2g} signal units"

        axis.text((lx + rx) / 2.0, ry_axes - 0.02, win_label, transform=axis.transAxes,
                  va='top', ha='center', clip_on=False, fontsize=_scale_font(9))
        axis.text(rx + 0.01, (ry_axes + ty_axes) / 2.0, _amplitude_label(), transform=axis.transAxes,
                  va='center', ha='left', rotation='vertical', clip_on=False, fontsize=_scale_font(9))

    def plot_detection(self):
        results = self.data.get('results', []) if isinstance(self.data, dict) else []
        res = (results[self.cell_idx] if 0 <= self.cell_idx < len(results) else None)
        if not isinstance(res, dict):
            for axis in (self.ax_raw_top, self.ax_cs, self.ax_ss, self.ax_raw_bot):
                axis.clear()
            if isinstance(self.data, dict):
                time = np.asarray(self.data.get('time_ms', []))
                raw_data = np.asarray(self.data.get('raw_data', []))
                if (raw_data.ndim == 2 and time.ndim == 1 and
                        raw_data.shape[0] == time.size and
                        time.size > 0 and 0 <= self.cell_idx < raw_data.shape[1]):
                    center = time[0] + self.slider_time.value() / 1000.0 * (time[-1] - time[0])
                    half_window = float(self.spin_window.value()) / 2.0
                    visible = (time >= center - half_window) & (time <= center + half_window)
                    for axis in (self.ax_raw_top, self.ax_raw_bot):
                        axis.plot(time[visible], raw_data[visible, self.cell_idx],
                                  color='#333333', lw=_get_linewidth(1))
            self.ax_cs.text(.5, .5, 'No detection result for this cell',
                            ha='center', va='center', transform=self.ax_cs.transAxes)
            self.lbl_candidate_info.setText('Detection unavailable for this cell; see Info for the error.')
            self.btn_polarity_control.setEnabled(False)
            self.canvas.draw()
            return
        t = self.data['time_ms']
        raw = self.data['raw_data'][:, self.cell_idx]
        fs = float(self.data['fs'])

        parent = self.parent()
        colors = parent.colors if parent is not None else {'raw':'#333333','baseline':'#FFC20A','cs_trace':'#009E73','ss_trace':'#D55E00','cs_thresh':'#56B4E9','ss_thresh':'#CC79A7'}
        params = self.data.get('_saved_detection_params', parent.params if parent is not None else {})

        window_start, window_end = _trace_view_window(self.data, params, float(self.spin_window.value()),
            self.slider_time.value(), self._auto_start_view)
        mask = (t >= window_start) & (t <= window_end)
        try:
            self.lbl_start_time.setText(f'Start: {int(window_start)} ms')
        except Exception:
            pass
        # apply frame averaging if requested
        frames = int(parent.spin_avg_frames.value()) if (parent is not None and hasattr(parent, 'spin_avg_frames')) else 0
        mode = parent._get_frame_processing_mode() if (parent is not None and hasattr(parent, '_get_frame_processing_mode')) else 'Rolling average'
        if self.data.get('loaded_detection_result'):
            raw_proc = _display_processed_raw(self.data, self.cell_idx)
            baseline_gui = np.asarray(self.data['baseline_traces'][:, self.cell_idx])
        else:
            raw_proc, baseline_gui, _ = protected_preprocess(raw, fs, params, parent.baseline_params, frames, mode)
        vis_raw = np.asarray(raw_proc, dtype=float)

        for a in [self.ax_raw_top, self.ax_cs, self.ax_ss, self.ax_raw_bot]:
            a.clear()

        baseline_display = res.get('baseline', baseline_gui)
        vis_top = vis_raw
        self.ax_raw_top.plot(t[mask], vis_top[mask], color=colors.get('raw', '#333333'), lw=_get_linewidth(1))
        self.ax_raw_top.plot(t[mask], baseline_display[mask], color=colors.get('baseline', '#FFC20A'), ls='--', lw=_get_linewidth(1.6))
        self.ax_raw_bot.plot(t[mask], vis_raw[mask], color=colors.get('raw', '#333333'), lw=_get_linewidth(1))

        det_method = str(res.get('det_method', 'Threshold'))
        is_template_mode = ('Template' in det_method)
        self.btn_polarity_control.setEnabled(bool(is_template_mode and
            self.data.get('_control_context') and self._polarity_control_thread is None and
            all(f'{kind}_exclusion_mask' in res for kind in ('cs', 'ss'))))
        if is_template_mode or 'spike_qc' in res:
            messages = []
            for spike_type in ('CS', 'SS'):
                info = res.get(f'{spike_type.lower()}_candidate_diagnostics', {})
                if info.get('manual'):
                    messages.append(f'{spike_type}: manual labels {len(res[spike_type.lower()+"_peaks"])}; width/SNR measured without automatic rejection')
                elif info.get('unavailable'):
                    messages.append(f'{spike_type}: saved candidate diagnostics unavailable; kept {len(res[spike_type.lower()+"_peaks"])}')
                elif info.get('no_templates'):
                    messages.append(f'{spike_type}: ' + ('no templates available' if res.get('combo') else 'no templates loaded'))
                else:
                    width_removed = (sum(row.get('decision') == 'fail' for row in res.get('cs_width_candidates', []))
                                     if spike_type == 'CS' else res.get('ss_fwhm_filter_removed', 0))
                    width_uncertain = (sum(row.get('status') == 'uncertain' for row in res.get('event_widths_cs', []))
                                       if spike_type == 'CS' else res.get('ss_fwhm_filter_uncertain', 0))
                    losses = (f"score peaks {info.get('score_peaks', 0)}, masked {info.get('masked', 0)}"
                              if is_template_mode else f"QC candidates {len(res.get(spike_type.lower() + '_width_candidates', []))}")
                    qc = res.get('spike_qc', {}).get(spike_type.lower(), {})
                    if qc:
                        width_removed = qc['width_rejected']
                    losses += f", amplitude SNR rejected {qc.get('amplitude_rejected', 0)}, SNR unavailable {qc.get('amplitude_unavailable', 0)}"
                    uncertain_label = (f'{width_uncertain} (short green dashes)' if spike_type == 'CS'
                                       else str(width_uncertain))
                    messages.append(f"{spike_type}: {losses}, "
                        f"spacing rejected {info.get('refractory_rejected', 0)}, "
                        f"width rejected {width_removed}, width uncertain {uncertain_label}, "
                        f"kept {len(res.get(f'{spike_type.lower()}_peaks', []))}")
            if res.get('saved_score_unavailable'):
                messages.append('Saved template scores unavailable in this older file; showing filtered traces without score cutoffs.')
            if res.get('loaded_local_threshold_unavailable'):
                messages.append('Saved local threshold vectors unavailable in this older file; cutoff lines omitted.')
            summary = res.get('polarity_control')
            if summary is not None:
                messages.append('Polarity reversed (same settings and masks; control detections, not false-positive count): '
                    f"CS score peaks {summary['cs_score_peaks']}, kept {summary['cs_kept']} "
                    f"(original {len(res.get('cs_peaks', []))}); "
                    f"SS score peaks {summary['ss_score_peaks']}, kept {summary['ss_kept']} "
                    f"(original {len(res.get('ss_peaks', []))})")
            elif res.get('polarity_control_error'):
                messages.append(f"Polarity control failed: {res['polarity_control_error']}")
            if res.get('combo'):
                info = res['combo']
                messages.append('Combo: ' + '; '.join(
                    f"{kind.upper()} seeds {info[kind]['seeds']}, clean {info[kind]['clean']}, kernels {info[kind]['kernels']} ({info[kind]['source']})"
                    for kind in ('cs', 'ss')))
            whitening = res.get('template_whitening') or {}
            if whitening.get('requested'):
                messages.append('Whitening: ' + '; '.join(
                    f"{kind.upper()} " + ('ON' if whitening.get(kind, {}).get('applied') else
                        f"skipped ({whitening.get(kind, {}).get('reason', 'unavailable')})")
                    for kind in ('cs', 'ss')))
            self.lbl_candidate_info.setText('  |  '.join(messages[:2]) +
                ('\n' + '\n'.join(messages[2:]) if len(messages) > 2 else ''))
        else:
            self.lbl_candidate_info.clear()
        cs_plot_trace = res.get('cs_similarity_trace', res.get('cs_trace', np.zeros_like(raw_proc))) if is_template_mode and not res.get('saved_score_unavailable') else res.get('cs_trace', np.zeros_like(raw_proc))
        ss_plot_trace = res.get('ss_similarity_trace', res.get('ss_trace', np.zeros_like(raw_proc))) if is_template_mode and not res.get('saved_score_unavailable') else res.get('ss_trace', np.zeros_like(raw_proc))
        self.ax_cs.plot(t[mask], cs_plot_trace[mask], color=colors.get('cs_trace', '#009E73'))
        self.ax_ss.plot(t[mask], ss_plot_trace[mask], color=colors.get('ss_trace', '#D55E00'))

        if is_template_mode and not res.get('saved_score_unavailable'):
            cs_thr_line = float(res.get('cs_threshold_used', np.nan))
            ss_thr_line = float(res.get('ss_threshold_used', np.nan))
            if np.isfinite(cs_thr_line):
                self.ax_cs.axhline(cs_thr_line, color=colors.get('cs_thresh', '#56B4E9'), ls='--')
            if np.isfinite(ss_thr_line):
                self.ax_ss.axhline(ss_thr_line, color=colors.get('ss_thresh', '#CC79A7'), ls='--')
        elif not is_template_mode and not res.get('manual_labels') and not res.get('loaded_local_threshold_unavailable'):
            if res.get('local_baseline', False) and 'cs_threshold_trace' in res:
                self.ax_cs.plot(t[mask], np.asarray(res['cs_threshold_trace'])[mask], color=colors.get('cs_thresh', '#56B4E9'), ls='--')
            else:
                self.ax_cs.axhline(params.get('CS_THRESHOLD_SIGMA', 6.0) * res.get('sigma_cs', 0.0), color=colors.get('cs_thresh', '#56B4E9'), ls='--')
            if res.get('local_baseline', False) and 'ss_threshold_trace' in res:
                self.ax_ss.plot(t[mask], np.asarray(res['ss_threshold_trace'])[mask], color=colors.get('ss_thresh', '#CC79A7'), ls='--')
            else:
                self.ax_ss.axhline(params.get('SS_THRESHOLD_SIGMA', 3.0) * res.get('sigma_ss', 0.0), color=colors.get('ss_thresh', '#CC79A7'), ls='--')

        cs_idx = np.asarray(res.get('cs_peaks', []), dtype=int)
        ss_idx = np.asarray(res.get('ss_peaks', []), dtype=int)
        valid_cs = cs_idx[(t[cs_idx] >= window_start) & (t[cs_idx] <= window_end)] if len(cs_idx)>0 else np.array([])
        valid_ss = ss_idx[(t[ss_idx] >= window_start) & (t[ss_idx] <= window_end)] if len(ss_idx)>0 else np.array([])

        for a in [self.ax_raw_top, self.ax_cs, self.ax_ss, self.ax_raw_bot]:
            a.set_xlim(window_start, window_end)

        y_range = float(self.spin_zoom.value()) if hasattr(self, 'spin_zoom') else 0.0
        scale_mask = mask & ~np.asarray(res.get('recording_exclusion_mask', np.zeros(len(t), bool)), bool)
        if not np.any(scale_mask):
            scale_mask = mask
        if np.any(mask):
            center = 0.5 * (np.max(vis_top[scale_mask]) + np.min(vis_top[scale_mask]))
            vmin = np.min(vis_top[scale_mask]); vmax = np.max(vis_top[scale_mask])
            span = vmax - vmin
            local_std = np.std(vis_top[scale_mask]) if np.any(scale_mask) else 1.0
            if y_range <= 0.0:
                pad = max(span * 0.12, local_std * 0.5, 1e-9)
                ylim = (vmin - pad, vmax + pad)
            else:
                half_range = float(y_range) / 2.0
                ylim = (center - half_range, center + half_range)
        else:
            ylim = (-1.0, 1.0)
        # Keep the two raw panels strictly on the same Y scale and lock autoscale.
        for a in [self.ax_raw_top, self.ax_raw_bot]:
            a.set_ylim(ylim)
            try:
                a.set_autoscaley_on(False)
            except Exception:
                pass

        raw_span_original = max(1e-9, span if 'span' in locals() else 1.0)
        factor = float(y_range) / raw_span_original if y_range > 0.0 else 1.0
        cs_masked = cs_plot_trace[scale_mask] if np.any(scale_mask) else np.array([])
        ss_masked = ss_plot_trace[scale_mask] if np.any(scale_mask) else np.array([])
        cs_std = np.std(cs_masked) if cs_masked.size > 0 else 1.0
        ss_std = np.std(ss_masked) if ss_masked.size > 0 else 1.0
        if is_template_mode:
            cs_thresh = abs(float(res.get('cs_threshold_used', np.nan))) if np.isfinite(res.get('cs_threshold_used', np.nan)) else cs_std
            ss_thresh = abs(float(res.get('ss_threshold_used', np.nan))) if np.isfinite(res.get('ss_threshold_used', np.nan)) else ss_std
            cs_half = max(cs_thresh * 1.25, cs_std * 4.0)
            ss_half = max(ss_thresh * 1.25, ss_std * 5.0)
        else:
            cs_thresh = abs(params.get('CS_THRESHOLD_SIGMA', 6.0) * res.get('sigma_cs', 1.0))
            ss_thresh = abs(params.get('SS_THRESHOLD_SIGMA', 3.0) * res.get('sigma_ss', 1.0))
            cs_half = max(cs_thresh * 1.5, cs_std * 3.0) * factor
            ss_half = max(ss_thresh * 1.5, ss_std * 3.0) * factor
        if cs_masked.size > 0:
            cs_half = max(cs_half, np.max(np.abs(cs_masked)) * 1.2)
        if ss_masked.size > 0:
            ss_half = max(ss_half, np.max(np.abs(ss_masked)) * (1.35 if is_template_mode else 1.2))
        self.ax_cs.set_ylim(-max(cs_half, 1e-6), max(cs_half, 1e-6))
        self.ax_ss.set_ylim(-max(ss_half, 1e-6), max(ss_half, 1e-6))
        if is_template_mode and np.any(mask):
            for axis, key in ((self.ax_cs, 'cs_exclusion_mask'), (self.ax_ss, 'ss_exclusion_mask')):
                excluded = np.asarray(res.get(key, np.zeros(len(t), dtype=bool)), dtype=bool)
                if excluded.shape == t.shape:
                    low, high = axis.get_ylim()
                    axis.fill_between(t[mask], low, high, where=excluded[mask],
                                      color='#999999', alpha=.14, linewidth=0)

        # Marker rails follow recorded polarity, independent of display scaling.
        negative = bool(res.get('negative_going', self.data.get('_control_context', {}).get('params', {}).get(
            'NEGATIVE_GOING', params.get('NEGATIVE_GOING', True))))
        ss_mark_center = .05 if negative else .95
        ss_half_h = .03
        marker_transform = self.ax_raw_bot.get_xaxis_transform()
        for p in valid_ss:
            if 0 <= p < len(t):
                self.ax_raw_bot.plot([t[p], t[p]], [ss_mark_center - ss_half_h, ss_mark_center + ss_half_h],
                    transform=marker_transform, gid='ss_event_marker', color=colors.get('ss_trace', '#D55E00'), lw=_get_linewidth(1.8))

        for p in valid_cs:
            row = next((r for r in res.get('event_widths_cs', []) if r['candidate_index'] == int(p)), None)
            y = .015 if negative else .985
            if row is not None and row.get('status') == 'measured':
                x0 = float(np.interp(row['left_index'], np.arange(len(t)), t))
                x1 = float(np.interp(row['right_index'], np.arange(len(t)), t))
                self.ax_raw_bot.plot([x0, x1], [y, y],
                                     transform=marker_transform, gid='cs_event_marker',
                                     color=colors.get('cs_trace', '#009E73'), lw=_get_linewidth(3))
            else:
                # A short screen-space dash marks a retained CS whose physical
                # FWHM is uncertain; its length does not encode a measured width.
                self.ax_raw_bot.plot([t[p]], [y], marker='_', ls='None', markersize=12,
                                     transform=marker_transform, gid='cs_event_marker',
                                     markeredgewidth=_get_linewidth(3),
                                     color=colors.get('cs_trace', '#009E73'))

        for a in [self.ax_raw_top, self.ax_cs, self.ax_ss, self.ax_raw_bot]:
            a.set_xticks([]); a.set_yticks([])
            for sp in a.spines.values():
                sp.set_visible(False)

        try:
            vis_ms = float(window_end - window_start)
        except Exception:
            vis_ms = float(total_ms) if 'total_ms' in locals() else 1.0
        self._draw_classic_scale_bar(
            self.ax_raw_bot,
            vis_ms,
            ylim,
            res.get('raw_sigma', 1.0),
            baseline_value=float(np.nanmedian(np.asarray(baseline_display)[mask & ~res.get('recording_exclusion_mask', np.zeros(len(t), bool))])) if np.any(mask & ~res.get('recording_exclusion_mask', np.zeros(len(t), bool))) else None,
        )

        self.canvas.draw()
        return


    def _extract_waveforms(self, trace, peaks, half_win):
        waves = []
        if trace is None or peaks is None:
            return np.array([])
        arr = np.asarray(trace, dtype=float).ravel()
        pks = np.asarray(peaks, dtype=int).ravel()
        for p in pks:
            s = int(p - half_win)
            e = int(p + half_win)
            if s < 0 or e > arr.size:
                continue
            w = arr[s:e]
            if w.size == 2 * half_win and np.all(np.isfinite(w)):
                waves.append(w)
        if len(waves) == 0:
            return np.array([])
        return np.asarray(waves, dtype=float)

    def _preprocess_for_template_export(self, raw, fs):
        parent = self.parent()
        frames = int(parent.spin_avg_frames.value())
        processed, baseline, valid = protected_preprocess(raw, fs, parent.params,
            parent.baseline_params, frames, parent._get_frame_processing_mode())
        sig = (processed-baseline) * (-1 if parent.params.get('NEGATIVE_GOING', True) else 1)
        sig[~valid] = np.nan
        return sig

    def export_detected_templates(self):
        try:
            parent = self.parent()
            params = parent.params if parent is not None else {}

            dlg = QtWidgets.QDialog(self)
            dlg.setWindowTitle('Export as templates')
            form = QtWidgets.QFormLayout(dlg)
            combo_scope = QtWidgets.QComboBox(dlg)
            combo_scope.addItems(['Current Cell', 'All Cells'])
            combo_scope.setCurrentText('All Cells')
            chk_cs = QtWidgets.QCheckBox('Export CS templates', dlg)
            chk_ss = QtWidgets.QCheckBox('Export SS templates', dlg)
            chk_cs.setChecked(True)
            chk_ss.setChecked(True)
            form.addRow('Extract from:', combo_scope)
            form.addRow(chk_cs)
            form.addRow(chk_ss)
            spin_cs_w = QtWidgets.QDoubleSpinBox(dlg)
            spin_cs_w.setRange(1.0, 200.0)
            spin_cs_w.setDecimals(1)
            spin_cs_w.setSuffix(' ms')
            spin_cs_w.setValue(float(params.get('TEMPLATE_CS_WINDOW_MS', 30.0)))
            spin_ss_w = QtWidgets.QDoubleSpinBox(dlg)
            spin_ss_w.setRange(1.0, 100.0)
            spin_ss_w.setDecimals(1)
            spin_ss_w.setSuffix(' ms')
            spin_ss_w.setValue(float(params.get('TEMPLATE_SS_WINDOW_MS', 8.0)))
            _set_input_tooltip(combo_scope, SETTING_TOOLTIPS['combo_scope'])
            _set_input_tooltip(chk_cs, 'Include detected CS waveforms in the exported template file.')
            _set_input_tooltip(chk_ss, 'Include detected SS waveforms in the exported template file.')
            _set_input_tooltip(spin_cs_w, SETTING_TOOLTIPS['spin_cs_w'])
            _set_input_tooltip(spin_ss_w, SETTING_TOOLTIPS['spin_ss_w'])
            form.addRow('CS window:', spin_cs_w)
            form.addRow('SS window:', spin_ss_w)
            try:
                bb_buttons = QtWidgets.QDialogButtonBox.StandardButton.Ok | QtWidgets.QDialogButtonBox.StandardButton.Cancel
            except Exception:
                bb_buttons = QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel
            btn_box = QtWidgets.QDialogButtonBox(bb_buttons, parent=dlg)
            btn_box.accepted.connect(dlg.accept)
            btn_box.rejected.connect(dlg.reject)
            form.addRow(btn_box)
            try:
                accepted_code = QtWidgets.QDialog.DialogCode.Accepted
            except Exception:
                accepted_code = QtWidgets.QDialog.Accepted
            ok = (dlg.exec() == accepted_code)
            if not ok:
                return
            scope = str(combo_scope.currentText())
            do_cs = bool(chk_cs.isChecked())
            do_ss = bool(chk_ss.isChecked())
            if not do_cs and not do_ss:
                QMessageBox.warning(self, 'No selection', 'Please check CS and/or SS for export.')
                return

            fs = float(self.data.get('fs', 1000.0))
            cs_w_ms = float(spin_cs_w.value())
            ss_w_ms = float(spin_ss_w.value())
            try:
                params['TEMPLATE_CS_WINDOW_MS'] = cs_w_ms
                params['TEMPLATE_SS_WINDOW_MS'] = ss_w_ms
            except Exception:
                pass
            cs_half = max(2, int((cs_w_ms / 1000.0) * fs / 2.0))
            ss_half = max(2, int((ss_w_ms / 1000.0) * fs / 2.0))

            cell_indices = [self.cell_idx] if scope == 'Current Cell' else list(range(int(self.data['raw_data'].shape[1])))
            cs_all = []
            ss_all = []
            for ci in cell_indices:
                try:
                    res = self.data['results'][ci]
                except Exception:
                    continue
                if res is None:
                    continue
                raw_cell = self.data['raw_data'][:, ci]
                src = self._preprocess_for_template_export(raw_cell, fs)
                cs_src = src
                ss_src = src
                cs_w = self._extract_waveforms(cs_src, res.get('cs_peaks', None), cs_half)
                ss_w = self._extract_waveforms(ss_src, res.get('ss_peaks', None), ss_half)
                if cs_w.size > 0:
                    cs_all.append(cs_w)
                if ss_w.size > 0:
                    ss_all.append(ss_w)

            cs_stack = np.vstack(cs_all) if len(cs_all) > 0 else np.array([])
            ss_stack = np.vstack(ss_all) if len(ss_all) > 0 else np.array([])
            if (do_cs and cs_stack.size == 0) and (do_ss and ss_stack.size == 0):
                QMessageBox.warning(self, 'No spikes', 'No detected spikes found for template extraction in selected scope.')
                return

            saved_files = []
            if do_cs:
                if cs_stack.size == 0:
                    QMessageBox.warning(self, 'No CS spikes', 'No detected CS spikes found for selected scope.')
                else:
                    cs_name, _ = QFileDialog.getSaveFileName(self, 'Save CS Templates', os.path.expanduser('~/detected_cs_templates.npz'), 'NPZ Files (*.npz)')
                    if cs_name:
                        if not cs_name.lower().endswith('.npz'):
                            cs_name += '.npz'
                        fs_out = float(TEMPLATE_TARGET_FS)
                        cs_stack_rs = np.vstack([_resample_template_to_fs(w, fs, fs_out) for w in cs_stack])
                        np.savez_compressed(
                            cs_name,
                            fs=fs_out,
                            fs_cs=fs_out,
                            scope=scope,
                            cs_waveforms=cs_stack_rs,
                            template_cs=np.mean(cs_stack_rs, axis=0),
                        )
                        saved_files.append(cs_name)

            if do_ss:
                if ss_stack.size == 0:
                    QMessageBox.warning(self, 'No SS spikes', 'No detected SS spikes found for selected scope.')
                else:
                    ss_name, _ = QFileDialog.getSaveFileName(self, 'Save SS Templates', os.path.expanduser('~/detected_ss_templates.npz'), 'NPZ Files (*.npz)')
                    if ss_name:
                        if not ss_name.lower().endswith('.npz'):
                            ss_name += '.npz'
                        fs_out = float(TEMPLATE_TARGET_FS)
                        ss_stack_rs = np.vstack([_resample_template_to_fs(w, fs, fs_out) for w in ss_stack])
                        np.savez_compressed(
                            ss_name,
                            fs=fs_out,
                            fs_ss=fs_out,
                            scope=scope,
                            ss_waveforms=ss_stack_rs,
                            template_ss=np.mean(ss_stack_rs, axis=0),
                        )
                        saved_files.append(ss_name)

            if len(saved_files) > 0:
                QMessageBox.information(self, 'Saved', 'Templates saved:\n' + '\n'.join(saved_files))
        except Exception as e:
            QMessageBox.critical(self, 'Export Error', f'Failed to export templates: {e}')

    def save_figure(self):
        try:
            filename = save_figure_with_dialog(
                lambda title, default, flt: QFileDialog.getSaveFileName(self, title, default, flt),
                self.canvas.figure,
                default_name='detection_figure.svg',
            )
            if filename:
                QMessageBox.information(self, 'Saved', f'Figure saved as {filename}')
        except Exception as e:
            QMessageBox.critical(self, 'Error', f'Failed to save figure: {e}')


class TemplateViewerDialog(QtWidgets.QDialog):
    def __init__(self, template_store, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Template Waveforms')
        self.resize(*_scaled_size(900, 420))
        self.template_store = template_store if isinstance(template_store, dict) else {}
        self.fig = _make_figure(9, 4)
        self.canvas = FigureCanvas(self.fig)
        layout = QtWidgets.QVBoxLayout()
        layout.addWidget(self.canvas)
        self.parallel_mode = bool(getattr(parent, 'params', {}).get('TEMPLATE_PARALLEL', False))
        self.groups_by_kind = {}
        self.group_checks = {}
        if self.parallel_mode:
            for kind in ('CS', 'SS'):
                bank_key = f'{kind.lower()}_templates'
                fs_key = f'fs_{kind.lower()}'
                groups = _build_parallel_template_banks(
                    self.template_store.get(bank_key, []), self.template_store.get(fs_key, []),
                    TEMPLATE_TARGET_FS, force_peak_positive=True,
                    max_use_types=int(parent.params.get('TEMPLATE_PARALLEL_GROUPS', 3)),
                    n_components=int(parent.params.get('TEMPLATE_PARALLEL_COMPONENTS', 2)))
                self.groups_by_kind[kind] = groups
                row = QtWidgets.QHBoxLayout()
                row.addWidget(QtWidgets.QLabel(f'{kind} groups:'))
                selected = parent.params.get(f'TEMPLATE_{kind}_SELECTED_GROUPS')
                checks = []
                for group_number, (bank, _) in enumerate(groups, start=1):
                    check = QtWidgets.QCheckBox(f'{group_number} (n={len(bank)})')
                    check.setChecked(selected is None or group_number in selected)
                    check.setToolTip(f'Include {kind} template shape group {group_number} in detection.')
                    check.toggled.connect(lambda checked, k=kind, n=group_number:
                                          self._on_group_toggled(k, n, checked))
                    row.addWidget(check)
                    checks.append(check)
                self.group_checks[kind] = checks
                row.addStretch(1)
                layout.addLayout(row)
        self.setLayout(layout)
        self.plot_templates()

    def _on_group_toggled(self, kind, group_number, checked):
        checks = self.group_checks[kind]
        if not any(box.isChecked() for box in checks):
            checks[group_number - 1].setChecked(True)
            return
        self.parent().params[f'TEMPLATE_{kind}_SELECTED_GROUPS'] = [
            index for index, box in enumerate(checks, start=1) if box.isChecked()]
        self.plot_templates()

    def _plot_bank(self, ax, bank_key, fs_key, color, title):
        bank = self.template_store.get(bank_key, [])
        fs_bank = self.template_store.get(fs_key, [])
        if bank is None or len(bank) == 0:
            ax.text(0.5, 0.5, 'No templates', ha='center', va='center', transform=ax.transAxes)
            ax.set_title(title)
            return
        traces = []
        for i, tpl in enumerate(bank):
            try:
                t = np.asarray(tpl, dtype=float).ravel()
                if t.size > 3 and np.all(np.isfinite(t)):
                    traces.append(t)
            except Exception:
                continue
        if len(traces) == 0:
            ax.text(0.5, 0.5, 'No valid templates', ha='center', va='center', transform=ax.transAxes)
            ax.set_title(title)
            return
        min_len = int(np.min([tr.size for tr in traces]))
        stack = np.vstack([tr[:min_len] for tr in traces])
        mean_tpl = np.mean(stack, axis=0)
        try:
            fs0 = float(fs_bank[0]) if fs_bank is not None and len(fs_bank) > 0 and fs_bank[0] is not None else TEMPLATE_TARGET_FS
        except Exception:
            fs0 = TEMPLATE_TARGET_FS
        if not np.isfinite(fs0) or fs0 <= 0:
            fs0 = TEMPLATE_TARGET_FS
        t_ms = np.arange(min_len, dtype=float) * 1000.0 / fs0
        for tr in stack:
            ax.plot(t_ms, tr, color=color, alpha=0.2, lw=_get_linewidth(0.8))
        ax.plot(t_ms, mean_tpl, color=color, lw=_get_linewidth(2.0))
        ax.set_title(f'{title} (n={stack.shape[0]})')
        ax.set_xlabel('ms')
        try:
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
        except Exception:
            pass

    def _plot_parallel_bank(self, ax, bank_key, fs_key, color, title):
        kind = 'CS' if bank_key.startswith('cs_') else 'SS'
        groups = self.groups_by_kind.get(kind, [])
        if groups is None or len(groups) == 0:
            self._plot_bank(ax, bank_key, fs_key, color, title)
            return
        enabled = self.parent().params.get(f'TEMPLATE_{kind}_SELECTED_GROUPS')
        for gi, (tpl_bank, tpl_fs_bank) in enumerate(groups):
            if tpl_bank is None or len(tpl_bank) == 0:
                continue
            rows = [np.asarray(x, dtype=float).ravel() for x in tpl_bank if np.asarray(x, dtype=float).ravel().size > 3]
            if len(rows) == 0:
                continue
            min_len = int(np.min([r.size for r in rows]))
            stack = np.vstack([r[:min_len] for r in rows])
            mean_tpl = np.mean(stack, axis=0)
            try:
                fs0 = float(tpl_fs_bank[0]) if tpl_fs_bank is not None and len(tpl_fs_bank) > 0 else TEMPLATE_TARGET_FS
            except Exception:
                fs0 = TEMPLATE_TARGET_FS
            if not np.isfinite(fs0) or fs0 <= 0:
                fs0 = TEMPLATE_TARGET_FS
            t_ms = np.arange(min_len, dtype=float) * 1000.0 / fs0
            active = enabled is None or gi + 1 in enabled
            ax.plot(t_ms, mean_tpl, lw=_get_linewidth(2.0), alpha=0.95 if active else 0.3,
                    linestyle='-' if active else '--',
                    label=f'Group {gi+1} (n={stack.shape[0]})' + ('' if active else ' off'), color=color)
        ax.set_title(f'{title} (parallel types)')
        ax.set_xlabel('ms')
        try:
            ax.legend(frameon=False, fontsize=_scale_font(8), loc='best')
        except Exception:
            pass
        try:
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
        except Exception:
            pass

    def plot_templates(self):
        self.fig.clf()
        parent = self.parent()
        cols = parent.colors if parent is not None and hasattr(parent, 'colors') else {}
        cs_color = cols.get('cs_trace', '#009E73')
        ss_color = cols.get('ss_trace', '#D55E00')
        ax1 = self.fig.add_subplot(1, 2, 1)
        ax2 = self.fig.add_subplot(1, 2, 2)
        if self.parallel_mode:
            self._plot_parallel_bank(ax1, 'cs_templates', 'fs_cs', cs_color, 'CS Templates')
            self._plot_parallel_bank(ax2, 'ss_templates', 'fs_ss', ss_color, 'SS Templates')
        else:
            self._plot_bank(ax1, 'cs_templates', 'fs_cs', cs_color, 'CS Templates')
            self._plot_bank(ax2, 'ss_templates', 'fs_ss', ss_color, 'SS Templates')
        self.fig.tight_layout()
        self.canvas.draw()


class StatsViewerDialog(QtWidgets.QDialog):
    def __init__(self, data, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Spike Statistics')
        available = self.screen().availableGeometry()
        self.resize(min(1800, max(640, available.width()-40)), min(720, max(480, available.height()-80)))
        self._page_index = 0
        self.data = data
        self.fig = _make_figure(16, 7)
        self.canvas = FigureCanvas(self.fig)
        self.canvas.setMinimumSize(300, 240)
        self.canvas.setSizePolicy(SIZEPOLICY_EXPANDING, SIZEPOLICY_EXPANDING)
        # Top control row: session selector, cell selector, Save Figure
        top_h = QtWidgets.QHBoxLayout()
        parent_win = parent
        self.combo_path = QtWidgets.QComboBox()
        self.combo_path.setMinimumContentsLength(10)
        self.combo_path.setSizeAdjustPolicy(QtWidgets.QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.combo_path.setMaximumWidth(260)
        self.combo_path.addItem('All')
        self.combo_path.addItems(getattr(parent, 'batch_folders', []) or
                                 ([parent.master_folder] if parent and parent.master_folder else []))
        self.combo_path.currentIndexChanged.connect(self._on_path_change)
        # session selector (All + session names)
        self.combo_session = QtWidgets.QComboBox()
        self.combo_session.setMinimumContentsLength(16)
        self.combo_session.setSizeAdjustPolicy(QtWidgets.QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        sess_names = []
        try:
            if parent_win is not None and hasattr(parent_win, 'session_names'):
                sess_names = list(parent_win.session_names)
            else:
                sess_names = list(parent_win.loaded_sessions.keys()) if parent_win is not None else []
        except Exception:
            sess_names = []
        self.combo_session.addItem('All')
        for n in sess_names:
            self.combo_session.addItem(n)
        self.combo_session.currentIndexChanged.connect(self._on_session_change)

        # cell selector (will be populated by session change)
        self.combo_cell = QtWidgets.QComboBox()
        self.combo_cell.addItem('All')
        self.combo_cell.currentIndexChanged.connect(self.compute_stats)

        self.spin_cs_bg_alpha = QtWidgets.QDoubleSpinBox()
        self.spin_cs_bg_alpha.setRange(0.0, 1.0)
        self.spin_cs_bg_alpha.setDecimals(3)
        self.spin_cs_bg_alpha.setSingleStep(0.01)
        self.spin_cs_bg_alpha.setValue(float(parent.params.get('STATS_CS_BG_ALPHA', 0.3)) if parent is not None else 0.3)
        self.spin_cs_bg_alpha.valueChanged.connect(self.compute_stats)

        self.spin_ss_bg_alpha = QtWidgets.QDoubleSpinBox()
        self.spin_ss_bg_alpha.setRange(0.0, 1.0)
        self.spin_ss_bg_alpha.setDecimals(3)
        self.spin_ss_bg_alpha.setSingleStep(0.005)
        self.spin_ss_bg_alpha.setValue(float(parent.params.get('STATS_SS_BG_ALPHA', 0.003)) if parent is not None else 0.003)
        self.spin_ss_bg_alpha.valueChanged.connect(self.compute_stats)

        for combo in (self.combo_path, self.combo_session, self.combo_cell):
            combo.setMinimumWidth(110)
            combo.setMaximumWidth(240)
            combo.setSizePolicy(SIZEPOLICY_EXPANDING, SIZEPOLICY_FIXED)
        for control in (self.spin_cs_bg_alpha, self.spin_ss_bg_alpha):
            control.setFixedWidth(78)

        top_h.addWidget(QtWidgets.QLabel('Path:'))
        top_h.addWidget(self.combo_path, 1)
        top_h.addWidget(QtWidgets.QLabel('Session:'))
        top_h.addWidget(self.combo_session, 1)
        top_h.addWidget(QtWidgets.QLabel('Cell:'))
        top_h.addWidget(self.combo_cell, 1)
        top_h.addWidget(QtWidgets.QLabel('CS bg alpha:'))
        top_h.addWidget(self.spin_cs_bg_alpha)
        top_h.addWidget(QtWidgets.QLabel('SS bg alpha:'))
        top_h.addWidget(self.spin_ss_bg_alpha)
        self.btn_next_page = QtWidgets.QPushButton('Next Page')
        self.btn_next_page.setToolTip('Switch between waveform/ACG distributions and CS-triggered SS rate/local CV2. CV2 uses adjacent ISIs within continuous valid cell/session segments.')
        self.btn_next_page.clicked.connect(self._next_page)
        top_h.addWidget(self.btn_next_page)
        self.btn_save = QtWidgets.QPushButton('Save Figure')
        self.btn_save.clicked.connect(self.save_figure)
        top_h.addWidget(self.btn_save)

        acg_h = QtWidgets.QHBoxLayout()
        acg_h.addWidget(QtWidgets.QLabel('Autocorrelogram:'))
        for spike_type, default_window, default_bin in (('cs', 1000, 10), ('ss', 100, 1)):
            prefix = f'STATS_{spike_type.upper()}_ACG_'
            selected_window = float(parent.params.get(prefix + 'WINDOW_MS', default_window)) if parent is not None else default_window
            selected_bin = float(parent.params.get(prefix + 'BIN_MS', default_bin)) if parent is not None else default_bin
            window = QtWidgets.QDoubleSpinBox()
            window.setDecimals(1)
            window.setFixedWidth(102)
            window.setRange(.1, 10000)
            window.setSuffix(' ms')
            window.setValue(selected_window)
            width = QtWidgets.QDoubleSpinBox()
            width.setDecimals(1)
            width.setFixedWidth(92)
            width.setRange(.1, window.value())
            width.setSuffix(' ms')
            width.setValue(selected_bin)
            setattr(self, f'spin_{spike_type}_acg_window', window)
            setattr(self, f'spin_{spike_type}_acg_bin', width)
            acg_h.addWidget(QtWidgets.QLabel(f'{spike_type.upper()} ± window:'))
            acg_h.addWidget(window)
            acg_h.addWidget(QtWidgets.QLabel('Bin:'))
            acg_h.addWidget(width)
            window.valueChanged.connect(width.setMaximum)
            window.valueChanged.connect(self.compute_stats)
            width.valueChanged.connect(self.compute_stats)
        self.spin_distribution_bins = QtWidgets.QSpinBox()
        self.spin_distribution_bins.setRange(1, 200)
        self.spin_distribution_bins.setFixedWidth(74)
        self.spin_distribution_bins.setValue(int(parent.params.get('STATS_DISTRIBUTION_BINS', 20)) if parent is not None else 20)
        self.spin_distribution_bins.valueChanged.connect(self.compute_stats)
        acg_h.addStretch(1)
        self.page_controls = QtWidgets.QStackedWidget()
        acg_page = QtWidgets.QWidget(); acg_page.setLayout(acg_h)
        self.page_controls.addWidget(acg_page)
        temporal = QtWidgets.QHBoxLayout()
        settings = (('spin_peth_pre_ms','Before CS:','STATS_PETH_PRE_MS',20.,' ms',0.,10000.),
            ('spin_peth_post_ms','After:','STATS_PETH_POST_MS',60.,' ms',0.,10000.),
            ('spin_peth_bin_ms','Bin:','STATS_PETH_BIN_MS',1.,' ms',.1,1000.),
            ('spin_ss_trend_s','SS rate window:','STATS_SS_TREND_S',5.,' s',.1,600.),
            ('spin_cs_trend_s','CS rate window:','STATS_CS_TREND_S',5.,' s',.1,600.))
        temporal.addWidget(QtWidgets.QLabel('SS PETH:'))
        for name,label,key,default,suffix,minimum,maximum in settings:
            control=QtWidgets.QDoubleSpinBox(); control.setDecimals(1)
            control.setRange(minimum,maximum); control.setSuffix(suffix); control.setFixedWidth(90)
            control.setValue(float(parent.params.get(key,default)) if parent is not None else default)
            setattr(self,name,control)
            temporal.addWidget(QtWidgets.QLabel(label));temporal.addWidget(control)
        self.spin_peth_pre_ms.valueChanged.connect(lambda value:self.spin_peth_post_ms.setMinimum(.1 if value==0 else 0))
        self.spin_peth_post_ms.setMinimum(.1 if self.spin_peth_pre_ms.value()==0 else 0)
        for name,*_ in settings:
            getattr(self,name).valueChanged.connect(self.compute_stats)
        temporal.addStretch(1)
        temporal_page=QtWidgets.QWidget();temporal_page.setLayout(temporal)
        self.page_controls.addWidget(temporal_page)
        controls_row=QtWidgets.QHBoxLayout()
        controls_row.addWidget(self.page_controls,1)
        controls_row.addWidget(QtWidgets.QLabel('Distribution bins:'))
        controls_row.addWidget(self.spin_distribution_bins)

        layout = QtWidgets.QVBoxLayout()
        layout.addLayout(top_h)
        layout.addLayout(controls_row)
        layout.addWidget(self.canvas)
        self.setLayout(layout)
        _apply_setting_tooltips(self)

        # initialize cell list based on current session selection
        self._on_session_change(0)
        # initial plot
        self.compute_stats()

    def _next_page(self):
        self._page_index = 1-self._page_index
        self.page_controls.setCurrentIndex(self._page_index)
        self.btn_next_page.setText('Previous Page' if self._page_index else 'Next Page')
        self.compute_stats()

    @staticmethod
    def _style_axes(axes):
        for axis in axes:
            axis.spines[['top', 'right']].set_visible(False)
            axis.tick_params(labelsize=8)
            axis.title.set_fontsize(10)
            axis.xaxis.label.set_size(9)
            axis.yaxis.label.set_size(9)
            if axis.axison:
                if not getattr(axis, '_stats_wide', False):
                    axis.set_box_aspect(1)

    def _plot_temporal_stats(self, items, colors, manual_summary):
        edges = peth_edges(self.spin_peth_pre_ms.value(),self.spin_peth_post_ms.value(),self.spin_peth_bin_ms.value())
        n_bins = edges.size-1
        counts, exposure = np.zeros(n_bins, dtype=int), np.zeros(n_bins)
        cv2 = {'CS': [], 'SS': []}
        dff = {'CS': [], 'SS': []}
        records = {'CS': [], 'SS': []}
        references, used = 0, 0
        for res, data, cell in items:
            if not isinstance(res, dict):
                continue
            time = np.asarray(data['time_ms'], dtype=float)
            intervals, times, available = {}, {}, {}
            run_params = data.get('_saved_detection_params', data.get('_control_context', {}).get('params', {}))
            for kind in ('CS', 'SS'):
                prefix = kind.lower()
                peaks = np.asarray(res.get(prefix+'_peaks', []), dtype=int)
                peaks = peaks[(peaks >= 0) & (peaks < time.size)]
                times[kind] = time[peaks]
                excluded = np.asarray(res.get(prefix+'_exclusion_mask', np.zeros(time.size, bool)), bool)
                excluded = excluded | np.asarray(res.get('recording_exclusion_mask', np.zeros(time.size, bool)), bool)
                intervals[kind] = recording_intervals_ms(time, float(data['fs']), excluded)
                info = res.get(prefix+'_candidate_diagnostics', {})
                available[kind] = bool(res.get(prefix+'_detection_enabled', True)) and not info.get('no_templates', False)
                if not res.get('manual_labels') and 'Template' not in str(res.get('det_method', '')):
                    available[kind] &= run_params.get(kind+'_THRESHOLD_SIGMA', 1) != 0
                if available[kind]:
                    cv2[kind].extend(local_cv2_values(times[kind], intervals[kind]))
                    amplitudes = self._event_amplitudes(data,cell,res,kind)
                    dff[kind].extend(amplitudes[np.isfinite(amplitudes)])
                    records[kind].append(dict(session_key=id(data), times_s=(times[kind]-time[0])/1000,
                        dff_percent=amplitudes, intervals_s=(intervals[kind]-time[0])/1000))
            if available['CS'] and available['SS']:
                c, e, n = triggered_rate_components(times['CS'], times['SS'], edges,
                    intervals['CS'], intervals['SS'])
                counts += c; exposure += e; references += n
                used += int(n > 0)
        rate = np.divide(counts, exposure, out=np.full(n_bins, np.nan), where=exposure > 0)
        sessions = self._selected_session_catalog()
        courses = {kind:session_time_courses(sessions,records[kind],getattr(self,'spin_'+kind.lower()+'_trend_s').value()) for kind in ('CS','SS')}
        self.temporal_statistics = dict(edges_ms=edges, counts=counts, exposure_s=exposure,
            rate_hz=rate, cs_references=references, recordings=used,
            cv2={kind: np.asarray(values) for kind, values in cv2.items()},
            dff_percent={kind:np.asarray(values) for kind,values in dff.items()}, courses=courses)
        self.fig.clf()
        grid = self.fig.add_gridspec(2,4,width_ratios=[1,1,1.65,1.1],wspace=.66,hspace=.52)
        self.fig.subplots_adjust(left=.045,right=.97,bottom=.15,top=.91)
        for row,kind in enumerate(('SS','CS')):
            color=colors[kind.lower()+'_trace']
            values=self.temporal_statistics['cv2'][kind]
            ax=self.fig.add_subplot(grid[row,0]);ax.set_gid(kind.lower()+'_cv2')
            if values.size:
                ax.hist(values,bins=int(self.spin_distribution_bins.value()),range=(0,2),color=color,alpha=.8)
                ax.axvline(np.mean(values),color=color,ls='--',label=f'Mean {np.mean(values):.2f}')
                ax.legend(frameon=False,fontsize=7)
            else:
                ax.text(.5,.5,'No valid ISI triplets',ha='center',transform=ax.transAxes,fontsize=8)
            ax.set(xlim=(0,2),title=kind+' local CV2',xlabel='CV2',ylabel='Count')
            ax=self.fig.add_subplot(grid[row,1]);ax.set_gid(kind.lower()+'_dff')
            values=self.temporal_statistics['dff_percent'][kind]
            if values.size:
                ax.hist(values,bins=int(self.spin_distribution_bins.value()),color=color,alpha=.8)
            else:
                ax.text(.5,.5,'No valid event dF/F',ha='center',transform=ax.transAxes,fontsize=8)
            ax.set(title=kind+' dF/F',xlabel='Spike dF/F (%)',ylabel='Count')
            ax=self.fig.add_subplot(grid[row,2]);ax.set_gid(kind.lower()+'_trend')
            ax._stats_wide=True;ax.set_box_aspect(1/1.65)
            ax.set(title=kind+' over time',xlabel='Concatenated recording time (s)',ylabel='Spike dF/F (%)')
            course=courses[kind]
            if course['reason']:
                ax.text(.5,.5,course['reason'],ha='center',va='center',wrap=True,transform=ax.transAxes,fontsize=8)
                continue
            twin=ax.twinx();twin.set_gid(kind.lower()+'_rate');twin._stats_wide=True
            twin.set_ylabel('Rate (Hz)',color='#4C72B0',fontsize=9)
            for segment in course['segments']:
                ax.plot(segment['time_s'],segment['dff_percent'],color=color,lw=_get_linewidth(1.5))
                twin.plot(segment['time_s'],segment['rate_hz'],color='#4C72B0',lw=_get_linewidth(1.3))
            for boundary in course['boundaries_s']:
                ax.axvline(boundary,color='.6',ls=':',lw=_get_linewidth(.7))
            ax.set_xlim(0,course['duration_s']);ax.tick_params(axis='y',labelcolor=color)
            ax.yaxis.label.set_color(color);twin.tick_params(axis='y',labelcolor='#4C72B0')
            twin.set_ylim(bottom=0)
            if not any(np.any(np.isfinite(segment['dff_percent'])) for segment in course['segments']):
                ax.text(.5,.85,'No finite dF/F',ha='center',transform=ax.transAxes,fontsize=8)
        axis=self.fig.add_subplot(grid[:,3]);axis.set_gid('cs_ss_peth')
        axis.stairs(rate,edges,color=colors['ss_trace'],linewidth=_get_linewidth(1.6))
        axis.axvline(0,color='.4',ls=':',lw=_get_linewidth(.9))
        axis.set(xlim=(edges[0],edges[-1]),ylim=(0,max(1,float(np.nanmax(rate))*1.12) if np.any(np.isfinite(rate)) else 1),
            title='CS-triggered SS rate',xlabel='Time relative to CS (ms)',ylabel='SS rate (Hz)')
        missing=exposure<=0
        boundaries=np.flatnonzero(np.diff(np.r_[False,missing,False]))
        for left,right in boundaries.reshape(-1,2):
            axis.axvspan(edges[left],edges[right],color='.85',alpha=.6,lw=0)
        if not references:
            axis.text(.5,.5,'No eligible CS triggers',ha='center',transform=axis.transAxes,fontsize=8)
        axis.text(0,-.27,f'{references} CS triggers',transform=axis.transAxes,fontsize=8)
        self._style_axes(self.fig.axes)
        for axis in self.fig.axes:
            if axis.get_gid() in ('ss_rate','cs_rate'):
                axis.spines['right'].set_visible(True)
        footer='dF/F uses saved event amplitudes (comparison method). Blue: rate; dotted lines: session joins. Grey PETH bins: no SS exposure.'
        if manual_summary:
            footer+='\nManual labels are partial/unverified.'
        self.fig.text(.045,.035,footer,fontsize=8,va='bottom')
        self.canvas.draw()

    def _selected_session_catalog(self):
        parent=self.parent()
        names=self._path_session_names() if self.combo_session.currentText()=='All' else [self.combo_session.currentText()]
        sessions=[]
        for name in names:
            data=parent.loaded_sessions.get(name) if parent is not None else None
            if data is None:
                continue
            source=data.get('source_folder') or (str(Path(data['session_path']).parent) if data.get('session_path') else None)
            source_name=Path(data.get('source_session_id',data.get('session_path',name))).name
            sessions.append(dict(key=id(data),name=source_name,folder=source,
                duration_s=len(data['time_ms'])/float(data['fs'])))
        return sessions

    def _event_amplitudes(self,data,cell,res,kind):
        prefix=kind.lower();peaks=np.asarray(res.get(prefix+'_peaks',[]),int)
        values=res.get('event_minus_dff_percent_'+prefix)
        saved = (np.asarray(values,float).ravel() if values is not None and np.array_equal(res.get('dff_indices_'+prefix,peaks),peaks) else None)
        if saved is not None and saved.size>=peaks.size:
            return saved[:peaks.size]
        if data.get('loaded_detection_result'):
            trace=np.asarray(data['processed_raw_data'][:,cell],float)
            baseline=np.asarray(data['baseline_traces'][:,cell],float)
        else:
            context=data.get('_control_context',{})
            params=context.get('params',getattr(self.parent(),'params',{}))
            base=context.get('baseline_params',getattr(self.parent(),'baseline_params',dict(method='Median',window_ms=30,percentile=20)))
            trace,baseline,_=protected_preprocess(data['raw_data'][:,cell],float(data['fs']),params,base,
                context.get('frames',0),context.get('frame_mode','Rolling average'))
        valid=~np.asarray(res.get('recording_exclusion_mask',np.zeros(len(trace),bool)),bool)
        values=event_dff_percent(trace,baseline,peaks,float(data['fs']),res.get('negative_going',True),valid)
        if saved is not None:
            values[:saved.size]=saved  # Explicit saved NaNs stay missing; only absent slots are recomputed.
        res['event_minus_dff_percent_'+prefix]=values
        res['dff_indices_'+prefix]=peaks.copy()
        return values

    def _path_session_names(self):
        parent = self.parent()
        if parent is None:
            return []
        path = self.combo_path.currentText()
        return [name for name in parent.session_names
                if path == 'All' or
                parent.loaded_sessions.get(name, {}).get('source_folder', parent.master_folder) == path]

    def _on_path_change(self, idx):
        self.combo_session.blockSignals(True)
        self.combo_session.clear()
        self.combo_session.addItem('All')
        self.combo_session.addItems(self._path_session_names())
        self.combo_session.blockSignals(False)
        self._on_session_change(0)

    def _on_session_change(self, idx):
        # Populate the cell combobox based on selected session.
        self.combo_cell.blockSignals(True)
        try:
            self.combo_cell.clear()
            self.combo_cell.addItem('All')
            parent_win = self.parent()
            sel = 'All'
            try:
                sel = self.combo_session.currentText()
            except Exception:
                sel = 'All'
            if sel == 'All':
                # Collect union of cell names across sessions
                names = []
                try:
                    if parent_win is not None and hasattr(parent_win, 'session_names'):
                        for s in self._path_session_names():
                            sdata = parent_win.loaded_sessions.get(s, None)
                            if sdata is None:
                                continue
                            for n in sdata.get('cell_names', []):
                                if n not in names:
                                    names.append(n)
                except Exception:
                    names = []
                for n in names:
                    self.combo_cell.addItem(n)
            else:
                try:
                    sdata = parent_win.loaded_sessions.get(sel, None) if parent_win is not None else None
                    if sdata is not None:
                        for n in sdata.get('cell_names', []):
                            self.combo_cell.addItem(n)
                except Exception:
                    pass
        except Exception:
            pass
        finally:
            self.combo_cell.blockSignals(False)
        # Trigger recompute
        try:
            self.compute_stats()
        except Exception:
            pass

    def compute_stats(self):
        parent = self.parent()
        defaults = {'cs_trace': '#009E73', 'ss_trace': '#D55E00', 'raw': '#333333', 'baseline': '#FFC20A'}
        colors = dict(defaults)
        if parent is not None and isinstance(parent, object):
            try:
                colors.update(parent.colors)
            except Exception:
                pass
        # Build list of (res, session_data, cell_idx) according to user selection
        sel_session = None
        sel_cell = None
        try:
            sel_session = self.combo_session.currentText()
        except Exception:
            sel_session = 'All'
        try:
            sel_cell = self.combo_cell.currentText()
        except Exception:
            sel_cell = 'All'

        # gather items: list of tuples (res, session_data, cell_idx)
        items = []
        parent_win = self.parent()
        if sel_session == 'All':
            # iterate all sessions
            sessions_iter = []
            try:
                if parent_win is not None and hasattr(parent_win, 'session_names'):
                    sessions_iter = self._path_session_names()
                else:
                    sessions_iter = list(parent_win.loaded_sessions.keys()) if parent_win is not None else []
            except Exception:
                sessions_iter = []
            for sname in sessions_iter:
                sdata = parent_win.loaded_sessions.get(sname, None) if parent_win is not None else None
                if sdata is None:
                    continue
                # If a specific cell name requested, try to find its index in this session
                if sel_cell != 'All':
                    try:
                        idx = sdata.get('cell_names', []).index(sel_cell)
                        res = sdata.get('results', [None])[idx]
                        items.append((res, sdata, idx))
                    except Exception:
                        # cell not found in this session
                        continue
                else:
                    # add all cells for this session
                    for idx, res in enumerate(sdata.get('results', [])):
                        items.append((res, sdata, idx))
        else:
            # single session selected
            sdata = parent_win.loaded_sessions.get(sel_session, None) if parent_win is not None else None
            if sdata is not None:
                if sel_cell != 'All':
                    try:
                        idx = sdata.get('cell_names', []).index(sel_cell)
                        res = sdata.get('results', [None])[idx]
                        items.append((res, sdata, idx))
                    except Exception:
                        pass
                else:
                    for idx, res in enumerate(sdata.get('results', [])):
                        items.append((res, sdata, idx))

        bins = int(self.spin_distribution_bins.value())
        if parent is not None:
            parent.params['STATS_DISTRIBUTION_BINS'] = bins
            for key,name in (('STATS_PETH_PRE_MS','spin_peth_pre_ms'),('STATS_PETH_POST_MS','spin_peth_post_ms'),('STATS_PETH_BIN_MS','spin_peth_bin_ms'),('STATS_SS_TREND_S','spin_ss_trend_s'),('STATS_CS_TREND_S','spin_cs_trend_s')):
                parent.params[key]=getattr(self,name).value()
        # Now compute stats across collected items
        all_stats = {'CS': {'waves': [], 'snr': [], 'fwhm': [], 'inst_rate': []}, 'SS': {'waves': [], 'snr': [], 'fwhm': [], 'inst_rate': []}}
        acg_settings = {
            'CS': (self.spin_cs_acg_window.value(), self.spin_cs_acg_bin.value()),
            'SS': (self.spin_ss_acg_window.value(), self.spin_ss_acg_bin.value()),
        }
        if parent is not None:
            for kind, (window, bin_width) in acg_settings.items():
                parent.params[f'STATS_{kind}_ACG_WINDOW_MS'] = window
                parent.params[f'STATS_{kind}_ACG_BIN_MS'] = bin_width
        acg_edges = {}
        acg_counts = {}
        acg_exposure = {}
        for kind, (window, bin_width) in acg_settings.items():
            acg_edges[kind], acg_counts[kind] = autocorrelogram_counts([], window, bin_width)
            acg_exposure[kind] = np.zeros_like(acg_counts[kind], dtype=float)
        rates = {'CS': [], 'SS': []}
        uncertain_counts = {'CS': 0, 'SS': 0}
        valid_seconds = {'CS': 0.0, 'SS': 0.0}
        items = [(res, data, cell) for res, data, cell in items
                 if not data.get('is_manual_labels') or cell in data.get('label_metadata', {}).get('labelled_cells', [])]
        manual_summary = any(data.get('is_manual_labels') for _, data, _ in items)
        if self._page_index:
            self._plot_temporal_stats(items, colors, manual_summary)
            return
        for res, sdata, cell_idx in items:
            if res is None or sdata is None:
                continue
            try:
                fs = float(sdata.get('fs', 1000.0))
                duration_s = len(sdata.get('time_ms', [])) / fs if len(sdata.get('time_ms', [])) > 1 else np.nan
            except Exception:
                fs = float(self.data.get('fs', 1000.0))
                duration_s = np.nan

            trace_for_waveforms = None
            try:
                if parent_win is not None and hasattr(parent_win, '_get_waveform_source_trace_for_stats'):
                    trace_for_waveforms = parent_win._get_waveform_source_trace_for_stats(sdata, cell_idx)
            except Exception:
                trace_for_waveforms = None

            for spike_type in ['CS', 'SS']:
                try:
                    window_ms_type = _stats_window_ms(spike_type)
                    half_win = int((window_ms_type / 2.0) * fs / 1000.0)
                    peaks_key = 'cs_peaks' if spike_type == 'CS' else 'ss_peaks'
                    peaks = np.array(res.get(peaks_key, []), dtype=int)
                    time_ms = np.asarray(sdata['time_ms'], dtype=float)
                    valid_peaks = peaks[(peaks >= 0) & (peaks < time_ms.size)]
                    observation = recording_intervals_ms(time_ms, fs,
                        res.get(spike_type.lower() + '_exclusion_mask'))
                    _, cell_acg, exposure = autocorrelogram_components(
                        time_ms[valid_peaks], *acg_settings[spike_type], observation)
                    acg_counts[spike_type] += cell_acg
                    acg_exposure[spike_type] += exposure
                    uncertain_counts[spike_type] += sum(not np.isfinite(r['fwhm_ms']) for r in res.get('event_widths_' + spike_type.lower(), []))
                    all_stats[spike_type]['fwhm'].extend(r['fwhm_ms'] for r in res.get('event_widths_' + spike_type.lower(), []) if np.isfinite(r['fwhm_ms']))
                    valid_seconds[spike_type] += np.sum(~res.get(spike_type.lower() + '_exclusion_mask', np.zeros(len(sdata['time_ms']), dtype=bool))) / fs
                    if duration_s and duration_s > 0:
                        rates[spike_type].append(len(peaks) / (np.sum(~res.get('recording_exclusion_mask', np.zeros(len(sdata['time_ms']), bool)))/fs))
                    try:
                        chosen_for_rate = _select_event_bank(peaks, max_per_cell=None)
                        if chosen_for_rate is not None and len(chosen_for_rate) >= 2:
                            isi_ms = np.diff(np.asarray(sdata['time_ms'])[np.sort(np.asarray(chosen_for_rate, dtype=int))])
                            isi_ms = isi_ms[np.isfinite(isi_ms)]
                            if isi_ms.size > 0:
                                inst_rate = 1000.0 / isi_ms[isi_ms > 0]
                                inst_rate = inst_rate[np.isfinite(inst_rate)]
                                if inst_rate.size > 0:
                                    all_stats[spike_type]['inst_rate'].extend(list(inst_rate))
                    except Exception:
                        pass
                    # compute SNRs
                    event_snrs = compute_event_snrs(
                        res,
                        spike_type,
                        fs,
                        window_ms=window_ms_type,
                        max_per_cell=None,
                        trace_override=trace_for_waveforms,
                    )
                    if len(event_snrs) > 0:
                        all_stats[spike_type]['snr'].extend(event_snrs)
                    # collect waveforms and fwhm
                    if trace_for_waveforms is not None:
                        trace = np.asarray(trace_for_waveforms, dtype=float)
                    else:
                        trace = res.get('cs_trace') if spike_type == 'CS' else (res.get('ss_trace') if res.get('ss_trace', None) is not None else res.get('detrended', None))
                    if trace is None or peaks.size == 0:
                        continue
                    fwhm_trace = np.asarray(res.get('cs_trace', trace), dtype=float) if spike_type == 'CS' else np.asarray(trace, dtype=float)
                    chosen = _select_event_bank(peaks, max_per_cell=None)
                    for p in chosen:
                        s = int(p - half_win); e = int(p + half_win)
                        if s < 0 or e > len(trace):
                            continue
                        wave = trace[s:e]
                        if len(wave) != (2 * half_win):
                            continue
                        if not np.all(np.isfinite(wave)):
                            continue
                        if len(wave) > 5:
                            wave = wave - np.mean(wave[:5])
                        all_stats[spike_type]['waves'].append(wave)
                except Exception:
                    pass

        cs_r_mean, cs_r_std, cs_r_n = mean_std_count(rates['CS'])
        ss_r_mean, ss_r_std, ss_r_n = mean_std_count(rates['SS'])
        cs_snr_mean, cs_snr_std, cs_snr_n = mean_std_count(all_stats['CS']['snr'])
        ss_snr_mean, ss_snr_std, ss_snr_n = mean_std_count(all_stats['SS']['snr'])
        cs_fwhm_mean, cs_fwhm_std, cs_fwhm_n = mean_std_count(all_stats['CS']['fwhm'])
        ss_fwhm_mean, ss_fwhm_std, ss_fwhm_n = mean_std_count(all_stats['SS']['fwhm'])
        cs_inst_mean, cs_inst_std, cs_inst_n = mean_std_count(all_stats['CS']['inst_rate'])
        ss_inst_mean, ss_inst_std, ss_inst_n = mean_std_count(all_stats['SS']['inst_rate'])

        # Plot: 2 rows x 6 cols (last col for text summary)
        self.fig.clf()
        gs = self.fig.add_gridspec(2, 6, width_ratios=[1, 1, 1, 1, 1, 1.55],
                                   wspace=0.46, hspace=0.48)
        self.fig.subplots_adjust(left=.04, right=.99, bottom=.12, top=.91)

        def _robust_hist_range(arr, q_lo=0.01, q_hi=0.99, floor_zero=True):
            x = np.asarray(arr, dtype=float)
            x = x[np.isfinite(x)]
            if x.size <= 0:
                return None
            try:
                lo = float(np.nanquantile(x, q_lo))
                hi = float(np.nanquantile(x, q_hi))
            except Exception:
                lo = float(np.nanmin(x))
                hi = float(np.nanmax(x))
            if floor_zero:
                lo = max(0.0, lo)
            # Fallback for degenerate/near-degenerate distributions.
            if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
                lo = max(0.0, float(np.nanmin(x))) if floor_zero else float(np.nanmin(x))
                hi = float(np.nanmax(x))
            if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
                return None
            # Small pad so last bin edge doesn't cut peak values too tightly.
            pad = 0.02 * (hi - lo)
            return (lo, hi + pad)

        def _pick_color(d, keys, default):
            for k in keys:
                try:
                    if k in d and d.get(k) is not None:
                        return d.get(k)
                except Exception:
                    pass
            return default

        for row, spike_type in enumerate(['CS', 'SS']):
            stats = all_stats[spike_type]
            waves = stats['waves']
            snr = stats['snr']
            fwhm = stats['fwhm']
            inst_rate = stats['inst_rate']
            # Try common color keys in parent/colors for robustness: prefer *_trace, then short name
            if spike_type == 'CS':
                color = _pick_color(colors, ['cs_trace', 'cs'], '#009E73')
            else:
                color = _pick_color(colors, ['ss_trace', 'ss'], '#D55E00')

            try:
                bg_alpha = float(self.spin_cs_bg_alpha.value()) if spike_type == 'CS' else float(self.spin_ss_bg_alpha.value())
            except Exception:
                bg_alpha = 0.3 if spike_type == 'CS' else 0.003
            bg_alpha = float(max(0.0, min(1.0, bg_alpha)))
            try:
                if parent is not None:
                    if spike_type == 'CS':
                        parent.params['STATS_CS_BG_ALPHA'] = bg_alpha
                    else:
                        parent.params['STATS_SS_BG_ALPHA'] = bg_alpha
            except Exception:
                pass

            # per-spike-type time window: CS=100ms, SS=50ms
            w_ms = _stats_window_ms(spike_type)

            ax1 = self.fig.add_subplot(gs[row, 0])
            mean_wave = None
            std_wave = None
            if len(waves) > 0:
                wave_list = [np.asarray(w, dtype=float).ravel() for w in waves if np.asarray(w).size > 0]
                wave_list = [w for w in wave_list if np.all(np.isfinite(w))]
                max_cap = 500 if spike_type == 'SS' else 500
                max_bg = min(len(waves), max_cap)
                for w in wave_list[:max_bg]:
                    ax1.plot(np.linspace(-w_ms/2.0, w_ms/2.0, len(w)), w, color=color, alpha=bg_alpha, lw=_get_linewidth(0.5))
                if len(wave_list) > 0:
                    min_len = int(min([len(w) for w in wave_list]))
                    if min_len > 1:
                        stack = np.vstack([w[:min_len] for w in wave_list])
                        mean_wave = np.mean(stack, axis=0)
                        std_wave = np.std(stack, axis=0)
                        ax1.plot(np.linspace(-w_ms/2.0, w_ms/2.0, min_len), mean_wave, color=color, lw=_get_linewidth(3))
            # Keep y=0 anchored by the mean waveform envelope instead of outlier traces.
            if mean_wave is not None and std_wave is not None and len(mean_wave) > 1:
                try:
                    y_low = float(np.nanmin(mean_wave - 2.0 * std_wave))
                    y_high = float(np.nanmax(mean_wave + 2.0 * std_wave))
                    if np.isfinite(y_low) and np.isfinite(y_high) and y_high > y_low:
                        pad = 0.08 * (y_high - y_low)
                        y_low -= pad
                        y_high += pad
                        if y_low > 0.0:
                            y_low = -pad
                        if y_high < 0.0:
                            y_high = pad
                        ax1.set_ylim(y_low, y_high)
                except Exception:
                    pass
            ax1.axhline(0.0, color='0.5', lw=_get_linewidth(0.8), alpha=0.6, zorder=1)
            ax1.set_title(f"{spike_type} Waveforms")
            ax1.set_xlabel('ms')
            try:
                ax1.spines['top'].set_visible(False)
            except Exception:
                pass
            try:
                ax1.spines['right'].set_visible(False)
            except Exception:
                pass

            ax_acg = self.fig.add_subplot(gs[row, 1])
            edges = acg_edges[spike_type]
            counts = acg_counts[spike_type]
            acg_window, _ = acg_settings[spike_type]
            exposure = acg_exposure[spike_type]
            rate_hz = np.divide(counts, exposure, out=np.full(counts.shape, np.nan), where=exposure > 0)
            ax_acg.stairs(rate_hz, edges, fill=True, color=color, alpha=0.8)
            ax_acg.axvline(0, color='0.4', lw=_get_linewidth(0.8), ls=':')
            ax_acg.set_xlim(-acg_window, acg_window)
            ax_acg.set_title(f'{spike_type} ACG')
            ax_acg.set_xlabel('Lag (ms)')
            ax_acg.set_ylabel('Spike rate (Hz)')
            if not np.any(counts):
                ax_acg.set_ylim(0, 1)
                empty_label = 'No pairs in window' if np.any(exposure > 0) else 'No reference spikes'
                ax_acg.text(0.5, 0.5, empty_label, ha='center', va='center',
                            transform=ax_acg.transAxes)
            else:
                ax_acg.set_ylim(bottom=0)

            ax2 = self.fig.add_subplot(gs[row, 2])
            if len(fwhm) > 0:
                fwhm_arr = np.asarray(fwhm, dtype=float)
                fwhm_arr = fwhm_arr[np.isfinite(fwhm_arr)]
                ax2.hist(fwhm_arr, bins=bins, color=color, alpha=0.8)
                ax2.set_title('FWHM')
                if fwhm_arr.size > 0:
                    lo = max(0.0, float(np.nanmin(fwhm_arr)) * 0.95)
                    hi = float(np.nanmax(fwhm_arr)) * 1.05
                    if hi > lo:
                        ax2.set_xlim(lo, hi)
            ax2.set_xlabel('FWHM (ms)')
            ax2.set_ylabel('Count')
            try:
                ax2.spines['top'].set_visible(False)
            except Exception:
                pass
            try:
                ax2.spines['right'].set_visible(False)
            except Exception:
                pass
            if len(fwhm) == 0:
                ax2.text(0.5, 0.5, 'No data', ha='center')

            ax3 = self.fig.add_subplot(gs[row, 3])
            if len(snr) > 0:
                snr_arr = np.asarray(snr, dtype=float)
                snr_arr = snr_arr[np.isfinite(snr_arr)]
                snr_range = _robust_hist_range(snr_arr, q_lo=0.01, q_hi=0.99, floor_zero=True)
                if snr_range is not None:
                    ax3.hist(snr_arr, bins=bins, range=snr_range, color=color, alpha=0.8)
                else:
                    ax3.hist(snr_arr, bins=bins, color=color, alpha=0.8)
                ax3.set_title('SNR')
                if snr_arr.size > 0:
                    if snr_range is not None and snr_range[1] > snr_range[0]:
                        ax3.set_xlim(snr_range[0], snr_range[1])
                    else:
                        lo = max(0.0, float(np.nanmin(snr_arr)) * 0.95)
                        hi = float(np.nanmax(snr_arr)) * 1.05
                        if hi > lo:
                            ax3.set_xlim(lo, hi)
            ax3.set_xlabel('SNR')
            ax3.set_ylabel('Count')
            try:
                ax3.spines['top'].set_visible(False)
            except Exception:
                pass
            try:
                ax3.spines['right'].set_visible(False)
            except Exception:
                pass
            if not np.any(np.isfinite(np.asarray(snr, dtype=float))):
                ax3.text(0.5, 0.5, 'No data', ha='center')

            ax4 = self.fig.add_subplot(gs[row, 4])
            if len(inst_rate) > 0:
                rate_arr = np.asarray(inst_rate, dtype=float)
                rate_arr = rate_arr[np.isfinite(rate_arr)]
                rate_range = _robust_hist_range(rate_arr, q_lo=0.01, q_hi=0.99, floor_zero=True)
                if rate_range is not None:
                    ax4.hist(rate_arr, bins=bins, range=rate_range, color=color, alpha=0.8)
                else:
                    ax4.hist(rate_arr, bins=bins, color=color, alpha=0.8)
                ax4.set_title('Instantaneous rate')
                if rate_arr.size > 0:
                    if rate_range is not None and rate_range[1] > rate_range[0]:
                        ax4.set_xlim(rate_range[0], rate_range[1])
                    else:
                        lo = max(0.0, float(np.nanmin(rate_arr)) * 0.95)
                        hi = float(np.nanmax(rate_arr)) * 1.05
                        if hi > lo:
                            ax4.set_xlim(lo, hi)
            ax4.set_xlabel('Rate (Hz)')
            ax4.set_ylabel('Count')
            try:
                ax4.spines['top'].set_visible(False)
            except Exception:
                pass
            try:
                ax4.spines['right'].set_visible(False)
            except Exception:
                pass
            if len(inst_rate) == 0:
                ax4.text(0.5, 0.5, 'No data', ha='center')

            # right-side text summary
            ax_txt = self.fig.add_subplot(gs[row, 5])
            ax_txt.axis('off')
            txt_lines = []
            txt_lines.append(f"Rate: {cs_r_mean:.2f}±{cs_r_std:.2f} Hz" if spike_type == 'CS' else f"Rate: {ss_r_mean:.2f}±{ss_r_std:.2f} Hz")
            if spike_type == 'CS':
                txt_lines.append(f"FWHM: {cs_fwhm_mean:.2f}±{cs_fwhm_std:.2f} ms (n={cs_fwhm_n})")
                txt_lines.append(f"SNR: {cs_snr_mean:.2f}±{cs_snr_std:.2f} (n={cs_snr_n})")
                txt_lines.append(f"Inst rate: {cs_inst_mean:.2f}±{cs_inst_std:.2f} Hz (n={cs_inst_n})")
            else:
                txt_lines.append(f"FWHM: {ss_fwhm_mean:.2f}±{ss_fwhm_std:.2f} ms (n={ss_fwhm_n})")
                txt_lines.append(f"SNR: {ss_snr_mean:.2f}±{ss_snr_std:.2f} (n={ss_snr_n})")
                txt_lines.append(f"Inst rate: {ss_inst_mean:.2f}±{ss_inst_std:.2f} Hz (n={ss_inst_n})")
            txt_lines.append(f"Uncertain widths: {uncertain_counts[spike_type]}")
            txt_lines.append(f"Valid time: {valid_seconds[spike_type]:.2f} cell-s")
            if manual_summary:
                txt_lines[0] = txt_lines[0].replace('Rate:', 'Label/mixed rate:')
                txt_lines.append('Manual labels: partial/unverified')
            import textwrap
            width_chars = max(20, min(33, int(ax_txt.get_position().width * (self.width()-40) / 6.5)))
            summary = '\n'.join(textwrap.fill(line, width=width_chars, break_long_words=False, break_on_hyphens=False) for line in txt_lines)
            ax_txt.text(0.02, 0.5, summary, va='center', ha='left', fontsize=8.5)

        self._style_axes(self.fig.axes)
        self.canvas.draw()

    def save_figure(self):
        try:
            filename = save_figure_with_dialog(
                lambda title, default, flt: QFileDialog.getSaveFileName(self, title, default, flt),
                self.canvas.figure,
                default_name='stats_figure.svg',
            )
            if filename:
                QMessageBox.information(self, 'Saved', f'Figure saved as {filename}')
        except Exception as e:
            QMessageBox.critical(self, 'Error', f'Failed to save figure: {e}')


class SettingsDialog(QtWidgets.QDialog):
    """Advanced timing, morphology, template, denoising and display settings."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Advanced Settings')
        self.resize(*_scaled_size(460, 280))
        self.parent_win = parent

        layout = QtWidgets.QVBoxLayout()

        form = QtWidgets.QFormLayout()
        p = parent.params if parent is not None else {}

        self.chk_denoise_cs = QtWidgets.QCheckBox('Use denoised trace for CS detection')
        self.chk_denoise_cs.setChecked(bool(p.get('DENOISE_APPLY_TO_CS', False)))
        form.addRow(self.chk_denoise_cs)
        # CS min dist and SS-specific params moved into Advanced Settings
        self.spin_cs_mind = QtWidgets.QDoubleSpinBox(); self.spin_cs_mind.setRange(0.0,1000.0); self.spin_cs_mind.setValue(p.get('CS_MIN_DIST_MS', 25.0))
        self.spin_ss_mind = QtWidgets.QDoubleSpinBox(); self.spin_ss_mind.setRange(0.0,1000.0); self.spin_ss_mind.setValue(p.get('SS_MIN_DIST_MS', 4.0))
        self.spin_ss_blank = QtWidgets.QDoubleSpinBox(); self.spin_ss_blank.setRange(0.0,1000.0); self.spin_ss_blank.setValue(p.get('SS_BLANK_MS', 18.0))
        self.spin_final_blank = QtWidgets.QDoubleSpinBox(); self.spin_final_blank.setRange(0.0, 5000.0); self.spin_final_blank.setValue(p.get('FINAL_BLANK_MS', 50.0))
        self.spin_initial_blank = QtWidgets.QDoubleSpinBox(); self.spin_initial_blank.setRange(0.0,5000.0); self.spin_initial_blank.setValue(p.get('INITIAL_BLANK_MS', 150.0))
        self.spin_tpl_cs_window = QtWidgets.QDoubleSpinBox(); self.spin_tpl_cs_window.setRange(1.0,200.0); self.spin_tpl_cs_window.setDecimals(1); self.spin_tpl_cs_window.setValue(p.get('TEMPLATE_CS_WINDOW_MS', 30.0))
        self.spin_tpl_ss_window = QtWidgets.QDoubleSpinBox(); self.spin_tpl_ss_window.setRange(1.0,100.0); self.spin_tpl_ss_window.setDecimals(1); self.spin_tpl_ss_window.setValue(p.get('TEMPLATE_SS_WINDOW_MS', 8.0))
        self.spin_template_components = QtWidgets.QSpinBox(); self.spin_template_components.setRange(1, 8); self.spin_template_components.setValue(int(p.get('TEMPLATE_PARALLEL_COMPONENTS', 2)))
        self.spin_template_components.setToolTip('PCA components used to group templates; components are not spike kernels.')
        self.spin_line_scale = QtWidgets.QDoubleSpinBox(); self.spin_line_scale.setRange(0.2,5.0); self.spin_line_scale.setDecimals(2); self.spin_line_scale.setSingleStep(0.1); self.spin_line_scale.setValue(float(p.get('LINE_WIDTH_SCALE', 0.7)))
        self.combo_raw_scale_unit = QtWidgets.QComboBox()
        self.combo_raw_scale_unit.addItem('MAD-based σ', 'Sigma')
        self.combo_raw_scale_unit.addItem('ΔF/F (%)', 'dF/F (%)')
        self.combo_raw_scale_unit.setCurrentIndex(max(0, self.combo_raw_scale_unit.findData(
            str(p.get('RAW_SCALE_BAR_UNIT', 'Sigma')))))
        form.addRow('CS min dist (ms):', self.spin_cs_mind)
        form.addRow('SS min dist (ms):', self.spin_ss_mind)
        pre, post = mask_windows(p)
        self.spin_ss_mask_pre = QtWidgets.QDoubleSpinBox()
        self.spin_ss_mask_post = QtWidgets.QDoubleSpinBox()
        for widget, value in ((self.spin_ss_mask_pre, pre), (self.spin_ss_mask_post, post)):
            widget.setRange(0.0, 1000.0)
            widget.setValue(value)
        form.addRow('SS exclusion before CS (ms):', self.spin_ss_mask_pre)
        form.addRow('SS exclusion after CS (ms):', self.spin_ss_mask_post)
        form.addRow('Initial blank (ms):', self.spin_initial_blank)
        form.addRow('Final blank (ms):', self.spin_final_blank)
        form.addRow('Template CS window (ms):', self.spin_tpl_cs_window)
        form.addRow('Template SS window (ms):', self.spin_tpl_ss_window)
        form.addRow('Parallel template PCA components:', self.spin_template_components)
        form.addRow('Global line thickness:', self.spin_line_scale)
        form.addRow('Raw scale-bar unit:', self.combo_raw_scale_unit)

        layout.addLayout(form)

        # Inline color pickers (embed color scheme settings here — no extra dialog)
        layout.addWidget(QtWidgets.QLabel('Colors:'))
        self.color_keys = ['raw','baseline','cs_trace','ss_trace','cs_thresh','ss_thresh']
        self.color_labels = {}
        grid = QtWidgets.QGridLayout()
        cols = parent.colors if parent is not None else {}
        # default (original) color scheme to fall back to when parent lacks keys
        default_colors = {
            'raw': '#333333',
            'baseline': '#FFC20A',
            'cs_trace': '#009E73',
            'ss_trace': '#D55E00',
            'cs_thresh': '#56B4E9',
            'ss_thresh': '#CC79A7'
        }
        # store defaults on the instance for use in other methods
        self.default_colors = dict(default_colors)
        color_display = ['Raw', 'Baseline', 'CS Trace', 'SS Trace', 'CS Threshold', 'SS Threshold']
        for i, key in enumerate(self.color_keys):
            grid.addWidget(QtWidgets.QLabel(color_display[i]+':'), i, 0)
            lbl = QtWidgets.QLabel('   ')
            lbl.setFixedHeight(20)
            curcol = cols.get(key, default_colors.get(key, '#FFFFFF'))
            lbl.setStyleSheet(f'background-color: {curcol};')
            lbl.setProperty('color_hex', curcol)
            btn = QtWidgets.QPushButton('Pick')
            # handler captures label and key
            def _make_handler(l=lbl, k=key):
                def _h():
                    cur = l.property('color_hex') or cols.get(k, '#ffffff')
                    col = QColorDialog.getColor(QColor(cur), self, f'Pick color for {k}')
                    if col.isValid():
                        hexc = col.name()
                        l.setStyleSheet(f'background-color: {hexc};')
                        l.setProperty('color_hex', hexc)
                return _h
            btn.clicked.connect(_make_handler())
            grid.addWidget(lbl, i, 1)
            grid.addWidget(btn, i, 2)
            self.color_labels[key] = lbl
        layout.addLayout(grid)

        # Buttons
        btns = QtWidgets.QHBoxLayout()
        ok = QtWidgets.QPushButton('OK'); cancel = QtWidgets.QPushButton('Cancel')
        ok.clicked.connect(self.save_and_close); cancel.clicked.connect(self.reject)
        self.btn_reset_app = QtWidgets.QPushButton('Reset App')
        self.btn_reset_app.setToolTip('Clear loaded data and restore app defaults after confirmation.')
        self.btn_reset_app.clicked.connect(self._reset_parent_app)
        btns.addWidget(self.btn_reset_app)
        btns.addStretch(1); btns.addWidget(ok); btns.addWidget(cancel)
        layout.addLayout(btns)

        self.setLayout(layout)
        _apply_setting_tooltips(self)

    def _reset_parent_app(self):
        if self.parent_win is not None and self.parent_win.reset_app():
            self.reject()

    def save_and_close(self):
        # Polarity is controlled in the main window.
        try:
            self.parent_win.params['DENOISE_APPLY_TO_CS'] = bool(self.chk_denoise_cs.isChecked())
        except Exception:
            pass
        # Apply SS settings
        try:
            self.parent_win.params['CS_MIN_DIST_MS'] = float(self.spin_cs_mind.value())
            self.parent_win.params['SS_MIN_DIST_MS'] = float(self.spin_ss_mind.value())
            self.parent_win.params['SS_MASK_PRE_MS'] = float(self.spin_ss_mask_pre.value())
            self.parent_win.params['SS_MASK_POST_MS'] = float(self.spin_ss_mask_post.value())
            self.parent_win.params['INITIAL_BLANK_MS'] = float(self.spin_initial_blank.value())
            self.parent_win.params['FINAL_BLANK_MS'] = float(self.spin_final_blank.value())
            self.parent_win.params['TEMPLATE_CS_WINDOW_MS'] = float(self.spin_tpl_cs_window.value())
            self.parent_win.params['TEMPLATE_SS_WINDOW_MS'] = float(self.spin_tpl_ss_window.value())
            components = int(self.spin_template_components.value())
            if components != int(self.parent_win.params.get('TEMPLATE_PARALLEL_COMPONENTS', 2)):
                self.parent_win.params['TEMPLATE_CS_SELECTED_GROUPS'] = None
                self.parent_win.params['TEMPLATE_SS_SELECTED_GROUPS'] = None
            self.parent_win.params['TEMPLATE_PARALLEL_COMPONENTS'] = components
            self.parent_win.params['LINE_WIDTH_SCALE'] = float(self.spin_line_scale.value())
            self.parent_win.params['RAW_SCALE_BAR_UNIT'] = str(self.combo_raw_scale_unit.currentData())
            _set_user_linewidth_scale(self.parent_win.params['LINE_WIDTH_SCALE'])
            for attr, key in [('spin_ss_blank', 'SS_BLANK_MS')]:
                w = getattr(self.parent_win, attr, None)
                if w is not None:
                    try:
                        old = bool(w.blockSignals(True))
                    except Exception:
                        old = False
                    try:
                        w.setValue(float(self.parent_win.params[key]))
                    finally:
                        try:
                            w.blockSignals(old)
                        except Exception:
                            pass
        except Exception:
            pass
        # Apply inline color choices to parent.colors
        try:
            cols = self.parent_win.colors
            for k, lbl in self.color_labels.items():
                hexc = lbl.property('color_hex') if lbl.property('color_hex') is not None else self.default_colors.get(k, cols.get(k))
                if hexc is None:
                    continue
                cols[k] = hexc
        except Exception:
            pass
        self.accept()


class DenoisingSettingsDialog(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Denoising Settings')
        self.resize(*_scaled_size(1180, 760))
        self.parent_win = parent
        p = parent.params if parent is not None else {}
        cfg = default_denoise_config()
        self._sig = None
        self._t = None
        self._fs = None
        self._last_meta = None
        self._preview_timer = QtCore.QTimer(self)
        self._preview_timer.setSingleShot(True)
        self._preview_timer.setInterval(120)
        self._preview_timer.timeout.connect(self.run_preview)

        root = QtWidgets.QVBoxLayout()

        # Controls (left) + preview (right) to keep plots readable.
        splitter = QtWidgets.QSplitter(Qt.Orientation.Horizontal)

        left_container = QtWidgets.QWidget()
        left_layout = QtWidgets.QVBoxLayout(left_container)

        top_form = QtWidgets.QFormLayout()
        self.spin_preview_window = QtWidgets.QDoubleSpinBox()
        self.spin_preview_window.setRange(100.0, 10000.0)
        self.spin_preview_window.setDecimals(0)
        self.spin_preview_window.setSuffix(' ms')
        self.spin_preview_window.setValue(float(p.get('DENOISE_PREVIEW_WINDOW_MS', 1000.0)))
        top_form.addRow('Preview window:', self.spin_preview_window)

        self.spin_f_min = QtWidgets.QDoubleSpinBox(); self.spin_f_min.setRange(0.5, 2000.0); self.spin_f_min.setValue(float(p.get('DENOISE_F_MIN_HZ', cfg['f_min_hz'])))
        self.spin_f_max = QtWidgets.QDoubleSpinBox(); self.spin_f_max.setRange(1.0, 5000.0); self.spin_f_max.setValue(float(p.get('DENOISE_F_MAX_HZ', cfg['f_max_hz'])))
        self.spin_n_freqs = QtWidgets.QSpinBox(); self.spin_n_freqs.setRange(8, 256); self.spin_n_freqs.setValue(int(p.get('DENOISE_N_FREQS', cfg['n_freqs'])))
        self.spin_min_clusters = QtWidgets.QSpinBox(); self.spin_min_clusters.setRange(1, 20); self.spin_min_clusters.setValue(int(p.get('DENOISE_MIN_CLUSTERS', cfg['min_clusters'])))
        self.spin_max_clusters = QtWidgets.QSpinBox(); self.spin_max_clusters.setRange(1, 20); self.spin_max_clusters.setValue(int(p.get('DENOISE_MAX_CLUSTERS', cfg['max_clusters'])))
        self.spin_pca = QtWidgets.QSpinBox(); self.spin_pca.setRange(1, 32); self.spin_pca.setValue(int(p.get('DENOISE_MAX_PCA_COMPONENTS', cfg['max_pca_components'])))
        self.spin_thr_sigma = QtWidgets.QDoubleSpinBox(); self.spin_thr_sigma.setRange(0.1, 10.0); self.spin_thr_sigma.setDecimals(2); self.spin_thr_sigma.setValue(float(p.get('DENOISE_THRESHOLD_SIGMA', cfg['threshold_sigma'])))
        self.spin_att_min = QtWidgets.QDoubleSpinBox(); self.spin_att_min.setRange(0.0, 1.0); self.spin_att_min.setDecimals(2); self.spin_att_min.setValue(float(p.get('DENOISE_ATTENUATION_MIN', cfg['attenuation_min'])))
        self.chk_soft = QtWidgets.QCheckBox('Graded below-threshold attenuation')
        self.chk_soft.setChecked(bool(p.get('DENOISE_SOFT_THRESHOLD', cfg['soft_threshold'])))
        self.spin_cycles = QtWidgets.QDoubleSpinBox(); self.spin_cycles.setRange(0.5, 10.0); self.spin_cycles.setDecimals(2); self.spin_cycles.setValue(float(p.get('DENOISE_MOVING_CYCLES', cfg['moving_cycles'])))
        self.spin_max_tp = QtWidgets.QSpinBox(); self.spin_max_tp.setRange(1000, 200000); self.spin_max_tp.setValue(int(p.get('DENOISE_MAX_TIMEPOINTS_FOR_CLUSTERING', cfg['max_timepoints_for_clustering'])))

        self.chk_event_refine = QtWidgets.QCheckBox('Event refinement (PC1-based attenuation)')
        self.chk_event_refine.setChecked(bool(p.get('DENOISE_EVENT_REFINE_ENABLED', cfg['event_refine_enabled'])))
        self.spin_evt_win = QtWidgets.QDoubleSpinBox(); self.spin_evt_win.setRange(2.0, 200.0); self.spin_evt_win.setValue(float(p.get('DENOISE_EVENT_REFINE_WINDOW_MS', cfg['event_refine_window_ms'])))
        self.spin_evt_sigma = QtWidgets.QDoubleSpinBox(); self.spin_evt_sigma.setRange(0.5, 10.0); self.spin_evt_sigma.setValue(float(p.get('DENOISE_EVENT_REFINE_SIGMA', cfg['event_refine_sigma'])))
        self.spin_evt_z = QtWidgets.QDoubleSpinBox(); self.spin_evt_z.setRange(-5.0, 5.0); self.spin_evt_z.setDecimals(2); self.spin_evt_z.setValue(float(p.get('DENOISE_EVENT_REFINE_PC1_Z_CUTOFF', cfg['event_refine_pc1_z_cutoff'])))
        self.spin_evt_att = QtWidgets.QDoubleSpinBox(); self.spin_evt_att.setRange(0.0, 1.0); self.spin_evt_att.setDecimals(2); self.spin_evt_att.setValue(float(p.get('DENOISE_EVENT_REFINE_ATTENUATION', cfg['event_refine_attenuation'])))

        group_main = QtWidgets.QGroupBox('General')
        group_main.setLayout(top_form)
        left_layout.addWidget(group_main)

        group_tf = QtWidgets.QGroupBox('Time-frequency transform')
        form_tf = QtWidgets.QFormLayout()
        form_tf.addRow('Min frequency (Hz):', self.spin_f_min)
        form_tf.addRow('Max frequency (Hz):', self.spin_f_max)
        form_tf.addRow('Frequency bins (resolution):', self.spin_n_freqs)
        group_tf.setLayout(form_tf)
        left_layout.addWidget(group_tf)

        self.chk_show_advanced = QtWidgets.QCheckBox('Show advanced settings')
        self.chk_show_advanced.setChecked(bool(p.get('DENOISE_SHOW_ADVANCED', False)))
        self.chk_show_advanced.toggled.connect(self._toggle_advanced)
        left_layout.addWidget(self.chk_show_advanced)

        group_cluster = QtWidgets.QGroupBox('Frequency clustering')
        form_cluster = QtWidgets.QFormLayout()
        form_cluster.addRow('Min clusters:', self.spin_min_clusters)
        form_cluster.addRow('Max clusters:', self.spin_max_clusters)
        form_cluster.addRow('Max PCA components:', self.spin_pca)
        form_cluster.addRow('Max timepoints for clustering:', self.spin_max_tp)
        group_cluster.setLayout(form_cluster)
        left_layout.addWidget(group_cluster)

        group_thr = QtWidgets.QGroupBox('Adaptive threshold and attenuation')
        form_thr = QtWidgets.QFormLayout()
        form_thr.addRow('Envelope threshold (SD):', self.spin_thr_sigma)
        form_thr.addRow('Min attenuation factor:', self.spin_att_min)
        form_thr.addRow(self.chk_soft)
        group_thr.setLayout(form_thr)
        left_layout.addWidget(group_thr)

        group_evt = QtWidgets.QGroupBox('Event refinement')
        form_evt = QtWidgets.QFormLayout()
        form_evt.addRow(self.chk_event_refine)
        form_evt.addRow('Event refine window (ms):', self.spin_evt_win)
        form_evt.addRow('Event refine sigma:', self.spin_evt_sigma)
        form_evt.addRow('Event PC1 z cutoff:', self.spin_evt_z)
        form_evt.addRow('Event attenuation factor:', self.spin_evt_att)
        group_evt.setLayout(form_evt)
        left_layout.addWidget(group_evt)

        group_adv = QtWidgets.QGroupBox('Advanced')
        form_adv = QtWidgets.QFormLayout()
        form_adv.addRow('Moving cycles for local threshold:', self.spin_cycles)
        group_adv.setLayout(form_adv)
        left_layout.addWidget(group_adv)

        self._advanced_groups = [group_cluster, group_evt, group_adv]
        self._toggle_advanced(self.chk_show_advanced.isChecked())
        left_layout.addStretch(1)

        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(left_container)
        splitter.addWidget(scroll)

        right_container = QtWidgets.QWidget()
        right_layout = QtWidgets.QVBoxLayout(right_container)
        self.fig = _make_figure(11.2, 7.2)
        self.canvas = FigureCanvas(self.fig)
        right_layout.addWidget(self.canvas, 1)
        self.lbl_plot_hint = QtWidgets.QLabel('QC panels show raw vs denoised trace, wavelet power, cluster masks, thresholding, and event-PC rejection.')
        self.lbl_plot_hint.setWordWrap(True)
        right_layout.addWidget(self.lbl_plot_hint)
        splitter.addWidget(right_container)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)

        root.addWidget(splitter, 1)

        btn_row = QtWidgets.QHBoxLayout()
        self.btn_tips = QtWidgets.QPushButton('Tips')
        self.btn_tips.clicked.connect(self.show_tips)
        self.lbl_info = QtWidgets.QLabel('Preview uses averaged + baseline-corrected trace of selected cell.')
        self.lbl_info.setWordWrap(True)
        btn_row.addWidget(self.btn_tips)
        btn_row.addWidget(self.lbl_info)
        btn_row.addStretch(1)

        ok = QtWidgets.QPushButton('OK')
        cancel = QtWidgets.QPushButton('Cancel')
        ok.clicked.connect(self.save_and_accept)
        cancel.clicked.connect(self.reject)
        btn_row.addWidget(ok)
        btn_row.addWidget(cancel)
        root.addLayout(btn_row)

        self.setLayout(root)
        _apply_setting_tooltips(self)
        self._connect_live_preview_signals()
        self._schedule_preview()

    def _connect_live_preview_signals(self):
        watch_widgets = [
            self.spin_preview_window,
            self.spin_f_min,
            self.spin_f_max,
            self.spin_n_freqs,
            self.spin_min_clusters,
            self.spin_max_clusters,
            self.spin_pca,
            self.spin_thr_sigma,
            self.spin_att_min,
            self.chk_soft,
            self.spin_cycles,
            self.spin_max_tp,
            self.chk_event_refine,
            self.spin_evt_win,
            self.spin_evt_sigma,
            self.spin_evt_z,
            self.spin_evt_att,
            self.chk_show_advanced,
        ]
        for w in watch_widgets:
            try:
                if hasattr(w, 'valueChanged'):
                    w.valueChanged.connect(self._schedule_preview)
                if hasattr(w, 'stateChanged'):
                    w.stateChanged.connect(self._schedule_preview)
                if hasattr(w, 'toggled'):
                    w.toggled.connect(self._schedule_preview)
            except Exception:
                pass
        try:
            if self.parent_win is not None and hasattr(self.parent_win, 'slider_time'):
                self.parent_win.slider_time.valueChanged.connect(self._schedule_preview)
        except Exception:
            pass

    def showEvent(self, event):
        super().showEvent(event)
        self._schedule_preview()

    def hideEvent(self, event):
        self._preview_timer.stop()
        super().hideEvent(event)

    def _schedule_preview(self, *_args):
        if not self.isVisible():
            return
        try:
            self._preview_timer.start()
        except Exception:
            self.run_preview()

    def _cfg_from_controls(self):
        min_k = int(self.spin_min_clusters.value())
        max_k = int(self.spin_max_clusters.value())
        if max_k < min_k:
            max_k = min_k
        return {
            'f_min_hz': float(self.spin_f_min.value()),
            'f_max_hz': float(self.spin_f_max.value()),
            'n_freqs': int(self.spin_n_freqs.value()),
            'min_clusters': int(min_k),
            'max_clusters': int(max_k),
            'max_pca_components': int(self.spin_pca.value()),
            'threshold_sigma': float(self.spin_thr_sigma.value()),
            'attenuation_min': float(self.spin_att_min.value()),
            'soft_threshold': bool(self.chk_soft.isChecked()),
            'moving_cycles': float(self.spin_cycles.value()),
            'max_timepoints_for_clustering': int(self.spin_max_tp.value()),
            'event_refine_enabled': bool(self.chk_event_refine.isChecked()),
            'event_refine_window_ms': float(self.spin_evt_win.value()),
            'event_refine_sigma': float(self.spin_evt_sigma.value()),
            'event_refine_pc1_z_cutoff': float(self.spin_evt_z.value()),
            'event_refine_attenuation': float(self.spin_evt_att.value()),
        }

    def _set_preview_trace_ylim(self, ax, arr, mask):
        try:
            vals = np.asarray(arr, dtype=float)[mask]
            vals = vals[np.isfinite(vals)]
            if vals.size < 5:
                return
            lo, hi = np.nanpercentile(vals, [0.5, 99.5])
            if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
                lo, hi = float(np.nanmin(vals)), float(np.nanmax(vals))
            span = max(float(hi - lo), 1e-9)
            pad = max(0.15 * span, 1e-9)
            ax.set_ylim(float(lo - pad), float(hi + pad))
        except Exception:
            pass

    def _denoise_setting_diagnosis(self, cfg, meta):
        notes = []
        try:
            if float(cfg.get('f_min_hz', 0.0)) >= 100.0:
                notes.append('high min freq removes subthreshold/slow components')
            if float(cfg.get('threshold_sigma', 1.5)) <= 1.1:
                notes.append('Low envelope cutoff preserves more frames before PC1 refinement')
            if float(cfg.get('attenuation_min', 0.25)) <= 0.10:
                notes.append('very low attenuation can strongly suppress below-threshold frames')
            if int(cfg.get('n_freqs', 72)) <= 32:
                notes.append('few frequency bins give coarse clustering')
            if isinstance(meta, dict) and int(meta.get('n_clusters', 1)) <= 1:
                notes.append('only one frequency cluster was used')
            if isinstance(meta, dict):
                atten = np.asarray(meta.get('attenuation_mask', np.array([])), dtype=float)
                if atten.size > 0:
                    frac = 100.0 * float(np.mean(atten < 0.99))
                    if frac > 30.0:
                        notes.append(f'{frac:.0f}% of frames attenuated')
        except Exception:
            pass
        return '; '.join(notes) if notes else 'No parameter extremes flagged; inspect waveform preservation'

    def run_preview(self):
        if not self.isVisible():
            return
        if self.parent_win is None or not hasattr(self.parent_win, '_get_current_corrected_signal_full'):
            return
        sig, t, fs = self.parent_win._get_current_corrected_signal_full()
        if sig is None or t is None or fs is None:
            QMessageBox.warning(self, 'No data', 'No active session/cell trace available.')
            return
        self._sig = np.asarray(sig, dtype=float)
        self._t = np.asarray(t, dtype=float)
        self._fs = float(fs)

        cfg = self._cfg_from_controls()
        y, meta = adaptive_wavelet_denoise(self._sig, self._fs, cfg=cfg)

        # Show a local time window to make spike-level QC easier.
        preview_ms = float(self.spin_preview_window.value())
        preview_ms = max(100.0, preview_ms)
        center_t = self._get_main_center_time(float(self._t[0]), float(self._t[-1]))
        x0 = center_t - 0.5 * preview_ms
        x1 = center_t + 0.5 * preview_ms
        if x0 < float(self._t[0]):
            x0 = float(self._t[0])
            x1 = min(float(self._t[-1]), x0 + preview_ms)
        if x1 > float(self._t[-1]):
            x1 = float(self._t[-1])
            x0 = max(float(self._t[0]), x1 - preview_ms)

        self.fig.clf()
        gs = self.fig.add_gridspec(3, 2, wspace=0.30, hspace=0.68)
        trace_gs = gs[0, 0].subgridspec(2, 1, hspace=0.04)
        ax1_raw = self.fig.add_subplot(trace_gs[0, 0])
        ax1 = self.fig.add_subplot(trace_gs[1, 0], sharex=ax1_raw)
        ax2 = self.fig.add_subplot(gs[0, 1])
        ax3 = self.fig.add_subplot(gs[1, 0])
        ax4 = self.fig.add_subplot(gs[1, 1])
        ax5 = self.fig.add_subplot(gs[2, 0])
        ax6 = self.fig.add_subplot(gs[2, 1])

        ax1_raw.plot(self._t, self._sig, color='#7a7a7a', lw=_get_linewidth(1.0), alpha=0.85)
        ax1.plot(self._t, y, color='#1f77b4', lw=_get_linewidth(1.0), alpha=0.95)
        ax1_raw.set_xlim(x0, x1)
        ax1.set_xlim(x0, x1)
        mwin = (self._t >= x0) & (self._t <= x1)
        self._set_preview_trace_ylim(ax1_raw, self._sig, mwin)
        self._set_preview_trace_ylim(ax1, y, mwin)
        ax1_raw.text(0.01, 0.88, 'Input trace', transform=ax1_raw.transAxes, ha='left', va='top', fontsize=_scale_font(9), color='#555555')
        ax1.text(0.01, 0.88, 'Denoised trace', transform=ax1.transAxes, ha='left', va='top', fontsize=_scale_font(9), color='#1f77b4')
        ax1_raw.set_ylabel('Input')
        ax1.set_ylabel('Denoised')
        ax1.set_xlabel('Time (ms)')
        try:
            ax1_raw.set_xticks([])
            ax1_raw.tick_params(axis='x', which='both', bottom=False, top=False, labelbottom=False)
            ax1_raw.spines['bottom'].set_visible(False)
        except Exception:
            pass

        if isinstance(meta, dict) and meta.get('ok', False):
            freq = np.asarray(meta.get('freqs_hz', np.array([])), dtype=float)
            mat = np.asarray(meta.get('coeff_abs_norm', np.array([])), dtype=float)
            if mat.ndim == 2 and mat.shape[0] > 0 and mat.shape[1] > 0 and freq.size == mat.shape[0]:
                ds = max(1, int(mat.shape[1] / 1200))
                t_img = self._t[::ds]
                mat_img = mat[:, ::ds]
                extent = [float(t_img[0]), float(t_img[-1]), float(np.min(freq)), float(np.max(freq))]
                im = ax2.imshow(mat_img, aspect='auto', origin='lower', extent=extent, cmap='viridis', interpolation='nearest')
                try:
                    labels = np.asarray(meta.get('cluster_labels', np.array([])), dtype=int)
                    for cid in np.unique(labels):
                        f_sel = freq[labels == cid]
                        if f_sel.size:
                            ax2.text(x1, float(np.mean(f_sel)), f'c{int(cid)}', va='center', ha='right', color='white', fontsize=7)
                except Exception:
                    pass
            else:
                ax2.text(0.5, 0.5, 'No coefficient map', ha='center', va='center', transform=ax2.transAxes)
            ax2.set_title('Complex Morlet power by frequency', fontsize=_scale_font(10), pad=3)
            ax2.set_xlabel('')
            ax2.set_ylabel('Frequency (Hz)')
            ax2.set_xlim(x0, x1)

            mask = np.asarray(meta.get('attenuation_mask', np.ones_like(self._sig)), dtype=float)
            ax3.plot(self._t, mask, color='#d55e00', lw=_get_linewidth(1.0))
            ax3.set_xlim(x0, x1)
            ax3.set_ylim(-0.05, 1.05)
            ax3.set_title('Attenuation multiplier over time', fontsize=_scale_font(10), pad=3)
            ax3.set_xlabel('')
            ax3.set_ylabel('Multiplier')

            labels = np.asarray(meta.get('cluster_labels', np.array([])), dtype=int)
            if labels.size == freq.size and labels.size > 0:
                order = np.argsort(freq)
                ax4.scatter(freq[order], labels[order], s=22, color='#009e73', alpha=0.9)
                ax4.set_xlabel('Frequency (Hz)')
                ax4.set_ylabel('Cluster id')
                ax4.set_title('Ward frequency clusters', fontsize=_scale_font(10), pad=3)
            else:
                ax4.text(0.5, 0.5, 'No cluster map', ha='center', va='center', transform=ax4.transAxes)
                ax4.set_title('Ward frequency clusters', fontsize=_scale_font(10), pad=3)

            # Cluster-wise threshold diagnostics (shows threshold is per-cluster).
            cstats = list(meta.get('cluster_stats', [])) if isinstance(meta.get('cluster_stats', []), list) else []
            if len(cstats) > 0:
                msel = (self._t >= x0) & (self._t <= x1)
                plotted = 0
                for cs in cstats[:6]:
                    env = np.asarray(cs.get('envelope', np.array([])), dtype=float)
                    thr = np.asarray(cs.get('threshold', np.array([])), dtype=float)
                    cid = int(cs.get('cluster_id', -1))
                    if env.size != self._t.size or thr.size != self._t.size:
                        continue
                    mask_i = np.asarray(cs.get('mask', np.array([])), dtype=float)
                    ax5.plot(self._t[msel], env[msel], lw=_get_linewidth(0.9), alpha=0.70, label=f'c{cid} signal')
                    ax5.plot(self._t[msel], thr[msel], lw=_get_linewidth(1.0), ls='--', alpha=0.85, label=f'c{cid} threshold')
                    if mask_i.size == self._t.size:
                        below = mask_i[msel] < 0.99
                        if np.any(below):
                            ax5.fill_between(self._t[msel], np.nanmin(env[msel]), np.nanmax(thr[msel]), where=below, color='#d55e00', alpha=0.06)
                    plotted += 1
                if plotted > 0:
                    ax5.legend(frameon=False, fontsize=7, ncol=2)
                else:
                    ax5.text(0.5, 0.5, 'No cluster threshold curves', ha='center', va='center', transform=ax5.transAxes)
            else:
                ax5.text(0.5, 0.5, 'No cluster diagnostics', ha='center', va='center', transform=ax5.transAxes)
            ax5.set_title('Cluster threshold gates', fontsize=_scale_font(10), pad=3)
            ax5.set_xlabel('Time (ms)')
            ax5.set_ylabel('Magnitude')
            ax5.set_xlim(x0, x1)

            # PCA-score diagnostics for event refinement.
            ev = meta.get('event_refine', {}) if isinstance(meta.get('event_refine', {}), dict) else {}
            pidx = np.asarray(ev.get('peak_indices', np.array([])), dtype=int)
            pz = np.asarray(ev.get('peak_scores_z', np.array([])), dtype=float)
            patt = np.asarray(ev.get('peak_att_mask', np.array([])), dtype=bool)
            cutoff = float(ev.get('cutoff', np.nan)) if np.isfinite(ev.get('cutoff', np.nan)) else float(cfg.get('event_refine_pc1_z_cutoff', -0.5))
            if pidx.size > 0 and pz.size == pidx.size:
                pt = self._t[np.clip(pidx, 0, self._t.size - 1)]
                keep = (pt >= x0) & (pt <= x1)
                if np.any(keep):
                    pt = pt[keep]
                    pz_k = pz[keep]
                    patt_k = patt[keep] if patt.size == pidx.size else np.zeros_like(pz_k, dtype=bool)
                    ax6.scatter(pt[~patt_k], pz_k[~patt_k], s=16, alpha=0.7, label='kept', color='#4c72b0')
                    if np.any(patt_k):
                        ax6.scatter(pt[patt_k], pz_k[patt_k], s=22, alpha=0.9, label='attenuated', color='#d55e00')
                else:
                    ax6.text(0.5, 0.5, 'No detected events in window', ha='center', va='center', transform=ax6.transAxes)
                ax6.axhline(cutoff, color='k', lw=_get_linewidth(1.0), ls='--', alpha=0.8)
            else:
                ax6.text(0.5, 0.5, 'Event PCA diagnostics unavailable', ha='center', va='center', transform=ax6.transAxes)
                ax6.axhline(cutoff, color='k', lw=_get_linewidth(1.0), ls='--', alpha=0.8)
            ax6.set_title('Per-cluster event PC1 rejection', fontsize=_scale_font(10), pad=3)
            ax6.set_xlabel('Time (ms)')
            ax6.set_ylabel('z-score')
            ax6.set_xlim(x0, x1)
            try:
                ax6.legend(frameon=False, fontsize=8)
            except Exception:
                pass

            txt = (
                f"wavelet={meta.get('wavelet', 'cmor')}, clusters={int(meta.get('n_clusters', 1))}, "
                f"PCA elbow={int(meta.get('cluster_pca_elbow_components', 0))}, "
                f"silhouette={float(meta.get('silhouette', np.nan)):.3f}, "
                f"event attenuated={int(meta.get('event_refined_count', 0))}"
            )
            cwarn = meta.get('cluster_warning', None)
            if cwarn:
                txt += f" | cluster_warning={cwarn}"
            txt += f" | diagnosis: {self._denoise_setting_diagnosis(cfg, meta)}"
            self.lbl_info.setText(txt)
        else:
            ax2.text(0.5, 0.5, 'Denoise failed', ha='center', va='center', transform=ax2.transAxes)
            ax3.text(0.5, 0.5, str(meta.get('error', 'unknown')) if isinstance(meta, dict) else 'unknown', ha='center', va='center', transform=ax3.transAxes)
            ax5.text(0.5, 0.5, 'No cluster diagnostics', ha='center', va='center', transform=ax5.transAxes)
            ax6.text(0.5, 0.5, 'No PCA event diagnostics', ha='center', va='center', transform=ax6.transAxes)
            self.lbl_info.setText('Denoise preview failed. Check settings/dependencies.')

        for a in [ax1_raw, ax1, ax2, ax3, ax4, ax5, ax6]:
            try:
                a.grid(False)
                a.tick_params(axis='both', labelsize=_scale_font(8))
                a.spines['top'].set_visible(False)
                a.spines['right'].set_visible(False)
            except Exception:
                pass
        self._last_meta = meta
        self.fig.tight_layout(pad=1.2)
        self.canvas.draw()

    def _get_main_center_time(self, t0, t1):
        try:
            if self.parent_win is not None and hasattr(self.parent_win, 'slider_time'):
                center_pct = float(self.parent_win.slider_time.value()) / 1000.0
                return float(t0 + center_pct * (t1 - t0))
        except Exception:
            pass
        return float(0.5 * (t0 + t1))

    def show_tips(self):
        tips = (
            '<b>Adaptive wavelet denoising</b><br><br>'
            'The complex Morlet representation is normalized per frequency, grouped into frequency clusters, attenuated and reconstructed.<br><br>'
            '<b>Parameter meanings</b><br>'
            '- <i>Frequency limits</i>: select the wavelet range. GUI detection requires the upper limit to remain below 95% of Nyquist.<br>'
            '- <i>Envelope threshold</i>: local cluster-envelope mean + multiplier × local SD. Increasing this multiplier preserves fewer frames unchanged; lowering it preserves more. It is not an event-SNR cutoff.<br>'
            '- <i>Minimum attenuation factor</i>: fraction retained below threshold; 1 preserves the coefficients. Graded attenuation varies between this floor and 1.<br>'
            '- <i>Moving cycles</i>: threshold window = cycles / highest frequency in the cluster, with a five-sample minimum.<br>'
            '- <i>Event refinement</i>: proposes events using absolute cluster-trace amplitude / MAD, then attenuates windows below a robust PC1-score cutoff. A low PC1 score does not prove an event is noise.<br><br>'
            '<b>Reading the preview</b><br>'
            'Compare the same events before and after denoising, including burst spikes and broad CS shoulders. The attenuation plot shows where coefficients were reduced. Frequency-bin count, PCA, clustering and sampled timepoints can all change the reconstructed signal; they are not merely display or speed controls.'
        )
        QMessageBox.information(self, 'Denoising Tips', tips)

    def _toggle_advanced(self, checked):
        show = bool(checked)
        for g in getattr(self, '_advanced_groups', []):
            try:
                g.setVisible(show)
            except Exception:
                pass

    def save_and_accept(self):
        if self.parent_win is None:
            self.accept()
            return
        cfg = self._cfg_from_controls()
        m = self.parent_win.params
        m['DENOISE_SHOW_ADVANCED'] = bool(self.chk_show_advanced.isChecked())
        m['DENOISE_PREVIEW_WINDOW_MS'] = float(self.spin_preview_window.value())
        m['DENOISE_F_MIN_HZ'] = float(cfg['f_min_hz'])
        m['DENOISE_F_MAX_HZ'] = float(cfg['f_max_hz'])
        m['DENOISE_N_FREQS'] = int(cfg['n_freqs'])
        m['DENOISE_MIN_CLUSTERS'] = int(cfg['min_clusters'])
        m['DENOISE_MAX_CLUSTERS'] = int(cfg['max_clusters'])
        m['DENOISE_MAX_PCA_COMPONENTS'] = int(cfg['max_pca_components'])
        m['DENOISE_THRESHOLD_SIGMA'] = float(cfg['threshold_sigma'])
        m['DENOISE_ATTENUATION_MIN'] = float(cfg['attenuation_min'])
        m['DENOISE_SOFT_THRESHOLD'] = bool(cfg['soft_threshold'])
        m['DENOISE_MOVING_CYCLES'] = float(cfg['moving_cycles'])
        m['DENOISE_MAX_TIMEPOINTS_FOR_CLUSTERING'] = int(cfg['max_timepoints_for_clustering'])
        m['DENOISE_EVENT_REFINE_ENABLED'] = bool(cfg['event_refine_enabled'])
        m['DENOISE_EVENT_REFINE_WINDOW_MS'] = float(cfg['event_refine_window_ms'])
        m['DENOISE_EVENT_REFINE_SIGMA'] = float(cfg['event_refine_sigma'])
        m['DENOISE_EVENT_REFINE_PC1_Z_CUTOFF'] = float(cfg['event_refine_pc1_z_cutoff'])
        m['DENOISE_EVENT_REFINE_ATTENUATION'] = float(cfg['event_refine_attenuation'])
        try:
            self.parent_win._denoise_cache.clear()
        except Exception:
            pass
        self.accept()


class ColorSchemeDialog(QtWidgets.QDialog):
    """Dialog for selecting color scheme for plots"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Color Scheme Settings')
        self.resize(*_scaled_size(400, 300))
        
        self.color_schemes = {
            'Default': {
                'raw': '#333333',
                'baseline': '#FFC20A',
                'cs_trace': '#009E73',
                'ss_trace': '#D55E00',
                'cs_thresh': '#56B4E9',
                'ss_thresh': '#CC79A7'
            },
            'Dark': {
                'raw': '#CCCCCC',
                'baseline': '#FFD700',
                'cs_trace': '#00FF41',
                'ss_trace': '#FF6B35',
                'cs_thresh': '#00D4FF',
                'ss_thresh': '#FF1493'
            },
            'Light': {
                'raw': '#000000',
                'baseline': '#FF8C00',
                'cs_trace': '#228B22',
                'ss_trace': '#DC143C',
                'cs_thresh': '#4169E1',
                'ss_thresh': '#8B008B'
            },
            'Colorblind-friendly': {
                'raw': '#000000',
                'baseline': '#FF7F00',
                'cs_trace': '#0173B2',
                'ss_trace': '#DE8F05',
                'cs_thresh': '#CC78BC',
                'ss_thresh': '#CA9161'
            }
        }
        
        layout = QtWidgets.QVBoxLayout()
        
        label = QtWidgets.QLabel('Select Color Scheme:')
        layout.addWidget(label)
        
        self.combo = QtWidgets.QComboBox()
        self.combo.addItems(self.color_schemes.keys())
        layout.addWidget(self.combo)
        
        # Preview and customize area
        preview_group = QtWidgets.QGroupBox('Color Preview / Customize')
        preview_layout = QtWidgets.QGridLayout()
        self.color_labels = {}
        self.color_buttons = {}
        color_names = ['raw', 'baseline', 'cs_trace', 'ss_trace', 'cs_thresh', 'ss_thresh']
        color_display = ['Raw', 'Baseline', 'CS Trace', 'SS Trace', 'CS Threshold', 'SS Threshold']

        for idx, (color_key, color_display_name) in enumerate(zip(color_names, color_display)):
            preview_layout.addWidget(QtWidgets.QLabel(color_display_name), idx, 0)
            self.color_labels[color_key] = QtWidgets.QLabel('   ')
            self.color_labels[color_key].setFixedHeight(22)
            preview_layout.addWidget(self.color_labels[color_key], idx, 1)
            btn = QtWidgets.QPushButton('Pick')
            btn.clicked.connect(self._make_pick_handler(color_key))
            preview_layout.addWidget(btn, idx, 2)
            self.color_buttons[color_key] = btn

        preview_group.setLayout(preview_layout)
        layout.addWidget(preview_group)

        # Buttons: OK / Cancel
        btns_h = QtWidgets.QHBoxLayout()
        btn_ok = QtWidgets.QPushButton('OK')
        btn_cancel = QtWidgets.QPushButton('Cancel')
        btn_ok.clicked.connect(self.accept)
        btn_cancel.clicked.connect(self.reject)
        btns_h.addStretch(1); btns_h.addWidget(btn_ok); btns_h.addWidget(btn_cancel)
        layout.addLayout(btns_h)

        self.setLayout(layout)
        _apply_setting_tooltips(self)
        self.combo.currentTextChanged.connect(self.update_preview)
        self.update_preview()

    def _make_pick_handler(self, key):
        def handler():
            cur = self.color_labels[key].property('color_hex') or self.color_schemes[self.combo.currentText()].get(key, '#ffffff')
            col = QColorDialog.getColor(QColor(cur), self, f'Pick color for {key}')
            if col.isValid():
                hexc = col.name()
                self.color_labels[key].setStyleSheet(f'background-color: {hexc};')
                self.color_labels[key].setProperty('color_hex', hexc)
        return handler
    
    def update_preview(self):
        scheme = self.color_schemes[self.combo.currentText()]
        for color_key, label in self.color_labels.items():
            color = scheme.get(color_key, '#FFFFFF')
            label.setStyleSheet(f'background-color: {color};')
            label.setProperty('color_hex', color)
    
    def get_scheme(self):
        # return current edited scheme
        scheme = dict(self.color_schemes[self.combo.currentText()])
        for k, lbl in self.color_labels.items():
            hexc = lbl.property('color_hex') if lbl.property('color_hex') is not None else scheme.get(k)
            scheme[k] = hexc
        return scheme


def main():
    try:
        policy = Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
        QtWidgets.QApplication.setHighDpiScaleFactorRoundingPolicy(policy)
    except Exception:
        pass
    app = QtWidgets.QApplication(sys.argv)
    app.setApplicationName('Spike Detector')
    app.setApplicationDisplayName('Spike Detector')
    app.setWindowIcon(_application_icon())
    try:
        s = _get_screen_scale()
        if s > 1.0 and sys.platform != 'darwin':
            f = app.font()
            ps = float(f.pointSizeF()) if f.pointSizeF() > 0 else float(f.pointSize())
            if ps > 0:
                f.setPointSizeF(ps * (1.0 + 0.12 * max(0.0, s - 1.0)))
                app.setFont(f)
    except Exception:
        pass
    w = MainWindow()
    w.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
